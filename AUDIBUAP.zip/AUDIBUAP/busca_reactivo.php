<?php
error_reporting(E_ERROR);
//+++++++++++++++++++++++  Esta ventana es llamada por menu_reactivos.php +++++++++++++++++++++++++++++++++++++++

 session_start();
	//verificamos que se halla accesado desde la pagina de ingreso (verificamos que exista alguna variable de sesi�n)
	if (!Session_is_registered("S_idDocente")){
       echo('<script languaje="javascript" type="text/javascript">
               location.href="index.php";
            </script>');
    }
  //Si existe la variable de sesi�n entonces se ejecuta el c�digo
  else{
	$_SESSION["opcion"]=0;    //Asignamos opcion=0 para indicar en otros formularios que estamos modificando
?>

<html>
<head>
<title>Buscar Reactivos</title>
<link rel="stylesheet" href="css/estilo_buscar_react.css" type="text/css" media="screen" />

<script language='Javascript' type='text/javascript'>
<!-- La siguiente funci�n optienen el nombre del bot�n que se oprimi� y se lo asigna a una variable para que se env�ecomo campo oculto-->
  function boton(objeto){
     document.getElementById("nom_btn").value = objeto.name;
     document.form1.submit();    <!-- se env�a el formulario-->
  }   <!-- Fin de la Funci�n-->
</script>
<!--****************************************************************************************--> 
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"></head>
<body>
<?php
   $id_docente= $_POST["cbx_docente"];
   $nom_docente= $_POST["docente"];
   $id_materia= $_POST["cbx_materia"];
   $nom_materia= $_POST["materia"];   
   $id_tema= $_POST["cbx_tema"];
?>
<div class="Contenedor" >
  <div class="imagen1"><img src="imagenes/EscudoBuap.png" width="67" height="100"></div>
			  <div class="Estilo5">
                <div class="Titulo1">- ALTA DE COORDINADORES -</div>
			    <div class="Titulo3">SISTEMA WEB DE REACTIVOS PARA EVALUAR EL APRENDIZAJE EN LA EDUCACI�N SUPERIOR</div>
				 <div class="imagen2"><img src="imagenes/dotted_line.png">
			  </div>
	 <div class="titulo2">
       <p>DOCENTE: <?php echo($nom_docente); ?> </p>	 
       <p>MATERIA: <?php echo($nom_materia); ?> </p>
  </div>
     <div align="center" class="Estilo1">
     <br>
	 
<?php	 
   require("conexion.php");
   $consulta="SELECT * FROM banco_reactivos WHERE id_docente = '".$id_docente."' and id_tema = '".$id_tema."';";  
   $hacerconsulta=mysql_query($consulta, $link);
   if ($hacerconsulta) {
		$prog =1;  //N�mero progresivo
		$i=0;
	    echo("<table width='1150' align='center' border='0' cellspacing='0'>");
		  
		     echo("<tr align='center' bgcolor='#FFDE00'>");
             echo("<td width='60'>N�MERO</td>");    
			 echo("<td width='60'>C�DIGO</td>");
			 echo("<td width='370'>INSTRUCCI�N</td>");
			 echo("<td width='370'>BASE</td>");							
  		  	 echo("<td width='115'>AREA</td>");
	  		 echo("<td width='115'>SUBAREA</td>");
			 echo("<td width='60'>&nbsp;</td>");	//crea una celda para el bot�n de modificar			
          echo("</tr>");
		  while($datos= mysql_fetch_array ($hacerconsulta, MYSQL_ASSOC)){ 							 
		     echo("<tr>");
               echo("<td align='center'>".$prog."</td>");
			   echo("<td align='center'>".$datos["id_pregunta"]."</td>");
			   echo("<td>".$datos["instruccion"]."&nbsp;</td>");
			   echo("<td>".$datos["base"]."</td>");
			   echo("<td>".$datos["id_tema"]."</td>");
			   echo("<td>".$datos["id_subtema"]."</td>");										
			   echo("<td align='center'> 
			         <input type='button' name='".$i."' id='".$i."' value='Editar' onClick='boton(this)'/>
					  </td>");//crea bot�n modificar
             echo("</tr>");
		//Observar que a todos los resultados de la base de datos se le aplica la fuunci�n "trim" para que elimine los tabuladores, enters al inicio y final de la cadena ya que si lleva estos, ocurre errores al mandar el arreglo  
	//Creamos un arreglo con los caracteres que se deben eliminar de la cadena para que al enviar el arreglo no cause error (no muestra los datos)
			 $b=array("'","\"","\r\n","\r","\n");    //estos son los caracteres que vamos a eliminar
			 $usuario[$i]["id_pregunta"]= $datos["id_pregunta"];
			 $usuario[$i]["instruccion"]= str_replace( $b,"",trim($datos["instruccion"]));  //Remplazamos los caracteres de la cadena
			 $usuario[$i]["base"]= str_replace( $b,"",trim($datos["base"]));   //Remplazamos los caracteres de la cadena
			 $usuario[$i]["opcionA"]= str_replace( $b,"",trim($datos["opcionA"]));    //Remplazamos los caracteres de la cadena
			 $usuario[$i]["opcionB"]= str_replace( $b,"",trim($datos["opcionB"]));    //Remplazamos los caracteres de la cadena
			 $usuario[$i]["opcionC"]= str_replace( $b,"",trim($datos["opcionC"]));
			 $usuario[$i]["opcionD"]= str_replace( $b,"",trim($datos["opcionD"]));
 			 $usuario[$i]["opcion_correcta"]= str_replace( $b,"",trim($datos["opcion_correcta"]));
			 $usuario[$i]["formato"]= trim($datos["formato"]);			 
			 $usuario[$i]["nivel_tax"]= trim($datos["nivel_tax"]);
			 $usuario[$i]["just_fuente"]= str_replace( $b,"",trim($datos["just_fuente"]));  
			 $usuario[$i]["id_tema"]= trim($datos["id_tema"]);
			 $usuario[$i]["tema"]= trim($datos["tema"]);
			 $usuario[$i]["id_subtema"]= trim($datos["id_subtema"]);
			 $usuario[$i]["subtema"]= trim($datos["subtema"]);			 
			 $usuario[$i]["id_materia"]= trim($datos["id_materia"]);
			 $usuario[$i]["semestre"]= trim($datos["semestre"]);			 
			 $usuario[$i]["id_docente"]= trim($datos["id_docente"]);
			 $usuario[$i]["fecha"]= trim($datos["fecha"]);
			 $i+=1;
             $prog +=1;
		  }
        echo("</table>");
?>		
     </div>  <!-- Estilo1 -->
	 <div class="botones">
		     <input type="button2" name="btn_volver" id="btn_volver" value="REGRESAR"  onClick="location.href='menu_reactivos.php';"/>
	 </div>   
</div>   
   <!-- Contenedor -->
<?php	
	 //Para poder mandar el arreglo es necesario aplicarle estas 2 funciones;
    $usuario = serialize($usuario); 
    $usuario = urlencode($usuario); 
	
	echo('<form name="form1" id="form1" method="post" action="ficha_reactivos.php">');
         echo('<input type="hidden" name="nom_btn" id= "nom_btn" value="">');   //se envia el nombre del bot�n que se oprimi�
	     echo('<input type="hidden" name="datos_usuario" id= "datos_usuario" value="'.$usuario.'">');   //se env�a el arreglo
		 echo('<input type="hidden" name="semestre" id= "semestre" value="'.$sem.'">');   //se env�a el semestre
	     
		 //Se env�an estas 4 var para que al regresar a la pag busca_reactivo.php pueda mostrar nuevamente los resultados de busqueda 
         echo('<input type="hidden" name="cbx_docente" id= "cbx_docente" value="'.$id_docente.'">');
         echo('<input type="hidden" name="cbx_tema" id= "cbx_tema" value="'.$id_tema.'">');
	     echo('<input type="hidden" name="materia" id= "materia" value="'.$nom_materia.'">'); 
	     echo('<input type="hidden" name="docente" id= "docente" value="'.$nom_docente.'">'); 		 
		 echo('<input type="hidden" name="'.session_name().'" value="'.session_id().'">');
	echo('</form>');
	 
	 }  //Fin if externo
    else{ echo("No se encontro ning�n registro"); }
?>
</body>
</html>
<?php
} //Se cierra el ELSE que se abri� al inicio
?>
