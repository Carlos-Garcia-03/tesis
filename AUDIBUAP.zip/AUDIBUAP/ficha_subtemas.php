<?php
error_reporting(E_ERROR);
//+++++++++++++++++++++++  Esta ventana es llamada por envio_var_busca_docentes.php +++++++++++++++++++++++++++++++++++++++
    session_start();
	//verificamos que se halla accesado desde la pagina de ingreso (verificamos que exista alguna variable de sesi�n)
	if (!Session_is_registered("S_idDocente")){    //Si existe la variable de sesi�n entonces se ejecuta el c�digo
?>
       <script languaje="javascript" type="text/javascript">
           location.href="index.php";
       </script>
<?php
    }
    else{
?>

<html>
<head>
<title>Agregar Sub�reas</title>
<link rel="stylesheet" href="css/estilo_ficha2.css" type="text/css" media="screen" />

<!--************* Esta funci�n que rellena los combox ********************-->	  
<script language="javascript" src="js/jquery-1.2.6.min.js"></script>  <!--Se requiere paracargar los combox-->   
<script language="javascript">

$(document).ready(function(){
	// Parametros para el combo1
   $("#cbox_semestre").change(function () {
   		                $("#cbox_semestre option:selected").each(function () {
				                                           elegido = $(this).val();
														   $.post("combo1.php", { elegido: elegido }, function(data){
				                                                                                       $("#cbox_materia").html(data);
				                                                                                       $("#cbox_tema").html('');																									   
			                                                                                         });			
                                                             });
                          })
   $("#cbox_materia").change(function () {
   		                $("#cbox_materia option:selected").each(function () {
				                                           elegido = $(this).val();
														   $.post("carga_temas.php", { elegido: elegido }, function(data){
				                                                                                       $("#cbox_tema").html(data);
			                                                                                         });			
                                                             });
                          })
						  
});
</script>	
<!--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-->
<script language='Javascript' type='text/javascript'>
<!--************* Esta funci�n verifica que se hallan escrito todos los datos********************-->	  
  function valida_datos(){
	  var error=false;
	  if(document.getElementById("cbox_semestre").value==0){
	     error=true;
         javascript:window.alert('Error... Debe seleccionar un Semestre');
	  }	 
	  else{ if(document.getElementById("cbox_materia").value==0){
	           error=true;
               javascript:window.alert('Error... Debe seleccionar una materia');
			}   
		    else{ if(document.getElementById("cbox_tema").value==0){
	                 error=true;
                     javascript:window.alert('Error... Debe seleccionar un Tema');
			      }
			      else{ if(document.getElementById("txt_subtema").value==''){
			               error=true;
                           javascript:window.alert('Error... El campo SubTema no puede quedar en blanco');
				        }
				  }
            }
	  }
	  if (!error) document.form.submit();    <!-- Si se escribieron todos los datos se env�a el formulario-->
  }   <!-- Fin de la Funci�n-->
</script>	
<!--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-->
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body> 
  <div class="Contenedor">
	<div class="imagen1"><img src="imagenes/EscudoBuap.png" width="67" height="100"></div>
			  <div class="Estilo5">
                <div class="Titulo1">- AGREGAR SUB�REAS -</div>
			    <div class="Titulo2">SISTEMA WEB DE REACTIVOS PARA EVALUAR EL APRENDIZAJE EN LA EDUCACI�N SUPERIOR</div>
				 <div class="imagen2"><img src="imagenes/dotted_line.png">
			  </div>  
	<form name="form" id="form" action="inserta_subtemas_.php"  method="post">
      <div class="Cuadro1">
      <table>
        <tr>
          <td width="160" height="41"><div align="center"><strong>Nivel</strong></div></td>
          <td width="277"><label>
             <select name="cbox_semestre" id="cbox_semestre">
               <option value="0">-Seleccione un nivel-</option>
               <option value="1">NIvel Basico</option>
               <option value="2">Nivel Formativo</option>
               <option value="3">Nivel Optativo</option>
             </select>
             </label></td>
        </tr>
        <tr>
          <td height="41"><div align="center"><strong>Materia</strong></div></td>
          <td><label>
             <select name="cbox_materia" id="cbox_materia">
             </select>
          </label></td>
        </tr>
		<tr>
          <td height="41"><div align="center"><strong>Area</strong></div></td>
          <td><label>
             <select name="cbox_tema" id="cbox_tema">
             </select>
          </label></td>
        </tr>
        <tr>
          <td height="41"><div align="center"><strong>SubArea</strong></div></td>
          <td><input type="text1" name="txt_subtema" id="txt_subtema" /></td>
        </tr>      
     </table>    
     </div>   <!--Cuadro1-->
     <div class="Botones">
       <table width="199" height="46" border="0" align="center">
          <tr>
            <td width="98"  align="center">
              <input type='button' name='btn_guardar' id='btn_guardar' value='GUARDAR'  onClick='valida_datos();'/>
            </td>
            <td width="84"  align="center">
              <input type='button' name='btn_volver' id='btn_volver' value='REGRESAR'  onClick="location.href='ficha_reactivos.php'"/>
            </td>
		  </tr>

       </table>
     </div>  <!--botones-->
    </form>
  </div>  <!--Contenedor-->
</body>
</html>
<?php
    }
?>
