<?php
error_reporting(E_ERROR);
    $numPreg=0;
    require("conexion.php");
    $consulta='SELECT COUNT(id_subtema) AS num_subtema 
	           FROM banco_reactivos
			   WHERE id_subtema = "'.$_POST["elegido"].'";';  //busca los subtemas que coincidan con la materia 
    $hacerconsulta=mysql_query($consulta, $link);
    
    $rpta="<option value= '0'>-preguntas-</option>;";
    if ($hacerconsulta) {    //si no hubo error al hacer la consulta
	   $subtema=mysql_fetch_array ($hacerconsulta, MYSQL_ASSOC);
	   $numPreg = $subtema["num_subtema"];
	   for ($i=1; $i<=$numPreg; $i++){
	         $rpta= $rpta.'<option value="'.$i.'">'.$i.'</option>';
	   }
    }
    else {
       $rpta= '<option value="1">error...</option>';
    }  
echo ($rpta);	
?>
