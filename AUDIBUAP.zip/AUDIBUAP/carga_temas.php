
<?php
error_reporting(E_ERROR);
    require("conexion.php");
    $consulta='SELECT tema, id_tema FROM temas  WHERE id_materia = "'.$_POST["elegido"].'" GROUP BY tema;';  //busca los temas que coincidan con la materia y los agrupa
    $hacerconsulta=mysql_query($consulta, $link);
    $rpta="<option value= '0'>Seleccione el Tema</option>;";
    if ($hacerconsulta) {    //si no hubo error al hacer la consulta
	   while ($dato=mysql_fetch_array ($hacerconsulta, MYSQL_ASSOC)){
	       if($dato["id_tema"]==$_POST["id_tema"]) {  // opci�n que se mostrar� por defaul en el select
              $rpta= $rpta.'<option value="'.$dato["id_tema"].'" selected="selected">'.htmlentities($dato["tema"]).'</option>';
		   }
	       else {
		      $rpta= $rpta.'<option value="'.$dato["id_tema"].'">'.htmlentities($dato["tema"]).'</option>';
		   }
	   }
    }
    else {
       $rpta= '<option value="1">error...</option>';
    }  
echo ($rpta);	
?>
