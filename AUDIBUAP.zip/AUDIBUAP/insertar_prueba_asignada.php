<?php 
error_reporting(E_ERROR);
    //Es necesario este procedimiento cuando se reciben matrices
    function recibe_array($url_array) { 
       $tmp = stripslashes($url_array); 
       $tmp = urldecode($tmp); 
       $tmp = unserialize($tmp); 

    return $tmp; 
    } 
//*********** Funci�n que muestra los mensajes de error *****************************	    
 function mensaje($msj){
       echo('
	         <html>
             <head>
                <script language="javascript" type="text/javascript">
                   function mandar(){        
	   ');
				     if($msj==1) echo("javascript:window.alert('La Prueba se asign� correctamente')");
                     if($msj==2) echo("javascript:window.alert('Error... No fue posible asignar la prueba');");
				 	 if($msj==3) echo("javascript:window.alert('Error.. No existe ning�n alumno al cual asignar el examen');");
				 	 if($msj==4) echo("javascript:window.alert('Error... Algunas variables estan vacias');");					 
				 	 if($msj==5) echo("javascript:window.alert('Error... No seleccion� ning�n alumno');");					 					 
	   echo('
	                 document.f0.submit();
                   }
                </script>
		     </head>
		     <body onLoad="javascript:mandar();">
				 <form name="f0" id="f0" method="post" action="menu_asignar_prueba.php">
                      <input type="hidden" name="'.session_name().'" value="'.session_id().'">
                 </form>
			 </body>
 		     </html>
		');
}		 
   
   
//***************************  Convierte fecha de normal a mysql ******************************
  function cambiaf_a_mysql($fecha){
     ereg( "([0-9]{1,2})/([0-9]{1,2})/([0-9]{2,4})", $fecha, $mifecha);
     $lafecha=$mifecha[3]."-".$mifecha[2]."-".$mifecha[1];
     return $lafecha;
  } 
//****************************************************************************************************
$casilla_seleccionada= false;
$mat_alumnos = recibe_array($_POST['alumnos']);   
$id_examen = $_POST['id_examen'];

if ($id_examen != "" and count($mat_alumnos)>0){
   	if ($_POST['num_reg'] > 0) {
	    require("conexion.php");
	    for($i=0; $i <= $_POST['num_reg']; $i+=1){
           $checkbox ="c".$i;        //creamos las variables del checkbox c1,c2,...cn que se crearon en asignar_examen.php
           if ($_POST[$checkbox] == 1){     //verifica que haya sido asignado 1=asignado  0=no asignado		
		      $casilla_seleccionada= true;   //se le asigna true si se selecciona por lo menos una casillla
			  $fecha= date("d/m/Y");  //optiene la fecha del sistema   
              $consulta="INSERT INTO pruebas_asignadas (id_alumnos, id_examen,fecha)
                         VALUES ('".$mat_alumnos[$i]."','".$id_examen."','".cambiaf_a_mysql($fecha)."');";
	          $hacerconsulta=mysql_query($consulta, $link);
		      if ($hacerconsulta) {
                  mensaje(1);   // la operaci�n se realiz� correctamente
			  }
			  else mensaje(2);   //"error... No se pudo insertar un  registro
           }  //fin if
	    }  //fin for
        mysql_close($link);   //cierra la conexion
	}  
    else mensaje(3);     //El n�mero de registros es cero
}  //fin if externo
else mensaje(4);   //Se recivieron variables vacias
if(!$casilla_seleccionada) mensaje(5);    //no se seleccion� ninguna casilla
?>
