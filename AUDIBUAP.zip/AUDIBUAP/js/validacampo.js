function valida_campos(){
   if (!document.getElementById('txt_usuario').value) window.alert('El campo usuario no puede estar vacio.'); 
   else document.form1.submit(); 
}
