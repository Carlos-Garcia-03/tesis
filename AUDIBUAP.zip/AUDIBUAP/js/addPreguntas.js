function nuevoAjax()
{ 
	/* Crea el objeto AJAX. Esta funcion es generica para cualquier utilidad de este tipo, por
	lo que se puede copiar tal como esta aqui */
	var xmlhttp=false; 
	try 
	{ 
		// Creacion del objeto AJAX para navegadores no IE
		xmlhttp=new ActiveXObject("Msxml2.XMLHTTP"); 
	}
	catch(e)
	{ 
		try
		{ 
			// Creacion del objet AJAX para IE 
			xmlhttp=new ActiveXObject("Microsoft.XMLHTTP"); 
		} 
		catch(E) { xmlhttp=false; }
	}
	if (!xmlhttp && typeof XMLHttpRequest!="undefined") { xmlhttp=new XMLHttpRequest(); } 

	return xmlhttp; 
}
//-----------------------------------------------------------------------------------------------------------
function validaDatos(valor)
{
	/* Funcion encargada de validar lo ingresado por el usuario. Se devuelve TRUE en caso de ser 
	valido, FALSE en caso contrario */
	var reg=/(^[a-zA-Z0-9.@ ]{1,40}$)/;   //[caracteres permitidos]{cadena de 1 a 40 caraceres}
	if(reg.test(valor)) return true;
	else return false;
}
//-----------------------------------------------------------------------------------------------------------
function AgregarPregunta(contador)
{
	// Obtengo el div donde se mostraran las advertencias y errores
	var divMensaje=document.getElementById("msjerror");
    var txt_nom_exa=document.getElementById("txt_nom_exa");  //Nombre del examen
	var cbx_mat=document.getElementById("cbx_mat");	   //Id de la materia
    var cbx_tema=document.getElementById("cbx_tema");  //Id del tema
	var cbx_subtema=document.getElementById("cbx_subtema");   //Id del subtema
	var cbx_numpreg=document.getElementById("cbx_numpreg");   //Cantidad de preguntas del subtema que tendr� la prueba
	
	//Aqu� obtenemos el valor de las variables	
	var nom_exa = txt_nom_exa.value;  
	var id_mat = cbx_mat.value;
	var id_tema = cbx_tema.value;	
	var id_subtema = cbx_subtema.value;
	var id = id_subtema;  
	var num_preg = cbx_numpreg.value;
	var nom_mat = cbx_mat.options[cbx_mat.selectedIndex].text;
	var nom_tema = cbx_tema.options[cbx_tema.selectedIndex].text;
	var nom_subtema = cbx_subtema.options[cbx_subtema.selectedIndex].text;
	var resultado = divMensaje.innerHTML;
	//Se van a crear unas tablas con un identificador en cada celda para poder referenciarlas despu�s, para eso, al nombre del 
	// identificador se le agregar� el id del subtema para que cuando se desee eliminar se pueda buscar tambi�n por subtema
    var celda1 = '<td width="60" id="cod_subtema'+contador+'">'+id+'</td>';
	var celda2 = '<td width="205" id="m'+contador+'">'+nom_mat+'</td>';
	var celda3 = '<td width="215" id="t'+contador+'">'+nom_tema+'</td>';	
	var celda4 = '<td width="215" id="s'+contador+'">'+nom_subtema+'</td>';
	var celda5 = '<td width="50" id="p'+contador+'">'+num_preg+'</td>';	
	var celda6 = '<td width="50" id="boton'+contador+'"><input type="button" name="'+contador+id+'" id="'+contador+id+'" value="Eliminar" onClick="eliminar(this)"/></td>';	
	var tabla= '<table border="1"><tr>'+celda1+celda2+celda3+celda4+celda5+celda6+'</tr></table>';
	if (validaDatos(nom_exa)){     //validamos que se halla escrito alg�n dato en el campo usuario
	  // Creo la conexion con el servidor 
       var ajax=nuevoAjax();
	   ajax.open("POST", "crea_prueba.php", true);
	   ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	   //enviamos las variables
	   ajax.send("txt_nom_exa="+nom_exa+" & cbx_subtema="+id_subtema+ "& cbx_numpreg="+num_preg+"& cbx_mat="+id_mat);
		
       ajax.onreadystatechange=function() {
	      if (ajax.readyState==4){

			 divMensaje.innerHTML = resultado+tabla;
	      }
		  else {
			  divMensaje.innerHTML="Error...........";
		  }
	   }
	}
	else { 
	   divMensaje.innerHTML="No ha ingresado un nombre de usuario o ingres� caracteres no validos";
	}
}
//---------------------------------------------------------------------------------------------------------------
//Funci�n que elimina la pregunta seleccionada, adem�s muestra nuevamente las preguntas que no se han eliminado
function elimina_pregunta(id_subtema,tpreg,indice){
 	 var divMensaje=document.getElementById("msjerror");
     var aux=document.getElementById("txt_nom_exa");  
	 var nom_exa= aux.value;   //optenemos el nombre de la prueba
	 
   //id_subtema es igual a numero de bot�n mas el c�digo del del subtema. Ejemplo 2MAT1T1ST1. las siguientes funciones
	 // separan el num. 2 y MAT1T1ST1
	 npreg= id_subtema.charAt(0); // optenemos el primer caracter de la cadena, en este caso optenemos el num. de la preg. eliminada
	 id_subtema= id_subtema.substring(1);  //optenemos el id_subtema sin el n�mero inicial
     tam=indice.length  //obtenemos el num de elementos del arrglo
     //Marcamos en el arreglo el elemento que se elimin� con -1
     for(i=0; i<tam; i++){
	      aux= indice[i];
          if (aux==npreg){
			  indice[i]= -1;
		  }
	  }
 	  tabla='';
	  celda1='';
	  celda2='';	 
	  celda3='';
	  celda4='';
	  celda5='';
	  celda6='';

	 //Creamos nuevamente las tablas con la informaci�n de las preguntas que seleccion� el usuario.. quitando la que elimin�
	 if(tpreg>0){
	    for(var i=0; i<tam; i++){
		    elemento= indice[i];
		    if(elemento != -1){   //Si el elemento en el arreglo no ha sido eliminad...
		       codSubtema = document.getElementById("cod_subtema"+i).innerHTML;	//optenemos el valor (contenido) del objeto
               materia = document.getElementById("m"+i).innerHTML;
	           tema = document.getElementById("t"+i).innerHTML;
	           subtema = document.getElementById("s"+i).innerHTML;
	           preguntas = document.getElementById("p"+i).innerHTML;
		
		   	   celda1= '<td width="60" id="cod_subtema'+i+'">'+codSubtema+'</td>';
			   celda2= '<td width="205" id="m'+i+'">'+materia+'</td>';			
			   celda3= '<td width="215" id="t'+i+'">'+tema+'</td>';
			   celda4= '<td width="215" id="s'+i+'">'+subtema+'</td>';			 
			   celda5= '<td width="50" id="p'+i+'">'+preguntas+'</td>';	
			   celda6= '<td width="50"><input type="button" name="'+i+codSubtema+'" id="'+i+codSubtema+'" value="Eliminar" onClick="eliminar(this)"/></td>';	
	           tabla=tabla+'<table border="1"><tr>'+celda1+celda2+celda3+celda4+celda5+celda6+'</tr></table>';
	        }  //end if
		 }  //end for
	 }
	 else { tabla="No existen preguntas que mostrar"; }

	 var ajax=nuevoAjax();  
	 ajax.open("POST", "elimina_pregunta_prueba.php", true);
	 ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	 //enviamos las variables
	 ajax.send("txt_nom_exa="+nom_exa+" & txt_subtema="+id_subtema);
     ajax.onreadystatechange=function() {
	    if (ajax.readyState==4){
	        divMensaje.innerHTML= tabla;
 	    }
		else {
		    divMensaje.innerHTML="Error...........";
		}
	 }
}	 
//---------------------------------------------------------------------------------------------------------------
function mostrar_prueba()
{
	// Obtengo el div donde se mostraran las advertencias y errores
	var divMenu2=document.getElementById("Menu2");
 
    var cbx_examenes = document.getElementById("cbx_examenes");  //Id de la prueba
	
	//Aqu� obtenemos el valor de las variables	
	var id_prueba = cbx_examenes.options[cbx_examenes.selectedIndex].text;

    if( id_prueba != "") {	
	  // Creo la conexion con el servidor 
       var ajax=nuevoAjax();
	   ajax.open("POST", "obtener_prueabas_generadas.php", true);
	   ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	   //enviamos el id con que se nombr� a los campos de texto (txt_usuario y txt_pass) con los valores asignados 
	   ajax.send("id_prueba="+id_prueba);
		
       ajax.onreadystatechange=function() {
	       if (ajax.readyState==4){
			   divMenu2.innerHTML = ajax.responseText;
	       }
		   else {
			   divMenu2.innerHTML="Error...........";
		   }
	   }
	}
	else { 
	   divMenu2.innerHTML="No ha ingresado un nombre de usuario o ingres� caracteres no validos";
	}
}