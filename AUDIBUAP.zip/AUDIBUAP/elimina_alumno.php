<?php
error_reporting(E_ERROR);
//*********** Funci�n que muestra los mensajes de error *****************************	    
   function mensaje($msj){
	   echo('<html><head>');
          echo('<script language="Javascript" type="text/javascript">'); 
	      echo('function enviar(){');
				echo("document.form.submit();");		  
		    	if($msj==1)  echo("javascript:window.alert('Se Elimin� correctamente el registro');");
				if($msj==2)  echo("javascript:window.alert('Error... No se pudo Eliminar el registro');");
				if($msj==3)  echo("javascript:window.alert('Error... no se pudo optener le Matricula a eliminar');");				

		  echo('}');		
       echo('</script>');
	   echo('</head>');
	   echo("<body onLoad='javascript:enviar();'>");
	      echo('<form name="form" id="form" action="busca_alumno.php"  method="post">');
          echo('</form>');
          echo('</body>');
          echo('</html>');
   }		 
//************************************************************************************
session_start();      /*Se inicia la sesi�n. */
$id_aux=$_POST["id_aux"];
if ($id_aux!='') {
    require("conexion.php");
    $consulta="DELETE FROM alumnos WHERE id_alumno='".$id_aux."';";
	$hacerconsulta=mysql_query($consulta, $link);
	if ($hacerconsulta) mensaje(1);   
    else mensaje(2);   
}
else mensaje(3);
            	
if ($hacerconsulta) {
	mysql_close($link);
   } //cierra la conexion 
?>