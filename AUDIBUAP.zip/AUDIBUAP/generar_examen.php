<?php
error_reporting(E_ERROR);
   session_start();      /*Se inicia la sesi�n. */

?> 

<head>
<title>Crea Examen</title>
<link rel="stylesheet" href="css/estilo_examen.css" type="text/css" media="screen" />
<script language="javascript" src="js/jquery-1.2.6.min.js"></script>
<script type="text/javascript" src="js/addPreguntas.js"></script>

<!--Creamos una variable global que permite verificar si se guarda la prueba o no-->
<script language="javascript">
    //Creamos las isguientes variable globales
    var nn = 0;   //contador de preguntas insertadas
	var indice= new Array();   //arreglo de indices de preguntas insertadas y eliminadas
</script>

<!--------------------------------------------------------------------------------------------------------------------------------------->
<script language="javascript">
$(document).ready(function(){
	// Parametros para e combo1
    $("#cbx_sem").change(function () {
   		                $("#cbx_sem option:selected").each(function () {
				                                           elegido = $(this).val();
				                                           $.post("carga_materias.php", { elegido: elegido, id_materia:''  }, function(data){
				                                                                                       $("#cbx_mat").html(data);
				                                                                                       $("#cbx_tema").html("");
																									   $("#cbx_subtema").html("");
			                                                                                         });			
                                                           });
                          })
	// Parametros para el combo2
	$("#cbx_mat").change(function () {
	                    $("#cbx_mat option:selected").each(function () {
			                                               elegido=$(this).val();
			                                               $.post("carga_temas.php", { elegido: elegido, id_tema:'' }, function(data){
				                                                                                              $("#cbx_tema").html(data);
																											  $("#cbx_subtema").html("");
			                                                                                                 });			
                                                            });
                          })
    
	// Parametros para el combo2
	$("#cbx_tema").change(function () {
	                    $("#cbx_tema option:selected").each(function () {
			                                               elegido=$(this).val();
			                                               $.post("carga_subtemas.php", { elegido: elegido, id_subtema:'' }, function(data){
				                                                                                              $("#cbx_subtema").html(data);
			                                                                                                 });			
                                                            });
                          })
    
	$("#cbx_subtema").change(function () {
	                    $("#cbx_subtema option:selected").each(function () {
			//alert($(this).val());
			                                               elegido=$(this).val();
			                                               $.post("carga_total_subtemas.php", { elegido: elegido }, function(data){
				                                                                                              $("#cbx_numpreg").html(data);
			                                                                                                 });			
                                                            });
                          })
    

});

</script>
<!--************* Esta funci�n verifica que se hayan escrito todos los datos********************-->	  
<script language='Javascript' type='text/javascript'>
  function valida_datos(){
	  var error=false;
	  if(document.getElementById("cbx_sem").value==0){
	     error=true;
         javascript:window.alert('Error... Debe Seleccionar un Semestre');
	  }	 
	  else{ if(document.getElementById("cbx_mat").value==0){
	           error=true;
               javascript:window.alert('Error... Debe Seleccionar una Materia');
			}
			else{ if(document.getElementById("cbx_tema").value==0){
	                 error=true;
                     javascript:window.alert('Error... Debe Seleccionar una Tema');
			      }
			      else{ if(document.getElementById("cbx_subtema").value==0){
	                       error=true;
                           javascript:window.alert('Error... Debe Seleccionar una SubTema');
			            }
			            else{ if(document.getElementById("cbx_numpreg").value==0){
	                             error=true;
                                 javascript:window.alert('Error... Debe Seleccionar al menos una Pregunta');
			                  }
							  else{ if(document.getElementById("txt_nom_exa").value ==''){
	                                   error=true;
                                       javascript:window.alert('Error... Debe escribir un nombre a la Prueba');
								    }
			                  }
						}
				  }
			}
	  }
	  if (!error){
          document.getElementById("txt_nom_exa").disabled=true;//Deshabilitamos el campo tex topara que no modifiquen nombre de la prueba	  
		  javascript:AgregarPregunta(nn); //La sig. funci�n muestra las preguntas que se van eligiendo (est� en ajax)
		  indice[nn]=nn;     //agregamos el indice de la pregunta insertada
  	      nn=nn+1;    //incrementamos el contador de preguntas insertadas
	  }	 
  }   <!-- Fin de la Funci�n-->
 </script>
<!--------------------------------------------------------------------------------------------------------------------------------------->
<!-- Este script se ejecuta al oprimir el boton eliminar que se crea din�micamente -->
<!-- llama a la funci�n elimina_pregunta que se encuentra en addPreguntas.js (Ajax) se le pasan como parametros -->
<!-- el nombre del bot�n que se oprimi� y el n�mero de preguntas que componen la prueba-->
<script language='Javascript' type='text/javascript'>
  function eliminar(objeto){
      var idSubtema= objeto.name;  //Obtenemos el nombre del objeto enviado. En este caso se envi� el id_subtema
      javascript:elimina_pregunta(idSubtema,nn,indice);  //Funci�n en ajax. Enviamos el codigo del subtema a eliminar el num. de preg. de la prueba
	  nn=nn-1;
  }   
</script>

<!-- ********************************************************************************************************************-->
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"></head>

<body>  <!--Si se estan insertando mas preguntas carga los valores --> 
<div  class="Contenedor">
    <form id="form1" name="form1" method="post" accion="menu_opciones.php" >
 <div class="imagen1"><img src="imagenes/EscudoBuap.png" width="67" height="100"></div>
			  <div class="Estilo5">
                <div class="Titulo1">- GENERAR PRUEBA -</div>
			    <div class="Titulo2">SISTEMA WEB DE REACTIVOS PARA EVALUAR EL APRENDIZAJE EN LA EDUCACI�N SUPERIOR</div>
				 <div class="imagen2"><img src="imagenes/dotted_line.png">
			  </div>
    <div class="TituloCeldas">
	  <table border="0">
        <tr>
          <td width="80"><div class="Estilo2"><div align="center">C�digo </div></div></td>
		  <td width="205"><div class="Estilo2"><div align="center">Materia</div></div></td>
		  <td width="215"><div class="Estilo2">
		    <div align="center">�rea </div>
		  </div></td>
		  <td width="215"><div class="Estilo2">
		    <div align="center">Sub�rea </div>
		  </div></td>
		  <td width="50"><div class="Estilo2"><div align="center">Preguntas</div></div></td>
        </tr>
	  </table>
  </div>  
    <div class="error" id="msjerror">&nbsp;</div>
    <div class="Menu"><br>
      <table width="600" height="188"  align="left" cellspacing="0">
        <tr>
          <td width="500" height="30" ><div class="Estilo2">Nombre de la Prueba:</div></td>
          <td width="600"><input name="txt_nom_exa" id="txt_nom_exa" tabindex="1"/></td>
        </tr>
        <tr>
          <td height="30"><div class="Estilo2">Selecciona el nivel: </div></td>
           <td><label>
              <select name="cbx_sem" id="cbx_sem" tabindex="2">
  	  	         <option value="0" selected="selected">Selecciona Nivel</option>
                 <option value="1">Nivel Basico</option>
                 <option value="2">NIvel Formativo</option>
                 <option value="3">NIvel Optativo</option>
            </select>
           </label></td>
        </tr>
        <tr>
          <td height="30"><div class="Estilo2">Selecciona Materia:</div></td>
           <td><label>
              <select name="cbx_mat" id="cbx_mat" tabindex="3">
              </select>
           </label></td>
        </tr>
        <tr>
          <td height="30"><div class="Estilo2">Selecciona el Area: </div></td>
           <td><label>
              <select name="cbx_tema" id="cbx_tema" tabindex="4">
              </select>
           </label></td>
        </tr>
		<tr>
          <td height="30"><div class="Estilo2">Selecciona el Subarea: </div></td>
           <td><label>
              <select name="cbx_subtema" id="cbx_subtema" tabindex="5">
              </select>
           </label></td>
        </tr>
        <tr>
          <td height="36"><div class="Estilo2">Num. de Preguntas:</div></td>
           <td><label>
		       <select name="cbx_numpreg" id="cbx_numpreg" tabindex="6">
               </select>
			  <!--<input name="txt_numpreg" type="text" id="txt_numpreg" />-->
			  </label></td>
        </tr>
      </table>
    <p>&nbsp;</p>
    <div class="Botones1">
      <input name="retorno" type="button" tabindex="8" onClick="location.href='menu_opciones.php';" value="REGRESAR"/>
    </div>  
   <div class="Botones2">
        <input type="button" tabindex=7 name="add" value="Agregar Preguntas" onClick="valida_datos();"/>
   </div>
  
     <!-- Campo oculto que env�a la variable de sesi�n-->
 	 <input type="hidden" name="txt_materia" id="txt_materia">
	 <input type="hidden" name="txt_tema" id="txt_tema">
	 <input type="hidden" name="txt_subtema" id="txt_subtema">
	 <input type="hidden" name="txt_preguntas" id="txt_preguntas">
	 <input type="hidden" name="txt_nom_exa" id="txt_nom_exa" value="">
     <input type="hidden" name="<?php session_name() ?>" value="<?php session_id() ?>">

  </div>
    </form>
</div>
</body>
</html>

