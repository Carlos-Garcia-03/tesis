<?php
error_reporting(E_ERROR);
require_once('phplot-5.5.0/phplot.php');
//Es necesario hacer esto cuando se recibe un arreglo
 $id_subtema = stripslashes($_POST['id_subtema']); 
 $id_subtema = urldecode($id_subtema); 
 $id_subtema = unserialize($id_subtema);


 $calf_subtemas = stripslashes($_POST['calf_subtemas']);
 $calf_subtemas = urldecode($calf_subtemas);
 $calf_subtemas = unserialize($calf_subtemas);
 
 $cont=count($id_subtema);
 //los datos a graficar siempre van en un array de datos de la siguiente manera: array('etiqueta', valorX, valorY)
 for($i=0; $i<$cont; $i++){
     $calif[$i][0] = $id_subtema[$i];  //valor en el eje de las x
     $calif[$i][1]=  $calf_subtemas[$i][0];       //valor en el eje de las y
 }

 $grafica = new PHPlot(1200,600);              //creamos el objeto de la clase PHPlot de 800px de ancho por 600px de alto
 $grafica->SetImageBorderType('plain');      //le asignamos un borde a la grafica
 $grafica->SetPlotType ('bars');                  //el tipo de gr�fica ser� de barras
 $grafica->SetDataType('text-data');         //lo que va a graficar seran datos en los ejes X y Y
 $grafica->SetDataValues($calif);            //le asignamos el array de datos a la grafica
 //$grafica->SetLegend(array('alumnos'));  //Creamos un rotulo de datos
 $grafica->SetTitle('Gr�fica de Aprovechamiento por Subtema');  //le asignamos un titulo a la grafica
 $grafica->SetPlotAreaWorld(0, 0, NULL, 10);        //eje X min=0 y max=Null  eje Y min=0 y el max. =10 si se ponen estos valores en NULL los valores se calculan automaticamente tomando en cuenta los maximos y minimos valores del array
 $grafica->SetXTickLabelPos('none');
 $grafica->SetXTickPos('none');
// $grafica->SetShading(0);
 $grafica->DrawGraph();                          //dibujamos nuestra grafica
?>
<html>
<body>
      <input type="button" name="regresar" id="regresar" value="REGRESAR" onClick="location.href=\'optener_calif.php\';"/>
</body>
</html>