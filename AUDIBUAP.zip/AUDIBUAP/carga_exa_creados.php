<?php
error_reporting(E_ERROR);
    require("conexion.php");
	//busca los nombres de los examenes que coincidan con la materia y los agrupa
	$consulta= 'SELECT id_examen FROM pruebas_generadas 
	            WHERE id_docente = "'.$_POST["id_docente"].'" and id_materia = "'.$_POST["id_materia"].'" GROUP BY id_examen;';
    $hacerconsulta=mysql_query($consulta, $link);
    $rpta="<option value= '0']>Seleccione una Prueba</option>;";
    if ($hacerconsulta) {    //si no hubo error al hacer la consulta
       $n=1;
	   while ($examen=mysql_fetch_array ($hacerconsulta, MYSQL_ASSOC)){
	         $rpta= $rpta.'<option value="'.$examen["id_examen"].'">'.htmlentities($examen["id_examen"]).'</option>';
		     $n=n+1;
	   }
    }
    else {
       $rpta= '<option value="1">error...</option>';
    }  
echo ($rpta);	
?>
