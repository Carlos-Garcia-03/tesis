<?php
error_reporting(E_ERROR);
    require("conexion.php");
    $consulta='SELECT subtema, id_subtema FROM subtemas  WHERE id_tema = "'.$_POST["elegido"].'";';  //busca los temas que coincidan con la materia y los agrupa
    $hacerconsulta=mysql_query($consulta, $link);
    
    $rpta="<option value= '0'>-Seleccione Subtema-</option>;";
    if ($hacerconsulta) {    //si no hubo error al hacer la consulta
	   while ($dato=mysql_fetch_array ($hacerconsulta, MYSQL_ASSOC)){
	       if($dato["id_subtema"]==$_POST["id_subtema"]) {  // opci�n que se mostrar� por defaul en el select
              $rpta= $rpta.'<option value="'.$dato["id_subtema"].'" selected="selected">'.htmlentities($dato["subtema"]).'</option>';
		   }
	       else {
		      $rpta= $rpta.'<option value="'.$dato["id_subtema"].'">'.htmlentities($dato["subtema"]).'</option>';
		   }
	   }
    }
    else {
       $rpta= '<option value="1">error...</option>';
    }  
echo ($rpta);	
?>
