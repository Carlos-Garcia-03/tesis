<?php
error_reporting(E_ERROR);
//*********** Funci�n que muestra los mensajes de error *****************************	    
   function mensaje($msj){
	   echo("<html><head>
             <script language='Javascript' type='text/javascript'>"); 
	             if($msj==1){
				    echo("location.href='busca_usuario.php';");
			        echo("javascript:window.alert('No se encontr� ningun registro');");
				 }
				 if($msj==2){
				    echo("location.href='busca_usuario.php';");
			        echo("javascript:window.alert('Error... Algunos campos no contienen informaci�n');");
				 }
       echo("</script>
		     </head>
		     </html>");
   }		 
//*********************************************************************************************************+
    session_start();      /*Se inicia la sesi�n. */
	$id_alumno= $_POST['txt_id'];
	require("conexion.php");
    $consulta="SELECT * FROM alumnos WHERE id_alumno= '".$id_alumno."';";      
    $hacerconsulta=mysql_query($consulta, $link);
	if ($hacerconsulta) {
	   while ($dato= mysql_fetch_array ($hacerconsulta, MYSQL_ASSOC)){
	          $nom= $dato["nombre"];
		      $ap_paterno= $dato["ap_paterno"];
			  $ap_materno= $dato["ap_materno"];
			  $mat= $dato["id_alumno"];
			  $sem= $dato["semestre"];
			  $gpo= $dato["grupo"];
			  $pass= $dato["password"];
	   }
	    echo("<html>");
        echo("<head>");
        echo('<script language="javascript" type="text/javascript">');
              /* La siguiente funci�n, que se ejecuta cuando se carga la p�gina, llama a la primera
                 p�gina de contenidos, pas�ndole, como campo oculto, la constante de identificaci�n de la sesi�n. */
              echo("function mandar(){");
                  echo("document.f0.submit();");
              echo("}");
           echo("</script>");
		echo("<head>");
        echo("<!-- Hacemos que, a la carga de la p�gina, se envie un campo oculto con la constante PHPSESSID -->");
        echo('<body onLoad="javascript:mandar();">');
        echo('<!-- El formulario contiene la constante PHPSESSID en un campo oculto. -->');
        echo('<form name="f0" id="f0" method="post" action="ficha_alumnos.php">');
        echo('<input type="hidden" name="'.session_name().'" value="'.session_id().'">');
		echo('<input type="hidden" name="reg_nombre" id="reg_nombre" value="'.$nom.'">');
		echo('<input type="hidden" name="reg_appaterno" id="reg_paterno" value="'.$ap_paterno.'">');
		echo('<input type="hidden" name="reg_apmaterno" id="reg_apmaterno" value="'.$ap_materno.'">');
		echo('<input type="hidden" name="reg_matricula" id="reg_matricula" value="'.$id_alumno.'">');
		echo('<input type="hidden" name="cbx_semestre" id="cbx_semestre" value="'.$sem.'">');
		echo('<input type="hidden" name="cbx_grupo" id="cbx_grupo" value="'.$gpo.'">');
		echo('<input type="hidden" name="reg_pass" id="reg_pass" value="'.$pass.'">');
        echo(" </form>");
        echo("</body>");
	    echo("</html>");
     }
    else { mensaje(1);   }  
?>
