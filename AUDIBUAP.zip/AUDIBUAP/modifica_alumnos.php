<?php
//+++++++++++++++++++++++  Esta ventana es llamada por registro_docentes.php y por registro_alumnos.php +++++++++++++++++

//*********** Funci�n que muestra los mensajes de error *****************************	    
  error_reporting(E_ERROR);
   function mensaje($msj,$opcion,$sem,$gpo){
	   echo('<html><head>');
          echo('<script language="Javascript" type="text/javascript">'); 
	      echo('function enviar(){');
				echo("document.form.submit();");		  
		    	if($msj==1)  echo("javascript:window.alert('Se Modificaron correctamente los datos');");
				if($msj==2)  echo("javascript:window.alert('Error... Es posible que ya exista esta matr�cula');");
				if($msj==3)  echo("javascript:window.alert('Error... Algunos campos no contienen informaci�n');");				

		  echo('}');		
       echo('</script>');
	   echo('</head>');
	   echo("<body onLoad='javascript:enviar();'>");
          if ($opcion==2)   echo('<form name="form" id="form" action="busca_alumno.php"  method="post">');
	      echo('</form>');
          echo('</body>');
          echo('</html>');
   }		 
//************************************************************************************
session_start();      /*Se inicia la sesi�n. */
$id_nueva= $_POST["txt_id"];
$nombre= $_POST["txt_nom"];
$appaterno=$_POST["txt_appaterno"];
$apmaterno= $_POST["txt_apmaterno"];
$id_aux=$_POST["id_aux"];
$pass= $_POST["txt_pass"];
$semestre= $_POST["cbx_sem"];
$grupo= $_POST["cbx_grupo"];
//Las siguientes dos variables sirven para que al regresar a la pagina:busca_por_sem.php busque nuevamente la informacion solicitada
    require("conexion.php");
   	if ($id_nueva != "" and $appaterno != "" and $apmaterno != "" and $nombre != "" and
	    $pass != "" and $id_aux != '' and $semestre != "" and    $grupo != "" ){
        $consulta="UPDATE alumnos SET  id_alumno= '".$id_nueva."',ap_paterno= '".$appaterno."', ap_materno= '".$apmaterno."',
	              nombre= '".$nombre."', semestre= '".$semestre."', grupo= '".$grupo."', password= '".$pass."'
	              WHERE  id_alumno='".$id_aux."';";
	    $hacerconsulta=mysql_query($consulta, $link);
	    if ($hacerconsulta) mensaje(1,$_SESSION["opcion"],$d_sem,$d_gpo);   
		else  mensaje(2,$_SESSION["opcion"],$d_sem,$d_gpo);   
	}
    else mensaje(3,$_SESSION["opcion"],$d_sem,$d_gpo);   
				         	
if ($hacerconsulta) {mysql_close($link);   } //cierra la conexion 
?>