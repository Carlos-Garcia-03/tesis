<html>
<head>
<title>Editar Alumnos</title>
<style type="text/css">
<!--
body,td,th {
	color: ;
	font-size: 12px;
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
.tabla {
	font-size: 14px;
	color: #000FFF;
	font-style: normal;
	font-family: Verdana, Arial, Helvetica, sans-serif;
	height: 200px;
	overflow: scroll;
	position: absolute;
	top: 20px;
}
-->
</style>

<script language='Javascript' type='text/javascript'>
<!-- La siguiente funci�n optienen el nombre del bot�n que se oprimi� y se lo asigna a una variable para que se env�ecomo campo oculto-->
  function valida(objeto){
     document.getElementById("nom_btn").value = objeto.name;
     document.form.submit();    <!-- se env�a el formulario-->
  }   <!-- Fin de la Funci�n-->
</script>
<!--****************************************************************************************--> 
</head>
<?php
error_reporting(E_ERROR);
   session_start();      /*Se inicia la sesi�n. */
   $sem= $_GET["cbx_semestre"];
   $gpo= $_GET["cbx_grupo"];
?>
<body>
   <form name="form" id="form" method="post" action="">  
<?php
   require("conexion.php");
   $consulta="SELECT * FROM alumnos WHERE semestre = '".$sem."' and grupo= '".$gpo."';";  
   $hacerconsulta=mysql_query($consulta, $link);
   if ($hacerconsulta) {
		$prog =1;  //N�mero progresivo
		$i=0;
		echo('<div class="tabla">');
		echo('<table border="1" cellspacing="0">
		       <tr>
                 <td width="60"> N�MERO</td>  
			     <td width="100"> MATR�CULA</td>
			     <td width="150">AP. PATERNO</td>
			     <td width="150">AP. MATERNO</td>							
  		  	     <td width="170">NOMBRE</td>
	  		     <td width="150">CONTRASE�A</td>
			     <td width="80">&nbsp;</td>		
               </tr>
			 ');
		  while($datos= mysql_fetch_array ($hacerconsulta, MYSQL_ASSOC)){ 							 
		     echo("<tr>");
               echo("<td align='center'>".$prog."</td>");
			   echo("<td id='a".$i."' align='center'>".$datos["id_alumno"]."</td>");
			   echo("<td id='b".$i."'>".$datos["ap_paterno"]."</td>");
			   echo("<td id='c".$i."'>".$datos["ap_materno"]."</td>");
			   echo("<td id='d".$i."'>".$datos["nombre"]."</td>");										
			   echo("<td id='e".$i."'>".$datos["password"]."</td>");
 			   echo("<td align='center'>
			         <input type='button' name='".$i."' id='".$i."' value='Editar' onClick='valida(this)'/>
					  </td>");//crea bot�n modificar
             echo("</tr>");
			 $i+=1;
             $prog +=1;
		  }
     	  echo("</table>");  
    echo(' 
	  <input type="hidden" name="'.session_name().'" value="'.session_id().'">
      </form>
	  </div>
    ');
    }  //Fin if externo
    else{ echo("No se encontro ning�n registro"); }
?>
</body>
</html>	 