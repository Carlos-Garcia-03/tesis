<?php
error_reporting(E_ERROR);
    session_start();
	//verificamos que se halla accesado desde la pagina de ingreso (verificamos que exista alguna variable de sesi�n)
		if (!isset($_SESSION["S_idDocente"])){
?>
       <script languaje="javascript" type="text/javascript">
           location.href="index.php";
       </script>
<?php
    }
  //Si existe la variable de sesi�n entonces se ejecuta el c�digo
  else{
      if ($_SESSION["privilegio"]==3){       //verificamos si cuenta con los privilegios para ingresar alumnos
?>
<html>
<head>
<title>Alta de Alumnos</title>
<link rel="stylesheet" href="css/estilo_gral.css" type="text/css" media="screen" />

<script language='Javascript' type='text/javascript'>
<!--************* Esta funci�n verifica que se hallan escrito todos los datos********************-->	  
  function valida_datos(){
	  var error=false;
	  if(!document.getElementById("txt_appaterno").value){
	     error=true;
         javascript:window.alert('Error... Debe escribir el APELLIDO PATERNO del alumno');
	  }	 
	  else{ if(!document.getElementById("txt_apmaterno").value){
	           error=true;
               javascript:window.alert('Error... Debe escribir el APELLIDO MATERNO del alumno');
			}   
		    else{ if(!document.getElementById("txt_nom").value){
			         error=true;
                     javascript:window.alert('Error... Debe escribir el NOMBRE del alumno');
				  }
				  else{ if(!document.getElementById("txt_id").value){
				           error=true;
                           javascript:window.alert('Error... Debe escribir la MATR�CULA del alumno');
						}
						else{ if(document.getElementById("cbx_sem").value==0){
				                 error=true;
                                 javascript:window.alert('Error... Seleccione el SEMESTRE del alumno');
						      }
						      else{ if(document.getElementById("cbx_grupo").value==0){
				                       error=true;
                                       javascript:window.alert('Error... Seleccione el GRUPO del alumno');
						            }   
						            else{ if(!document.getElementById("txt_pass").value){
						                     error=true;
                                             javascript:window.alert('Error... Debe escribir la CONTRASE�A del alumno');
										  }
									}	  
							  }	 
						}
				  }
			}  		 
	  }
	  if (!error) document.form.submit();    <!-- Si se escribieron todos los datos se env�a el formulario-->
  }   <!-- Fin de la Funci�n-->
</script>	
<!-- **Esta funcion se ocupa cuando se editan datos************************************************-->
<script language='Javascript' type='text/javascript'>
function cargaDatos(){
    id_alumno= '<?php echo($_POST['reg_matricula']);?>';
    if (id_alumno == ''){
	   window.alert('No se encontr� ning�n registro');
	}
	else{
      document.getElementById("txt_nom").value="<?php echo($_POST['reg_nombre']); ?>";
	  document.getElementById("txt_appaterno").value="<?php echo($_POST['reg_appaterno']); ?>";
	  document.getElementById("txt_apmaterno").value="<?php echo($_POST['reg_apmaterno']); ?>";
	  document.getElementById("txt_id").value="<?php echo($_POST['reg_matricula']); ?>";
	  document.getElementById("txt_pass").value="<?php echo($_POST['reg_pass']); ?>";
	  document.getElementById("cbx_sem").value= "<?php echo($_POST['cbx_semestre']); ?>";
	  document.getElementById("cbx_sem").selected="selected";
	  document.getElementById("cbx_grupo").value= "<?php echo($_POST['cbx_grupo']); ?>";
	  document.getElementById("cbx_grupo").selected= "selected";
	}  
}
</script>
<!--++++++++++++  Esta funci�n confirma si se desea eliminar el registro ++++++++++++++++++++++++++++-->
<script language='Javascript' type='text/javascript'>
function eliminar(){
    if (confirm('Confirme que desea ELIMINAR el registro')){
       document.form2.submit()
    }
}
</script> 
<!--****************************************************************************************************************-->
</head>
<?php
    $opcion= $_SESSION["opcion"];   //Recuperamos la variable de sesi�n
    //Verificamos que se va a realizar. 1 para INSERTAR usuarios y 2 para EDITAR sus datos
    if($opcion == 1) echo("<body>");   
	if($opcion == 2) echo("<body onLoad='javascript:cargaDatos();'>");   //Carga los datos que se van a modificar
?>    
<div class="Contenedor">
    <?php  if($opcion == 1) { ?>  
	          <div class="imagen1"><img src="imagenes/EscudoBuap.png" width="67" height="100"></div>
			  <div class="Estilo5">
                <div class="Titulo1">- ALTA DE ALUMNOS -</div>
			    <div class="Titulo2">SISTEMA WEB DE REACTIVOS PARA EVALUAR EL APRENDIZAJE EN LA EDUCACI�N SUPERIOR</div>
				 <div class="imagen2"><img src="imagenes/dotted_line.png">
			  </div>
    <?php  }  ?>	  
	<?php  if($opcion == 2) { 
	          echo('
			   <div class="imagen1"><img src="imagenes/EscudoBuap.png" width="67" height="100"></div>
		
                <div class="Titulo1">- ALTA DE ALUMNOS -</div>
			    <div class="Titulo2">SISTEMA WEB DE REACTIVOS PARA EVALUAR EL APRENDIZAJE EN LA EDUCACI�N SUPERIOR</div>
				 <div class="imagen2"><img src="imagenes/dotted_line.png"></div>
				   ');
		   }
	 ?>
	<div class="Bloque1">
    <?php
      if($opcion == 1) echo('<form name="form" id="form" action="inserta_alumnos.php"  method="post">');
      if($opcion == 2) echo('<form name="form" id="form" action="modifica_alumnos.php"  method="post">');   
    ?>   
      <table width="664" border="0" align="center">	  
	    <tr>
          <td width="203" height="23" align="center"><div class="Estilo3">Apellido Paterno</div></td>
	      <td width="225" align="center"><div class="Estilo3">Apellido Materno</div></td>
	      <td width="191" align="center"><div class="Estilo3">Nombre</div></td>
	    </tr>
	    <tr>
          <td width="203" height="33" align="center"><div class="Estilo4">
           <input name="txt_appaterno" type="text1" id="txt_appaterno" />
          </div></td> 
          <td width="225" align="center"><div class="Estilo4">
            <input name="txt_apmaterno" type="text1" id="txt_apmaterno"/></div></td> 		 
          <td wio90ldth="191" align="center"><div class="Estilo4">
            <input name="txt_nom" type="text1" id="txt_nom" value=""/></div></td> 		  		 
        </tr>
      </table>
      <p>&nbsp;</p>
      <div class="centra_contenido">
	  <table width="626"  border="0" align="center">	  
	    <tr>
          <td width="172" height="23" align="center"><div class="Estilo3">Matr&iacute;cula</div></td>
	      
	      <td width="100" align="center"><div class="Estilo3">Nivel</div></td>
          <td width="165" align="center"><div class="Estilo3">Area</div></td>
		  <td width="165" align="center"><div class="Estilo3">Contrase&ntilde;a</div></td>
	    </tr>
	    <tr>
          <td width="172" height="33" align="center"><div class="Estilo4">
            <input name="txt_id" type="text" id="txt_id" /></div></td> 
           		 
          <td width="106" align="center">
		    <select name="cbx_grupo" id="cbx_grupo">
			   <option value="0" selected="selected">---</option>
               <option value="BASICO">B�sico</option>
               <option value="FORMATIVO">Formativo</option>
			   <option value="OPTATIVO">Optativo</option>
            </select> </td> 
            <td width="165" align="center"><div class="Estilo4">
		    <select name="cbx_sem" id="cbx_sem">
			   <option value="0" selected="selected">-seleccione una Area-</option>
               <option value="1">�rea 1</option>
               <option value="2">�rea 2</option>
               <option value="3">�rea 3</option>
               <option value="4">�rea 4</option>
               <option value="5">�rea 5</option>
            
            </select></div></td>		  		 
		  <td width="165" align="center"><div class="Estilo4">
	        <input name="txt_pass" type="text" id="txt_pass" /></div></td> 
	    </tr>
      </table>
      </div>
      <div class="botones">
	  <table height="46" align="center" border="0">
        <tr>
          <td width="90"  align="center">
<?php		
             if($opcion == 1) echo("<input type='button' name='btn_guardar' id='btn_guardar' value='GUARDAR'  onClick='valida_datos();'/>");
	         if($opcion == 2) 
			    echo("<input type='button' name='btn_guardar' id='btn_guardar' value='MODIFICAR' onClick='valida_datos();'/>");
?>			   
		  </td>
<?php
    	     if($opcion == 2){
?>
                <td width="70" align="center">
			       <input type="button" name="btn_eliminar" id="btn_eliminar" value="ELIMINAR" onClick="eliminar();"/>
			    </td>		    
<?php
		}
?>		   
        <td width="90" align="right">
<?php   
    //Regresa a la p�gina que llam� es esta p�gina
	   if ($opcion == 1){   // Opcion=1 entonces la llam� la p�gina menu_opciones.php
		    echo('<input type="button" name="regresar" id="regresar" value="REGRESAR" onClick="location.href=\'menu_opciones.php\';"/>');
	   }
	   if ($opcion == 2){   // Opcion=2 entonces la llam� la p�gina buscar_usuario.php
		   echo('<input type="button" name="regresar" id="regresar" value="REGRESAR" onClick="location.href=\'busca_alumno.php\';"/>');
	   }
?>	
        </td>
       </tr>
     </table>
</div>
<?php	 
//+++++++++++++++++++ campos ocultos *********************************************************************************************************+	  
	 if($opcion == 1){
	      echo('<input type="hidden" name="'.session_name().'" value="'.session_id().'">');
	 }
     if($opcion == 2){
	     echo('<input type="hidden" name="id_aux" id="id_aux" value="'.$_POST['reg_matricula'].'"/>');  //respaldamos la matricula por si se cambia 
         echo('<input type="hidden" name="'.session_name().'" value="'.session_id().'">');
     }
?>	 
    </form>
	<!--Este formulario se ejecuta s�lo cuando se oprime el bot�n de eliminar --> 
	<form name="form2" id="form2" action="elimina_alumno.php"  method="post">
	<!--enviamos la matricula de respaldo por si se cambi�--> 
	   <input type="hidden" name="id_aux" id="id_aux" value="<?php echo($_POST['reg_matricula']);?>"/>
	   <input type="hidden" name="'.session_name().'" value="'.session_id().'">
	</form>
  </div>  <!--Fin Bloque1-->
</div>  
<!--Fin Contenedor--> 
</body>
</html>
<?php
    }  //If que se encuentra dentro del else del inicio
	else{
	    echo('....NO tiene los suficientes privilegios para ver esta p�gina.....');
	    echo('<a href="menu_opciones.php">regresar</a>');
    }
 }  //Fin del else que se encuentra al principio
?>
