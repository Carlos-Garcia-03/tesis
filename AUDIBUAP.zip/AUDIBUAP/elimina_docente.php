<?php
error_reporting(E_ERROR);
//*********** Funci�n que muestra los mensajes de error *****************************	    
function mensaje($msj){
   echo('
	         <html>
             <head>
                <script language="javascript" type="text/javascript">
                   function mandar(){        /* La siguiente funci�n se ejecuta cuando se carga la p�gina */
	   ');
				     if($msj==1) echo("javascript:window.alert('El registro se ELIMIN� correctamente')");
                     if($msj==2) echo("javascript:window.alert('Error... No se fue posible eliminar el registro');");
				 	 if($msj==3) echo("javascript:window.alert('Error... la variable matr�cula no tiene informaci�n');");
       echo('
	                 document.f0.submit();
                   }
                </script>
		     </head>
		     <body onLoad="javascript:mandar();">
                 <form name="f0" id="f0" method="post" action="busca_docente.php">
                      <input type="hidden" name="'.session_name().'" value="'.session_id().'">
                 </form>
			 </body>
 		     </html>");
		');
}		 
//************************************************************************************ 
$id_nueva= $_POST["txt_id"];
$id_aux=$_POST["id_aux"];

if ($id_aux!='') {
    require("conexion.php");
    $consulta="DELETE FROM docentes WHERE  id_docente='".$id_aux."';";
	$hacerconsulta=mysql_query($consulta, $link);
	if ($hacerconsulta) mensaje(1);   
    else mensaje(2);   
}
else mensaje(3);
            	
if ($hacerconsulta) {
	mysql_close($link);
   } //cierra la conexion 
?>
