<html>
<head>
<title>AUDIBUAP</title>
<link rel="stylesheet" href="css/estilo_ingreso.css" type="text/css" media="screen" />
<SCRIPT Language=Javascript SRC="js/validacampo.js"></SCRIPT>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
</head>
 
<body>

<header>          
    <a class="logo" href="www.buap.com.mx"> <img src="http://www.dci.buap.mx/sites/all/themes/plantilla_1/images/escudo_blanco.png" alt="">
    </a>       
                
    <nav>        
	    <form id="form1" name="formmethod="posaction="valida_pass.php">              
            <input class="inputText" name="txt_usuario" type="text" id="txt_usuario" placeholder="Matrícula de Usuario" />
            <input class="inputText" name="txt_pass" type="password" id="txt_pas" placeholder="Contraseña" />
                <a href="#">¿Olvidaste tu contraseña?</a><br>	
            <input class="inputRadio" name="tusuario" id="tusuario" type="radio" value=1/> <label for="">Coordinador</label>
            <input class="inputRadio" name="tusuario" id="tusuario" type="radio" value=2 checked/> <label for="">Alumno</label>
            <input class="btnIngresar" name="btn_aceptar" type="button" id="btn_aceptar" value="Ingresar" onClick="javascript:valida_campos();"/>
                  
                 		    
	   </form>	
    </nav>
</header>

  
</body>
</html>