<?php
error_reporting(E_ERROR);
    session_start();
	//verificamos que se halla accesado desde la pagina de ingreso (verificamos que exista alguna variable de sesi�n)
	if (!Session_is_registered("S_idDocente")){
?>
       <script languaje="javascript" type="text/javascript">
           location.href="index.php";
       </script>
<?php
    }
  //Si existe la variable de sesi�n entonces se ejecuta el c�digo
  else{

?>

<html>
<head>
<link rel="stylesheet" href="css/estilo_listado.css" type="text/css" media="screen" />
<style type="text/css">
<!--
body,td,th {
	color: #000099;
}
.contenedor{
	position: relative;
	height: 600px;
	width: 1150px;
	left: 100px;
	top: 0px;
}
.Estilo1 {
	font-size: 20px;
	text-align: center;
	color: #000066;
	background-repeat: no-repeat;
	font-style: normal;
	border-left-color: #000066;
	font-family: Verdana, Arial, Helvetica, sans-serif;
	width: 1100px;
	float: right;
	position: absolute;
	left: 10px;
	top: 80px;
	overflow: scroll;
	height: 450px;
	background-color: #FFFFFF;
}
.titulo {
	font-size: 18px;
	text-align: left;
	color: #FFFFFF;
	font-style: normal;
	font-family: Verdana, Arial, Helvetica, sans-serif;
	width: 1100px;
	position: absolute;
	top: 0px;
	height: 80px;
	background-color: #000066;
	left: 10px;
}
#botones{
	position: absolute;
	left: 446px;
	bottom: 7px;
	height: 57px;
	width: 206px;
}
body {
	background-color: #C4D7D5;
}

-->
</style>
<!--+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++---> 
<script language='Javascript' type='text/javascript'> 
   function regresar(){
	       location.href="menu_opciones.php?<?php echo(session_name());?>=<?php echo(session_id()); ?>";
	   }
</script>  
<!--+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++--->  
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"></head>

<?php
    //Se reciben las variables
	$semestre= $_POST["cbx_sem"];
	$id_examen= $_POST["cbx_examenes"];
	$nom_materia= $_POST["nom_materia"];		   
	$grupo= $_POST["cbx_grupo"];
	
	$condicion = "WHERE semestre=".$semestre." and grupo = '".$grupo."'";
	if( $semestre==9) $condicion= '';
   	$expresion= "SELECT * FROM alumnos ".$condicion." ORDER BY semestre,grupo,ap_paterno;";
	require("conexion.php");
	$consulta= $expresion;
	$hacerconsulta=mysql_query($consulta, $link);
	if ($hacerconsulta) {
		$cont= 0;   //Inicializamos el indice que identificaran a los chebox de los usuario
?>		
      <body>
     	<div class="contenedor">
		  <div class="titulo" align="center">
 	          <p>Examen Asignado: <?php echo($id_examen); ?></p>
	          <p>Materia: <?php echo($nom_materia); ?></p>
		  </div>
		  <form name='form1' id='form1' method='post' action='insertar_prueba_asignada.php'>
		  <div class="Estilo1"> 
<?php			  
	    $sem= 0;  //Se inicializa la var $sem -semestre- con un n�mero distinto de 1,2,3,..8
		$grupo= 'Z';  //Se inicializa la var $grupo con un grupo distinto a "A" o "B"
		$cierra_tabla= false;
		$alumnos=array(); //arreglo que almacena la matr�cula (id) de los usuarios
		while($datos= mysql_fetch_array ($hacerconsulta, MYSQL_ASSOC)){ 
           //Se muestran el semestre, grupo y los encabezados de las tablas		
            if ($datos['semestre'] !== $sem or $datos['grupo'] != $grupo){    //Ingresa s�lo cuando se cambia de semestre o grupo
		        if ($cierra_tabla) { 
				    echo("</table>"); 
				} //Cierra las tablas intermedias 
?>	
			       <table width='1000' align='center'>
			          <tr>
			             <td align='center'><div class='fondo1'><p>SEMESTRE: <?php echo($datos['semestre']) ?></p></div></td>
			          </tr>
		              <tr>
			             <td align='left'><div class='fondo1'><p>GRUPO: <?php echo($datos['grupo']) ?></p></div></td>
			          </tr>
			       </table>
   			       <table width='1000' align='center' border='1'>
				      <tr align='center' bgcolor=''>
                        <td width='100'>N�MERO</td>
			            <td width='200'>MATR�CULA</td>
			            <td width='170'>AP. PATERNO</td>
			  		    <td width='170'>AP. MATERNO</td>
  		  	            <td width='170'>NOMBRE</td>
	  		            <td width='50'>ASIGNAR</td>
                      </tr>
<?php
			  $sem = $datos['semestre'];
			  $grupo = $datos['grupo'];
			  $prog =1;  //inicializamos el N�mero progresivo
			  $cierra_tabla= true;						 
		    } //If	
?>
	        <tr>
               <td align='center' width='100'><?php echo($prog) ?></td>
		       <td align='center' width='200'><?php echo($datos["id_alumno"]) ?></td>
		       <td width='170'><?php echo($datos["ap_paterno"]) ?></td>
               <td width='170'><?php echo($datos["ap_materno"])  ?></td>
		       <td width='170'><?php echo($datos["nombre"]) ?></td>
		       <td width='50' align ="center"><input type="checkbox" name=" <?php echo('c'.$cont) ?>" id= "<?php echo('c'.$cont) ?>" value="1"></td>
            </tr>
<?php 
		   $alumnos[$cont]= $datos["id_alumno"];  //Se almacena la matr�cula(id) del usuario
		   $prog +=1;
		   $cont +=1;
		}  //del while  
    	echo("</table>");  //Cierra la �ltima tabla que se crea
		 //Para poder mandar el arreglo es necesario aplicarle estas 2 funciones;
         $alumnos = serialize($alumnos); 
         $alumnos = urlencode($alumnos); 
?>
       </div>  <!--Estilo1-->
	   <div id='botones'>
		 <table width="195" height="54">
		   <tr>
             <td align='center'><input type='submit' name='btn_asignar' value='ASIGNAR'></td>
		     <td align='center'><input type='button' name='retorno' id='retorno' value='REGRESAR' onClick='javascript:regresar();'/></td>
		   </tr>
		 </table>
	   </div>
	       <input type='hidden' name='id_examen' id='id_examen' value='<?php echo($id_examen) ?>'>
           <input type='hidden' name='alumnos' id='alumnos' value='<?php echo($alumnos) ?>'>
           <input type='hidden' name='num_reg' id='num_reg' value='<?php echo($cont) ?>'>
		   <input type="hidden" name="'.session_name().'" value="'.session_id().'">
	    </form>
	  </div>   <!--contenedor-->
	</body>
	</html>
<?php
     }  //if externo
	 else {
	       echo('
		         <html>
		         <body>
		           <p>No se encontro ning�n registro</p>
			     </body>
				 </html>
		   ');
	 }		   
			   
  } //end if inicial
?>


