<?php
error_reporting(E_ERROR);
     session_start();      /*Se inicia la sesi�n. */
?>	 

<html>
<head>
<title>Selecciona examen</title>
<link rel="stylesheet" href="css/estilo_examen2.css" type="text/css" media="screen" />


<script language="javascript" src="js/jquery-1.2.6.min.js"></script>
<script>
<!--*******************Protejemos el codigo para que no se muestre si no tienen javascript*****************-->
<!-- *************** Carga el combo con los examenes asignados a el alumno********************************************-->
   function carga_prueba(){
        elegido = "<?php echo($_SESSION["S_idAlumno"]); ?>";  
	    $.post("carga_pruebas.php", { elegido: elegido }, function(data){
	                                                                $("#cbx_examenes").html(data);
	                                                                        });			
   }
</script>

<!--************************************************************************************-->
<script language='Javascript' type='text/javascript'>
   function cargaVariables(){	
	  document.getElementById("contestarExa").value= 1;   <!-- campo oculto..le asignamos 1=permitir se envie examen contestado-->
      document.form1.submit();    <!-- se env�a el formulario-->
   }	  
</script>
<!--************************************************************************************-->
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"></head>

<body onLoad="carga_prueba()">
<div class="Contenedor">
  <div class="imagen1"><img src="imagenes/EscudoBuap.png" width="67" height="100"></div>
			  <div class="Estilo5">
                <div class="Titulo1">- AGREGAR �REAS -</div>
			    <div class="Titulo2">SISTEMA WEB DE REACTIVOS PARA EVALUAR EL APRENDIZAJE EN LA EDUCACI�N SUPERIOR</div>
				 <div class="imagen2"><img src="imagenes/dotted_line.png">
			  </div> 
   <div class="Estilo1">
<!--   <form id="form1" name="form1" method="post" action="guarda_var.php">-->
   <form id="form1" name="form1" method="post" action="prueba_generada.php">
   <table width="435">
      <tr>
        <td height="73" align="center"><div class="Estilo4">Seleccione el Examen que desea presentar</div></td>
	  </tr>
	  <tr>
	     <td height="34" align="center">
		   <select name="cbx_examenes" id="cbx_examenes">
           </select></td>
	  </tr>
	  <tr>
        <td height="94" align="left" valign="bottom">
		 <input type="button" name="btn_enviar" id="btn_enviar" value="ACEPTAR" onClick="javascript:cargaVariables();" /></td>
	  </tr>
   </table>
     <input type="hidden" name="contestarExa" id="contestarExa" value="">
	 <input type="hidden" name="<?php echo (session_name()); ?>" value="<?php echo (session_id()); ?>">
   </form>
</div> <!-- Fin Estilo1-->
</div>
</body>
</html>
