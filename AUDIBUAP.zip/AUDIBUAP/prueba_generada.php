<?php
error_reporting(E_ERROR);
               /*Para acceder a los elementos de la matriz de registros optenidos empleamos los siguientes argumentos
		       MYSQL_ASSOC: Cada elemento de la matriz se identifica por el nombre del campo
			   MYSQL_NUM: Cada elemento de la matriz se identifica por el n�mero, empezando desde cero
			   MYSQL_BOTH: Se puede acceder por el �ndice o el nombre del campo, indistintamente */
  
  session_start();      /*Se inicia la sesi�n. */
 //Recuperamos las variables
  $id_examen= $_POST["cbx_examenes"];  //contiene el id del examen abuscar
  $preg_prueba= array(array());   //inicializamos el arreglo para almacenar las preguntas que contendr� la prueba

  require("conexion.php");
  //Buscamos todos los subtemas y el n�mero de preguntas que conforman la prueba
  $consulta="SELECT id_subtema,total_preg FROM pruebas_generadas WHERE id_examen= '".$id_examen."';";     
  $hacerconsulta= mysql_query($consulta, $link);
  if ($hacerconsulta) {   
      $d = 0; 	  //inicializamos el Indice del arreglo $preg
	  //Recuperamos los datos de los registros encontrados
	  $preg_encontradas= array(array());   //inicializamos el arreglo para almacenar todas las preguntas encontradas del subtema 
	  while($datos= mysql_fetch_array ($hacerconsulta, MYSQL_ASSOC)){ 
            //Buscamos todas las preguntas del subtema 	  
            $consulta_2 = "SELECT * FROM banco_reactivos WHERE id_subtema = '".$datos["id_subtema"]."';";    
	        $hacerconsulta_2= mysql_query($consulta_2, $link);
		    if ($hacerconsulta_2) { 
		        $i = 0;
                //recuperamos los datos de los registros encontrados 
		        while($datos2=mysql_fetch_array ($hacerconsulta_2, MYSQL_NUM)){  //recuperamos los registros encontrados
	                  $preg_encontradas[$i]= $datos2;
				      $i+=1;
		        }
			    $total_preg_encontradas= count($preg_encontradas);
			    if ($total_preg_encontradas >= $datos["total_preg"]){  //Verificamos que no se hayan escogido m�s preguntas de las que existen en BD
			        shuffle ($preg_encontradas); //Mueve de lugar los elementos del arreglo de forma aleatoria  
			        //Escojemos del arreglo s�lo el n�mero de preguntas solicitadas
			        for ($j=0; $j<$datos["total_preg"]; $j+=1){      
			             $preg_prueba[$d]= $preg_encontradas[$j];
				         $d=$d+1;
			        }
			        unset($preg_encontradas);   //destruimos el arreglo para evitar que en la proxima iteraci�n tenga datos 
				 //   $preg_encontradas= array_values($preg_encontradas);  //indexamos nuevamente el arreglo
			        unset($datos2);   //destruimos el arreglo
				   // $datos2= array_values($datos2);  //indexamos nuevamente el arreglo
			        unset($hacerconsulta_2);
			        $preg_encontradas = array();
			        $datos2=array();
			        $hacerconsulta_2=array();
			    }
		    } 
       } //while
	//El if del inicio se cierra hasta el final del c�digo
?>
<html>
<head>
<link rel="stylesheet" href="css/estilo_prueba.css" type="text/css" media="screen" />

<!--************* Esta funci�n verifica que se hayan escrito todos los datos********************-->	  
<script language='Javascript' type='text/javascript'>
   function valida_datos(tope){
      var error= true;
	  var huboError= false;
	  for( var i=1; i<=tope; i++){   
         for( var j=0; j<4; j++){   
              var radio= document.form1["rbtn_opcion"+i][j]; <!-- Es la forma de crear variables de variables ** form1["rbtn_opcion"+i] es decir hay que poner la variableentre corchetes**-->       
			  if(!radio.checked) {error=true;}
			  else  {
			     error= false;
			     j=4;  <!-- si la pregunta se contest� j=4 para que salga del for-->
			  }
		 }
		 if(error) huboError=true;   <!-- evita que se dejen preguntas intermedias sin contestar-->
	  }			
	  if(huboError) javascript:window.alert('Error... Existen preguntas que no han sido contestadas');
     
	  if (!huboError){
	     document.form1.submit();    <!-- Si se escribieron todos los datos se env�a el formulario-->
	  }  	 
  }   <!-- Fin de la Funci�n-->
 </script>
 <!--++++++++++++  Esta funci�n confirma si se desea eliminar el registro ++++++++++++++++++++++++++++-->
<script language='Javascript' type='text/javascript'>
function eliminar(){
    if (confirm('La Prueba no ha sido enviada, si decide salir no se guardaran sus datos')){
	   javascript:location.href='index.php';
    }
}
</script> 
<!--*******************************************************************************************************-->
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"></head>

<body>
  <div class="Contenedor">
    <div class="imagen1"><img src="imagenes/EscudoBuap.png" width="67" height="100"></div>
			  <div class="Estilo5">
                <div class="Titulo1">- PRUEBA ASIGNADA -</div>
			    <div class="Titulo2">SISTEMA WEB DE REACTIVOS PARA EVALUAR EL APRENDIZAJE EN LA EDUCACI�N SUPERIOR</div>
				 <div class="imagen2"><img src="imagenes/dotted_line.png">
			  </div>       <div class="datosAlumno">
         <table>
            <tr>
			    <td width="200"><div class="NombreA">Nombre del Alumno: </div></td>
			    <td width="700"><?php echo($_SESSION["S_nombreA"]); ?></td>
	            <td width="300" align="center">EXAMEN: <?php echo($id_examen); ?>
				</td>
            </tr>
         </table>
      </div>  <!--datosAlumo -->
    </div>
    <!--Encabezado-->
   
   <form name="form1" id="form1" method="post" action="guarda_respuestas.php">
   <div class="Datos">
     <p>&nbsp;</p>
     <table width='1200'  align='sup' border='0' cellspacing='0'>
<?php		
	$j=0;
    $t= count($preg_prueba);  //Obtenemos el tama�o del arreglo que se va a mostrar
    while($j < $t){   
	   $r= $arr_num[$j];
	   
       /*if ($datos[img1]!=""){
	       $datos["base"]=str_replace("#1#",'<img src="'.$datos[img1].'" width="240" height="120" />',$datos["base"]);
	   }
       if ($datos[img2]!=""){
		   $datos["base"] = str_replace("#2#",'<img src="'.$datos[img2].'" width="240" height="120" />',$datos["base"]);
	   }*/
	   
	   
	   /* convertir los saltos de l�nea en cadenas: nl2br()
          convertir los caracteres especiales a sus c�digos correspondientes: htmlentities()
          Las dos funciones reciben la cadena y devuelven la misma cadena alterada.
          supongamos que tienes una cadena en una variable $cadena y que la quieres convertir a HTML e imprimirla en pantalla:*/
             echo nl2br(htmlentities($cadena));
		
	   
?>			 
     <tr>
        <td width='34' valign="top"><div  align="center"><?php echo($j+1);?></div></td>  <!--num. pregunta-->
	    <td colspan="2" valign="top"><div class="Preguntas"><label><?php echo nl2br(htmlentities($preg_prueba[$j][2]));?></label></div></td>  <!--pregunta-->
	 </tr>
	 <tr>					  	
		 <td colspan="3" height="20">&nbsp;</td>
	 </tr>	 
	 <tr>					  	
		 <td height='34'>&nbsp;</td>
	     <td width="51" valign="top"> <div align="center">
		      A)<input name="rbtn_opcion<?php echo($j+1); ?>" id="rbtn_opcion<?php echo($j); ?>" type="radio" value="A"></div></td>
		 <td width="1115" valign="top"><div class="Respuesta"><?php echo($preg_prueba[$j][3]); ?></div></td>  <!--Respuesta-->
     </tr>
	 <tr>					  	
		 <td height="34">&nbsp;</td>
         <td width="51" valign="top"> <div align="center">
		      B)<input name="rbtn_opcion<?php echo($j+1); ?>" id="rbtn_opcion<?php echo($j); ?>" type="radio" value="B"></div></td>
		 <td width="1115" valign="top"><div class="Respuesta"><?php echo($preg_prueba[$j][4]); ?></div></td>  <!--Respuesta-->
     </tr>
	     <tr>					  	
		 <td height="34">&nbsp;</td>
		 <td width="51" valign="top"> <div align="center">
		     C)<input name="rbtn_opcion<?php echo($j+1);?>" id="rbtn_opcion<?php echo($j);?>" type="radio" value="C"></div></td>
		 <td width="1115" valign="top"><div class="Respuesta"><?php echo($preg_prueba[$j][5]);?></div></td>  <!--Respuesta-->
     </tr>
     <tr>					  	
	     <td height="40">&nbsp;</td>
		 <td  width="51" valign="top"> <div align="center">
		     D)<input name="rbtn_opcion<?php echo($j+1); ?>" id="rbtn_opcion<?php echo($j); ?>" type="radio" value="D"></div></td>
         <td  width="1217" valign="top"><div class="Respuesta"><?php echo($preg_prueba[$j][6]);?></div></td>  <!--Respuesta-->
     </tr>
	 <tr>
	     <td>&nbsp;</td>
	     <td>&nbsp;</td>
	     <td>&nbsp;</td>
	 </tr>
<?php
     $j+=1;
	} //fin While  
?>	
   </table>
   </div>  <!-- Datos -->
   <div class="boton_enviar">
   	  <input type="button" name="btn_enviar" id="btn_enviar" value="Enviar" onClick="javascript:valida_datos('<?php echo($j-1); ?>');">
   </div>
   <div class="boton_salir">
	  <input type="button" name="btn_salir" id="btn_salir" value="Salir" onClick="eliminar();">
   </div>
<?php
	 //Para poder mandar el arreglo es necesario aplicarle estas 2 funciones;
    $preg_prueba = serialize($preg_prueba); 
    $preg_prueba = urlencode($preg_prueba); 
	$_SESSION["id_preguntas"]= $preg_prueba; 
?>   
	 <input name="preguntas_prueba" type="hidden" id= "preguntas_prueba" value='<?php echo($preg_prueba) ?>'>    <!--enviamos el arreglo-->
	 <input name="id_examen" type="hidden" id= "id_examen" value='<?php echo($id_examen) ?>'> 
     <input name="num_preg" type="hidden" id= "num_preg" value='<?php echo($j) ?>'>                 <!--enviamos el n�mero de preguntas de la preuba-->
	  <input type="hidden" name="<?php echo (session_name()); ?>" value="<?php echo (session_id()); ?>">
  </form> 
<?php 
    }
	 else{ echo("No se encontro ning�n registro"); }
		 
?>
</div>  <!--Contenedor-->
<div class="espaciador"></div>
<br><br><br>
</body>
</html>