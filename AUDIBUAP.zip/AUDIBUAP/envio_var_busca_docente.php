<?php
error_reporting(E_ERROR);
//*******************Esta ventana es llamada por la ventana "busca_docente.php" ********************************************
    //Es necesario hacer esto cuando se recibe un arreglo
    $datos_usuario = stripslashes($_POST['datos_usuario']);  //Recuperamos el arreglo con los datos de los docentes 
    $datos_usuario = urldecode($datos_usuario); 
    $datos_usuario = unserialize($datos_usuario); 
	$i= $_POST['nom_btn'];   //obtenemos el nombre del bot�n que ser� el num de registro en el arrego
	
    echo('<html>
          <head>');
		  /* La siguiente funci�n, que se ejecuta cuando se carga la p�gina, llama a la primera
          p�gina de contenidos, pas�ndole, como campo oculto, la constante de identificaci�n de la sesi�n. */
          echo('<script language="javascript" type="text/javascript">
                   function mandar(){
                       document.f0.submit();
                   }
               </script>');
	echo('</head>');
         //Hacemos que, a la carga de la p�gina, se envie un campo oculto con la constante PHPSESSID 
   echo('<body onLoad="javascript:mandar();">');
   //El formulario contiene la constante PHPSESSID en un campo oculto.
    echo('<form name="f0" id="f0" method="post" action="ficha_docentes.php">
	         <input type="hidden" name="id_docente" id= "id_docente" value="'.$datos_usuario[$i]["id_docente"].'">		  	
             <input type="hidden" name="nombre" id= "nombre" value="'.$datos_usuario[$i]["nombre"].'">		  
	         <input type="hidden" name="ap_paterno" id= "ap_paterno" value="'.$datos_usuario[$i]["ap_paterno"].'">
	         <input type="hidden" name="ap_materno" id= "ap_materno" value="'.$datos_usuario[$i]["ap_materno"].'">
	         <input type="hidden" name="pass" id="pass" value="'.$datos_usuario[$i]["pass"].'">		  		  		  
			 <input type="hidden" name="priv" id="priv" value="'.$datos_usuario[$i]["priv"].'">		  		  		  
  	         <input type="hidden" name="pag" id= "pag" value=1>');  //-- Se env�a pag=1 para que la pagina registro_alumnos.php sepa donde regresar
	   echo('<input type="hidden" name="'.session_name().'" value="'.session_id().'">');
    echo("</form>
          </body>
	      </html>");
?>  
    