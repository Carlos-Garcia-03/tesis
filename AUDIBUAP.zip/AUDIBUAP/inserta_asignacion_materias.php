<?php
error_reporting(E_ERROR);  
//*********** Funci�n que muestra los mensajes de error *****************************	    
 function mensaje($msj){
       echo('
	         <html>
             <head>
                <script language="javascript" type="text/javascript">
                   function mandar(){        /* La siguiente funci�n se ejecuta cuando se carga la p�gina */
	   ');
				     if($msj==1) echo("javascript:window.alert('Se ASIGN� correctamente la materia')");
                     if($msj==2) echo("javascript:window.alert('Error... Es posible que ya exista esta matr�cula');");
				 	 if($msj==3) echo("javascript:window.alert('Error... Algunos campos no contienen informaci�n');");
       echo('
	                 document.f0.submit();
                   }
                </script>
		     </head>
		     <body onLoad="javascript:mandar();">
                 <form name="f0" id="f0" method="post" action="ficha_asignar_materias.php">
                      <input type="hidden" name="'.session_name().'" value="'.session_id().'">
                 </form>
			 </body>
 		     </html>
		');
   }		 
//***************************************************************************************************************
$id_docente= $_POST["cbx_docente"];        //texto que muestra el combox...cbx_tema.text
$id_materia= $_POST["cbx_materia"];
$grupo= $_POST["cbx_grupo"];

if ($id_docente !="" and $id_materia !="") {			
    require("conexion.php");
    $consulta="INSERT INTO asignacion_materias (id_docente,id_materia,grupo)
	           VALUES ('$id_docente','$id_materia','$grupo');";
	$hacerconsulta=mysql_query($consulta, $link);
	if ($hacerconsulta){
	    mysql_close($link);      //cierra la conexion 
	    mensaje(1);   //Si se guardo correctamente
    }
	else  mensaje(2);     //No se guardo 
}
else mensaje(4);   //error si existen variables vacias

?>