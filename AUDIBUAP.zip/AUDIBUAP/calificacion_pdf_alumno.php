<?php
require('fpdf/fpdf.php');
//Creamos la clase PDF
class PDF extends FPDF
{
  //Cabecera de p�gina
  function Header() {
    //Logo
    $this->Image("imagenes/EscudoBuap.gif" , 20 ,10, 20 , 30 , "gif" ,"");
    //Arial bold 13
    $this->SetFont('Arial','B',13);
	//Movernos a la derecha
    $this->Cell(30);
	//T�tulo
    $this->Cell(140,10,'Benem�rita Universidad Aut�noma de Puebla',0,0,'C');
    //Salto de l�nea
    $this->Ln(8);
    //Movernos a la derecha
	$this->SetFont('Arial','B',11);
    $this->Cell(30);
	//T�tulo
    $this->Cell(140,10,'Sistema Web de Reactivos para Evaluar el',0,0,'C');
	 $this->Ln(4);
	 $this->Cell(30);
	$this->Cell(140,10,'Aprendizaje en la Educaci�n Superior',0,0,'C');
    //Salto de l�nea
    $this->Ln(8);
    //Movernos a la derecha
	$this->SetFont('Arial','B',13);
	$this->Cell(30);
    //T�tulo
    $this->Cell(140,10,'REPORTE DE EVALUACI�N',0,0,'C');
    //Salto de l�nea
    $this->Ln(10);
	//Arial bold 10
  }
   
  //Pie de p�gina
  function Footer() {
    //Posici�n: a 1,5 cm del final
    $this->SetY(-50);
    //Arial italic 8
    $this->SetFont('Arial','I',8);
    $this->Cell(40,5,'Nombre y Firma del Maestro:',0,0,'C');
    $this->Ln(20);
    //N�mero de p�gina
    $this->Cell(0,10,'P�gina '.$this->PageNo().'/{nb}',0,0,'C');
  }
  
   function menu2($nombre_alumno,$materia,$id_prueba,$fecha,$no_reactivos,$respuestas_new,$calificacion,$resp){
     $this->SetFont('Arial','B',9);
	//Texto
    $this->Cell(35,5,'Examen:',1,0,'C');
	$this->Cell(80,5,$materia,1,0,'C');
	//creamos un espacio
	$this->Cell(5);
    $this->Cell(35,5,"Num. de Reactivos:",1,0,'C');	
    $this->Cell(35,5,$no_reactivos,1,0,'C');	
	//Salto de l�nea
    $this->Ln(5);
    $this->Cell(35,5,'Prueba:',1,0,'C');
	$this->Cell(80,5,$id_prueba,1,0,'C');	
	$this->Cell(5);
    $this->Cell(35,5,"Respuestas Correctas:",1,0,'C');	
    $this->Cell(35,5,$respuestas_new,1,0,'C');	
    $this->Ln(5);
    $this->Cell(35,5,'Fecha de Examen:',1,0,'C');
	$this->Cell(80,5,$fecha,1,0,'C');		
	$this->Cell(5);
    $this->Cell(35,5,"Calificaci�n Obtenida:",1,0,'C');	
    $this->Cell(35,5,$calificacion,1,0,'C');	
	$this->Ln(5);
    $this->Cell(35,5,'Nombre del Alumno:',1,0,'C');
	$this->Cell(80,5,$nombre_alumno,1,0,'C');
	$this->Cell(5);
	$this->Cell(35,5,'Dictamen:',1,0,'C');
    $this->Cell(35,5,$resp,1,0,'C');	
    $this->Ln(20);
	
	//nuevo agregado
	$this->Cell(90,5,"Criterios de Evaluaci�n de la Prueba Apicada",0,0,'C');
	$this->Ln(10);	
	$this->Cell(10);
    $this->Cell(35,5,"RANGO",1,0,'C');	
    $this->Cell(50,5,'VALORACI�N',1,0,'C');
	$this->Cell(50,5,'APROBADO',1,0,'C');	
    $this->Ln(5);
	$this->Cell(10);
    $this->Cell(35,5, "0 a 6.99",1,0,'C');
	$this->Cell(50,5,'No Satisfactorio',1,0,'C');
	$this->Cell(50,5,'NO',1,0,'C');	
	$this->Ln(5);
	$this->Cell(10);
    $this->Cell(35,5,"7 a 8",1,0,'C');
	$this->Cell(50,5,'Regular',1,0,'C');
	$this->Cell(50,5,'S�',1,0,'C');	
	$this->Ln(5);
	$this->Cell(10);
    $this->Cell(35,5,"8.1 a 9",1,0,'C');
	$this->Cell(50,5,'Satisfactorio',1,0,'C');
	$this->Cell(50,5,'S�',1,0,'C');	
	$this->Ln(5);
	$this->Cell(10);
    $this->Cell(35,5,"9.1 a 10",1,0,'C');
	$this->Cell(50,5,'Excelente',1,0,'C');
	$this->Cell(50,5,'S�',1,0,'C');	
	$this->Ln(20);
   }
   
  
   //Tabla simple
   function TablaSimple($encabezado, $resultado_prueba) {
       $this->Ln(5);
	   	$this->Cell(75);
	   $this->Cell(35,5,'Descripci�n de la Prueba Aplicada',0,0,'C');
	   $this->Ln(10);
      //Cabecera
      foreach($encabezado as $col)
      $this->Cell(60,7,$col,1,0,'C');
      $this->Ln();
	  $t= count($resultado_prueba);
      for($i=0; $i<$t; $i++){  
	    $this->Cell(40,5,$resultado_prueba[$i][0],1,0,'C');
        $this->Cell(40,5,$i+1,1,0,'C');
        $this->Cell(40,5,$resultado_prueba[$i][1],1,0,'C');
        $this->Ln();
      }
   }
  
}  //cerramos la clase PDF

//Recuperamos variables
$nombre_alumno = $_POST["nom_alumno"];
$nombre_materia = $_POST["nombre_materia"];
$calificacion = $_POST["calificacion"];
$respuestas_new = $_POST["respuestas_new"];
$no_reactivos = $_POST["no_reactivos"];
$id_prueba = $_POST["id_prueba"];
$resp = $_POST["resp"];
$fecha_examen_new = $_POST["fecha_examen_new"];

//Es necesario hacer esto cuando se recibe un arreglo
 $resultado_prueba = stripslashes($_POST['resultado_prueba']); 
 $resultado_prueba = urldecode($resultado_prueba); 
 $resultado_prueba = unserialize($resultado_prueba);


$pdf=new PDF();
//T�tulos de las columnas
$Tencabezado = array('C�digo','Pregunta','Respuesta');

$pdf->AliasNbPages();
//Primera p�gina
$pdf->AddPage();
$pdf->SetY(55);

$pdf->menu2($nombre_alumno,$nombre_materia,$id_prueba,$fecha_examen_new,$no_reactivos,$respuestas_new,$calificacion,$resp);
$pdf->TablaSimple($Tencabezado, $resultado_prueba);
$pdf->Output();
?>

