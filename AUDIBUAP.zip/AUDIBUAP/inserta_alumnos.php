<?php
error_reporting(E_ERROR);
//*********** Funci�n que muestra los mensajes de error *****************************	    
   function mensaje($msj){
       echo('
	         <html>
             <head>
                <script language="javascript" type="text/javascript">
                   function mandar(){        /* La siguiente funci�n se ejecuta cuando se carga la p�gina */
	   ');
				     if($msj==1) echo("javascript:window.alert('El Registro se GUARDO Correctamente')");
                     if($msj==2) echo("javascript:window.alert('Error... Es posible que ya exista esta matr�cula');");
				 	 if($msj==3) echo("javascript:window.alert('Error... Algunos campos no contienen informaci�n');");
       echo('
	                 document.f0.submit();
                   }
                </script>
		     </head>
		     <body onLoad="javascript:mandar();">
                 <form name="f0" id="f0" method="post" action="ficha_alumnos.php">
                      <input type="hidden" name="'.session_name().'" value="'.session_id().'">
                 </form>
			 </body>
 		     </html>");
		');
   }		 
//*************** Funci�n que inserta los datos **************************************************************+
    function inserta_datos($id_alumno,$nom,$ap_paterno,$ap_materno,$sem,$grupo,$pass){
	   if ($id_alumno != "" and   $nom != "" and $sem != "" and 
	       $grupo != "" and $pass != "") {
		
	       require("conexion.php");
    	   $consulta="INSERT INTO alumnos (id_alumno,ap_paterno,ap_materno,nombre,semestre,grupo,password)
                      VALUES ('$id_alumno','$ap_paterno','$ap_materno','$nom','$sem','$grupo','$pass');";
	       $hacerconsulta=mysql_query($consulta, $link);
	       if ($hacerconsulta) mensaje(1);   
           else mensaje(2);   
       }
       else mensaje(3);   
    }  //Fin funci�n
//************************************************************************************
session_start();
	//verificamos que se halla accesado desde la pagina de ingreso (verificamos que exista alguna variable de sesi�n)
if (!isset($_SESSION["S_idDocente"])){
    echo('<script languaje="javascript" type="text/javascript">
           location.href="index.php";
       </script>');
    }
  //Si existe la variable de sesi�n entonces se ejecuta el c�digo
else{
//     $opcion_selec= $_POST["opcion_selec"];   //Se recupera la var que indica si se inserta o edita a docentes=2 � alumnos=1
     $id_alumno= $_POST["txt_id"];
     $nombre= $_POST["txt_nom"];
     $appaterno=$_POST["txt_appaterno"];
     $apmaterno= $_POST["txt_apmaterno"];
     $semestre= $_POST["cbx_sem"];
     $grupo= $_POST["cbx_grupo"];
     $pass= $_POST["txt_pass"];
     
	 inserta_datos($id_alumno,$nombre,$appaterno,$apmaterno,$semestre,$grupo,$pass); 
}
     if ($hacerconsulta) {
	     mysql_close($link);   //cierra la conexion
     }  
 //Se cierra el ELSE que se avrio al inicio
?>
