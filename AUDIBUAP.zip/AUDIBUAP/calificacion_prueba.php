
<?php
error_reporting(E_ERROR);
   session_start();
   //*************Se inicializan las variables***********************
   $id_prueba= $_POST["id_examen"];
   //s�lo se ejecuta cuando la pag. es llamada por un docente
	if ($_POST["opcion_ver"]==1){
        //Es necesario hacer esto cuando se recibe un arreglo
	    $datos_alumno = stripslashes($_POST['datos_alumno']); 
        $datos_alumno = urldecode($datos_alumno); 
        $datos_alumno = unserialize($datos_alumno);
	    //****************************************************
        $id = $_POST["nom_btn"];  //contiene el num en el arreglo del alumno del que se desea ver la ficha 
        $nombre_materia= $_POST["nom_materia"];
        $nombre_alumno = $datos_alumno[$id]["appaterno"]." ".$datos_alumno[$id]["apmaterno"]." ".$datos_alumno[$id]["nombre"];
        $id_alumno= $datos_alumno[$id]["id_alumno"];
		$respuestas_new=$datos_alumno[$id]["aciertos"];
		$resp_correctas_new=$datos_alumno[$id]["calif"];
		$no_reactivos= count($datos_alumno[$id]["preg"])-1;
   }
   //s�lo se ejecuta cuando la pag. es llamada por un alumno al contestar un examen 
   if ($_POST["opcion_ver"]==2){ 
       $id_alumno= $_SESSION["S_idAlumno"]; 
	   $nombre_alumno = $_SESSION["S_nombreA"];
   }   
   $resp= array();	   //arreglo para almacenar las respuestas
   $preg= array();     //arreglo para almacenar las preguntas
   $resp_correctas= array();    //arreglo para almacenar las respuestas 
   $resultado_prueba= array();
   $conteo_preg= array();
   $aciertos=0;
   $calificacion=0;
   
   
   //******************************
   require("conexion.php");
   //Buscamos los datos de la prueba que contest� el alumnos
   $consulta='SELECT preguntas,respuestas,resp_correctas,fecha FROM respuestas 
              WHERE id_examen = "'.$id_prueba.'" and id_alumno = "'.$id_alumno.'"';
			  
   //Consulta a base de datos para extrar el semestre del alumno
   $link2=mysql_connect("localhost","root","root");
   mysql_select_db("bd_sipo",$link2);
    $re=mysql_query("SELECT semestre FROM alumnos WHERE id_alumno='$id_alumno'");
	$semestre="";
	while($f=mysql_fetch_array($re)){
	$semestre=$semestre.' '.$f['semestre'].'';	  
	}
	
	if ($semestre == 1) $semestre="B�SICO";
	  else if ($semestre == 2) $semestre="FORMATIVO"; 
	  else  $semestre="PASANTE";

		
	 //Consulta a base de datos para extrar la fecha del examen
	$link3=mysql_connect("localhost","root","root");
    mysql_select_db("bd_sipo",$link3);
    $re=mysql_query("SELECT fecha FROM respuestas WHERE id_examen='$id_prueba' AND id_alumno='$id_alumno'");
	$fecha_examen_new="";
	while($f=mysql_fetch_array($re)){
	$fecha_examen_new=$fecha_examen_new.' '.$f['fecha'].'';
	}	
	
	 //Consulta a base de datos para extrar las respuestas
	$link3=mysql_connect("localhost","root","root");
    mysql_select_db("bd_sipo",$link3);
    $re=mysql_query("SELECT respuestas FROM respuestas WHERE id_examen='$id_prueba' AND id_alumno='$id_alumno'");
	$resp_user="";
	while($f=mysql_fetch_array($re)){
	$resp_user=$resp_user.' '.$f['respuestas'].'';
	} 

	
   $hacerconsulta=mysql_query($consulta, $link);
   if ($hacerconsulta) {    //si no hubo error al hacer la consulta obtenemos las respuestas del usuario, las correctas y los id de las preguntas
       while($datos=mysql_fetch_array ($hacerconsulta, MYSQL_ASSOC)){
             $resp= explode(",",$datos[respuestas]);   //expode convierte una cadena separada por "," en matrix mas un reg. vac�o
	     	 $preg= explode(",",$datos[preguntas]);
			 $resp_correctas= explode(",",$datos[resp_correctas]);
			 $fecha_examen = $datos[fecha];
 	   } 
	   $total_reactivos= count($resp)-1;  //Le restamos 1 por que la funci�n explode le agreg� un registro m�s
	   //Obtenemos el n�mero de aciertos de la prueba contestada
     
      $calificacion = $resp_correctas_new; 
	  $calificacion = number_format($calificacion,2);    //Formateamos la salida para que muestre s�lo dos decimales
	  if ($calificacion >= 7 & $calificacion <=8) $resp="REGULAR";
	  else if ($calificacion >8 & $calificacion <=8.99) $resp="SATISFACTORIO";
	  else if ($calificacion >=9 & $calificacion<=10) $resp="EXCELENTE"; 
	  else $resp="NO SATISFACTORIO";
	  
	
   }
echo('
<html>
<head>

<title>Resultado de la Prueba</title>
<link rel="stylesheet" href="css/estilo_calif.css" type="text/css" media="screen" />

<style type="text/css">
<!--
body,td,th {
	text-align: center;
}
.Contenedor {
	margin: 0px;
	position: relative;
	left: 230px;
	background-color: #000066;
	border-radius:10px;
	top: 220px;
	bottom:100px;
	font-family: Arial, Times, serif;
	font-size: 18px;
	font-style: normal;
	color: #0000CC;
	width: 800px;
	height: 500px;
}
.Titulo {
	margin: 0px;
	background-color: #000066;
	font-family: Arial, Times, serif;
	font-size: 24px;
	font-style: normal;
	color: #FFFFFF;
	position: absolute;
	height: 30px;
	width: 800px;
	left: 0px;
	top: 20px;
}
.Resultados {
	margin: 0px;
	background-color: #FFFFFF;
	font-family: Arial, Times, serif;
	font-size: 24px;
	font-style: normal;
	color: #0000CC;
	position: absolute;
	height: 180px;
	width: 500px;
	left: 7px;
	top: 123px;
}

.Calificacion {
	margin: 0px;
	font-family: Arial, Times, serif;
	font-size: 24px;
	font-style: normal;
	color: #0000CC;
	position: absolute;
	height: 180px;
	width: 280px;
	top: 123px;
	right: 3px;
}
.Estilo2 {
	margin: 0px;
	font-family: Arial, Times, serif;
	font-size: 18px;
	font-style: normal;
	color: #6C0000;
	font-weight: bold;
}
.Estilo3 {
	margin: 0px;
	font-family: Georgia, Arial, Times, serif;
	font-size: 16px;
	font-style: normal;
	color: #000066;
}
.Estilo4 {
	margin: 0px;
	font-family: Georgia, Arial, Times, serif;
	font-size: 14px;
	font-style: normal;
	color: #14148D;
	text-align: left;
}
.Cenefa {
	margin: 0px;
	font-family: Georgia, Arial, Times, serif;
	font-size: 14px;
	font-style: normal;
	color: #FFFFFF;
	position: absolute;
	height: 30px;
	width: 800px;
	top: 85px;
	background-color: #FFDE00;
	left: 0px;
}
.DesResp{
	background-color: #FFFFFF;
	position: absolute;
	top: 316px;
	left: 9px;
	width: 498px;
	overflow: scroll;
	height: 168px;
}
.Boton_salir{
	position: absolute;
	left: 620px;
	top: 400px;
}
.Boton_imprimir{
	position: absolute;
	left: 620px;
	top: 355px;
}
.espaciador{
	height:100px;
	margin-bottom:400px;
}

body {
	background-color: #FFF;
}
</style>

<script language="Javascript" type="text/javascript"> 
    function salir(){
	 	 document.form1.close(); 
	}
</script>

<script language="Javascript" type="text/javascript"> 
    function cerrar_ventana(){
	 	 location.href="index.php";	
</script>
');
    
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
?>

<body onUnload="javascript:salir();">	
<div class="Contenedor">
<div class="imagen1"><img src="imagenes/EscudoBuap.png" width="67" height="100"></div>
			  <div class="Estilo5">
                <div class="Titulo1">- REPORTE DE CALIFICACIONES -</div>
			    <div class="Titulo2">SISTEMA WEB DE REACTIVOS PARA EVALUAR EL APRENDIZAJE EN LA EDUCACI�N SUPERIOR</div>
				 <div class="imagen2"><img src="imagenes/dotted_line.png">
			  </div>
              <div class="espaciador"></div>
  <table width="751" height="20" border="0">
    <tr>
       <td><div class="Titulo">Benem�rita Universidad Aut�noma de Puebla</div></td>
    </tr>
  </table>
  
  <p>&nbsp;</p>
	<div class="Cenefa">
	<table width="799" height="30" border="0">
      <tr>
        <td width="600"><div class="Estilo4"> <div align="center"><h3><?php echo($nombre_materia); ?></h3></div></div></td>
        <td width="199"><div class="Estilo4"> <div align="center"><h3>Fecha: <?php echo($fecha_examen_new); ?></h3></div></div></td>
      </tr>
    </table>
	</div>
  <div class="Resultados">
  <table width="488" height="181" border="0" align="center">
    <tr>
      <td width="122" height="49" bgcolor="#FFF"><div class="Estilo3">Examen:</div></td>
      <td width="348" bgcolor="#DDE4EE"><div class="Estilo4"><?php echo($id_prueba); ?></div></td>
    </tr>
    <tr>
      <td height="35" bgcolor="#CCCCCC"><div class="Estilo3">Alumno:</div></td>
      <td bgcolor="#DDE4EE"><div class="Estilo4"><?php echo($nombre_alumno); ?></div></td>
    </tr>
    <tr>
      <td height="36" bgcolor="#CCCCCC"><div class="Estilo3">Nivel:</div></td>
      <td bgcolor="#DDE4EE"><div class="Estilo4"><?php echo($semestre); ?></div></td>
   </tr>
     <tr>
      <td height="41" bgcolor="#CCCCCC"><div class="Estilo3">Materia:</div></td>
      <td bgcolor="#DDE4EE"><div class="Estilo4"><?php echo($nombre_materia); ?></div></td>
   </tr>
  </table>
  </div>  <!--Fin Resultados-->

  <div class="Calificacion">
  <table width="273" height="172" border="0" align="center">
    <tr>
      <td width="103" height="37" bgcolor="#CCCCCC"><div class="Estilo3">Reactivos:</div></td>
      <td width="123" bgcolor="#DDE4EE"><div class="Estilo4"><?php  echo($no_reactivos); ?></div> </td>
    </tr>

    <tr>
      <td width="103" height="34" bgcolor="#CCCCCC"><div class="Estilo3">Aciertos:</div></td>
      <td width="123" bgcolor="#DDE4EE"><div class="Estilo4"><?php  echo($respuestas_new); ?></div> </td>
    </tr>
    <tr>
      <td height="31" bgcolor="#CCCCCC"><div class="Estilo3">Calificaci�n:</div></td>
      <td bgcolor="#DDE4EE"><div class="Estilo4"> <?php echo($resp_correctas_new); ?></div></td>  
    </tr>
    <tr height="51" >
    
	  <td colspan="2" bgcolor="#FFFFFF"><div class="Estilo2"><?php echo($resp); ?></div></td>
    </tr>
  </table>
  </div>  <!--Fin Calificacion-->
  <p>&nbsp;</p>
  
  <div class="DesResp">
  <table width="475" align="center">
    <tr>
	   <td width="181" bgcolor="#CCCCCC"><div align="center">Pregunta</div></td>
	   <td width="207" bgcolor="#CCCCCC"><div align="center">Respuesta</div></td>
	</tr>
    <tr>
<?php
  	for($p=1; $p <= $total_reactivos++; $p++){
		$contador=$no_reactivos+1;
		$contador=$total_reactivos - $no_reactivos;
		echo('
	    <tr>
	        <td bgcolor="#DDE4EE">Pregunta: '.$contador.'</td>
	   		<td bgcolor="#DDE4EE">'.$resp_user[$p++].'</td>
	      	</tr>
		    ');
    }
?>


</tr>



  </table>
  </div>
  <div class="Boton_salir">
<?php 
   if ($_POST["opcion_ver"] == 1 ) { 
      echo('<form name="form2" id="form2" method="post" action="obtener_calificacion.php">');
	  echo('<input type="button" name="btn_volver" id="btn_volver" value="SALIR" onClick="document.form2.submit();" />');
	  echo('<input type="hidden" name="cbx_examenes" id="cbx_examenes" value="'.$id_prueba.'">');  //para que al volver muestre informaci�n-->
      echo('<input type="hidden" name="nom_materia" id="nom_materia" value="'.$nombre_materia.'">');  //para que al volver muestre informaci�n-->
      echo('</form>');
   }
   if ($_POST["opcion_ver"] == 2 ) { 
       echo('<input type="button" name="btn_volver" id="btn_volver" value="S A L I R" onClick="location.href=\'index.php\';" />');
   }
?>
  </div> <!--botones-->   
  <div class="Boton_imprimir">
   <?php
      //Preparamos el arreglo (que contiene 1 y X dependiendo si contesto bien o mal la pregunta) para poder enviarlo 
      $resultado_prueba = serialize($resultado_prueba);   
      $resultado_prueba = urlencode($resultado_prueba);
   ?>
   <form name="form4" id="form4" method="post" action="calificacion_pdf_alumno.php"  target="_blank"  >
       <input type="button"  name="printt" id="printt" value="IMPRIMIR" onClick="document.form4.submit();" />
	   <input type="hidden" name="nom_alumno" id="nom_alumno" value="<?php echo($nombre_alumno); ?>">
       <input type="hidden" name="nombre_materia" id="nombre_materia" value="<?php echo($nombre_materia); ?>">
       <input type="hidden" name="id_prueba" id="id_prueba" value="<?php echo($id_prueba); ?>">
       <input type="hidden" name="no_reactivos" id="no_reactivos" value="<?php echo($no_reactivos); ?>">
       <input type="hidden" name="respuestas_new" id="respuestas_new" value="<?php echo($respuestas_new); ?>">	   	   
       <input type="hidden" name="calificacion" id="calificacion" value="<?php echo($calificacion); ?>">	   	   
       <input type="hidden" name="resp" id="resp" value="<?php echo($resp); ?>">	   	   	   
       <input type="hidden" name="fecha_examen_new" id="fecha_examen_new" value="<?php echo($fecha_examen_new); ?>">	   	   	   	   
       <input type="hidden" name="resultado_prueba" id="resultado_prueba" value="<?php echo($resultado_prueba); ?>">   	   	   
   </form>

   </div> 
   
</div><!-- Fin Contenedor-->
</body>
</html>
	
