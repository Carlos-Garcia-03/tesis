<?php 
error_reporting(E_ERROR);
  session_start();      /*Se inicia la sesi�n. */
/********************************************************************************/	
 function num_aciertos($resp_usuario,$resp_correctas){
     $numpreg = count($resp_usuario)-1;     
	 $aciertos=0;
	 for ($j=0; $j<$numpreg; $j++){
		   if ($resp_usuario[$j] == $resp_correctas[$j]) {
		       $aciertos+=1; 
		   }
	 }
	 return $aciertos;
 }
/********************************************************************************/	
$id_examen= $_POST["cbx_examenes"];   //Recuperamos las variables del formulario anterior
$nom_materia = $_POST["nom_materia"];


require("conexion.php");
//********Obtenemos las preguntas de cada subtema que componen la prueba para poder obtener 
//******** La calificai�n del grupo por subtema ***************
$consulta= "SELECT id_subtema,total_preg 
            FROM pruebas_generadas 
			WHERE id_examen= '".$id_examen."';";
$hacerconsulta = mysql_query($consulta, $link);
if ($hacerconsulta) {
    $i=0;
    while($datos = mysql_fetch_array ($hacerconsulta, MYSQL_ASSOC)){  
		  $npreguntas_subtema[$i] = $datos["total_preg"];
		  $id_subtema[$i]= $datos["id_subtema"];
		  $i++;
    }
}
//**************************************************************************************************
$consulta= "SELECT * 
            FROM respuestas 
			WHERE id_examen= '".$id_examen."';";
$hacerconsulta_1 = mysql_query($consulta, $link);
if ($hacerconsulta_1) {
   $i=0;
   $talumnos=0;
   while($datos_1= mysql_fetch_array ($hacerconsulta_1, MYSQL_ASSOC)){ 
         $datos_usuario[$i]["id_alumno"]= $datos_1["id_alumno"];
         //expode convierte una cadena separada por "," en matrix mas un reg. vac�o
		 $datos_usuario[$i]["resp"] = explode(",",$datos_1[respuestas]);  //Obtenemos todas las respuestas que hizo el alumno 
	     $datos_usuario[$i]["preg"] = explode(",",$datos_1[preguntas]);   //Obtenemos todas las preguntas del examen que contesto el alumno
		 $datos_usuario[$i]["resp_correctas"] = explode(",",$datos_1[resp_correctas]);//Obtenemos las respuestas correctas
		 $tpreg= count($datos_usuario[$i]["preg"])-1;  //le quitamos el registro vac�o que agreg� la funci�n "explode"
		 $datos_usuario[$i]["aciertos"] = num_aciertos($datos_usuario[$i]["resp"],$datos_usuario[$i]["resp_correctas"]); //optenemos el n�mero de aciertos
        $datos_usuario[$i]["calif"] = ($datos_usuario[$i]["aciertos"] * 10) / $tpreg;
//*************************************************************************************************		   
		//Cargamos un arreglo para mostrar la informaci�n en la ficha de resultados
		for ($j=0; $j<$tpreg; $j++){
		   if ($datos_usuario[$i]["resp"][$j] == $datos_usuario[$i]["resp_correctas"][$j]) {
		       $res_exa[$i][$j]=1;
		   }
		   else  $res_exa[$i][$j]=0;
		}
		//******** Obtenemos los datos del usuario **************************************************************************
        $consulta_2= "SELECT * FROM alumnos WHERE id_alumno = '".$datos_1["id_alumno"]."';";
		$hacerconsulta_2 = mysql_query($consulta_2, $link);
	    if ($hacerconsulta_2) {
		   while($datos_2= mysql_fetch_array ($hacerconsulta_2, MYSQL_ASSOC)){ 
		         $datos_usuario[$i]["appaterno"] = $datos_2["ap_paterno"];
				 $datos_usuario[$i]["apmaterno"] = $datos_2["ap_materno"];
				 $datos_usuario[$i]["nombre"] = $datos_2["nombre"];
		   } 
		}
		else $datos_usuario[$i]["nombre"] = "Error interno";
		$i+=1;
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//************************** Obtenemos la calificaci�n por subtema**********************************************************		
    	$resp_correctas = explode(",",$datos_1[resp_correctas]); //obtenemos el arreglo con las preguntas de la prueba
		$respuestas = explode(",",$datos_1[respuestas]); //obtenemos el arreglo con las respuestas de la prueba
		//Obtenemos cuantos subtemas tiene la prueba seleccionada. 
		//Por cada pregunta distinta(registro en el arreglo) hay un subtema
		$tsubtemas = count($id_subtema);  //obtenemos la cantidad de subtemas 
		$jj=0;  //Lo utilizamos para recorrer el arreglo de todas las preguntas del alumno
		$k=0;
		for ($z=0; $z<$tsubtemas; $z++){
			 $correctas=0;
		     $npreg = $npreguntas_subtema[$z];   //Obtenemos el n�m de preguntas de cada subtema
			 for ($j=0; $j<$npreg; $j++){   
                  $jj=$j+$k;			 
                  if ($resp_correctas[$jj] == $respuestas[$jj]) {
		              $correctas+=1; 
		          }
		     }
			 $k = $jj + 1;
			 if($npreg!=0)   //Verificamos que $numPreg sea distinto de cero para evitar error al dividir
		          $sbt_calificacion[$z][0] = (($correctas*10)/$npreg) + $sbt_calificacion[$z][0];
			  else
			    $npreg=1;
		}	 
		$talumnos+=1;   //lleva la cuenta de cuantos alumnos presentaron la prueba
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++		
   }  //Fin while externo
   //$tsubtemas=2;
   for($i=0; $i<$tsubtemas; $i++){
	   $sbt_calificacion[$i][0]= $sbt_calificacion[$i][0] / $talumnos; //$total_pruebas;
  }
}	   
else echo("no se realiz� la primera b�squeda");

?>
<html>
<head>
<title>Resultados</title>
<link rel="stylesheet" href="css/estilo_resultados.css" type="text/css" media="screen" />

<!--+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-->
<script language='Javascript' type='text/javascript'>
<!-- La siguiente funci�n optienen el nombre del bot�n que se oprimi� y se lo asigna a una variable para que se env�e como campo oculto-->
  function valida(objeto){
     document.getElementById("nom_btn").value = objeto.name;
	 document.form2.submit();    <!-- se env�a el formulario-->
  }   <!-- Fin de la Funci�n-->
</script>
</head>
<!--+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-->
<body>
  <div class='Contenedor'>
    <div class="imagen1"><img src="imagenes/EscudoBuap.png" width="67" height="100"></div>
			  <div class="Estilo5">
                <div class="Titulo1">- REGISTRO DE CALIFICACIONES -</div>
			    <div class="Titulo2">SISTEMA WEB DE REACTIVOS PARA EVALUAR EL APRENDIZAJE EN LA EDUCACI�N SUPERIOR</div>
				 <div class="imagen2"><img src="imagenes/dotted_line.png">
			  </div>
	<div class='Cuadro'>
	   <table width='516' align='center'>
	      <tr height="30">
            <td width="110" align='center'><div class='fondo1'>EXAMEN:</div></td>
		    <td width="348" align='left'><div class='fondo1'><?php echo($id_examen); ?></div></td>
	      </tr>
          <tr height="30">
	         <td align='center'><div class='fondo1'>MATERIA:</div></td>					  
			 <td align='left'><div class='fondo1'><?php echo($nom_materia);?></div></td>					  
		  </tr>
       </table> 
    </div>  <!--Cuadro-->

<?php					
 $prog =1;  //N�mero progresivo 	
 $lim =count($datos_usuario);  //$lim ser� el n�mero de alumnos encontrados
 for($i=0; $i<$lim; $i+=1){
     //Se muestran el semestre, grupo y los encabezados de las tablas		
     if ($i==0){  ?>
		<div class='Datos'>
		  <table align='center' border='0'>
            <tr align='center' bgcolor='#FFDE00'>
              <td width='90'><div class="Texto">N�MERO</div></td>
			  <td width='120'><div class="Texto">MATR�CULA</div></td>
			  <td width='150'><div class="Texto">AP. PATERNO</div></td>
			  <td width='150'><div class="Texto">AP. MATERNO</div></td>
  		  	  <td width='150'><div class="Texto">NOMBRE</div></td>
			  <td width='100'><div class="Texto">PREGUNTAS</div></td>
	  		  <td width='90'><div class="Texto">ACIERTOS</div></td>
	  		  <td width='130'><div class="Texto">CALIFICACION</div></td>
			  <td width='110'><div class="Texto">VER FICHA</div></td>
            </tr>
<?php 
     } // cierre del IF
     echo("<tr>");
     echo("<td align='center'>".$prog."</td>");
     echo("<td align='center'>".$datos_usuario[$i]["id_alumno"]."</td>");
	 echo("<td>".$datos_usuario[$i]["appaterno"]."</td>");
	 echo("<td>".$datos_usuario[$i]["apmaterno"]."</td>");
	 echo("<td>".$datos_usuario[$i]["nombre"]."</td>");										
	 echo("<td align ='center'>".$tpreg."</td>");
	 echo("<td align ='center'>".$datos_usuario[$i]["aciertos"]."</td>");
	 echo("<td align ='center'>".number_format($datos_usuario[$i]["calif"],2)."</td>");	
    //Se crea bot�n ver ficha
	 echo("<td align ='center'>
	           <input type='button' name='".$i."' id='".$i."' value='Ficha' onClick='valida(this)'/></td>");	   
     echo("</tr>");
		   $alumnos[$cont]= $datos["matricula"];  //Se almacena la matr�cula(id) del usuario
	 $prog +=1;
		   
 }  //fin del for  
?>    	
       </table>  <!--Cierra la �ltima tabla que se crea-->
    </div>  <!--datos-->
	 <?php
	  
	  $datos_usuario = serialize($datos_usuario);   //Arreglo con los datos del alumno 
      $datos_usuario = urlencode($datos_usuario);
	  
	  $sbt_calificacion = serialize($sbt_calificacion);
	  $sbt_calificacion = urlencode($sbt_calificacion);
	  
	  $id_subtema = serialize($id_subtema);
	  $id_subtema = urlencode($id_subtema);
?>		
	 <div class="Boton">	             
	      <input type="button2" name="btn_volver" id="btn_volver" value="REGRESAR" onClick="location.href='menu_calificaciones.php';" />
    </div>
	<div class="Grafica">	        
	<!-- Este formulario se ejecuta cuando se oprime el bot�n MOSTRAR GR�FICA -->     	  
	  <form name="form3" id="form3" action="grafica1.php" method="post"  target="_blank">
          <input type="submit" name="Submit" value="Gr&aacute;fica aprovechamiento Grupal">
		  <input type="hidden" name="datos_alumno" id= "datos_alumno" value="<?php echo($datos_usuario); ?>">
	  </form>
    </div>
	<div class="Boton_Grafica2">	        
	<!-- Este formulario se ejecuta cuando se oprime el bot�n MOSTRAR GR�FICA POR SUBTEMAS -->     	  
	  <form name="form4" id="form4" action="grafica_aprovechamiento_subtemas.php" method="post"  target="_blank">
          <input type="submit" name="Submit" value="Gr&aacute;fica Aprovechamiento por SubTemas">
		  <input type="hidden" name="id_subtema" id= "id_subtema" value="<?php echo($id_subtema); ?>">
		  <input type="hidden" name="calf_subtemas" id= "calf_subtemas" value="<?php echo($sbt_calificacion); ?>">		  
	  </form>
    </div>
</div>  <!--Contenedor-->
    	<!-- Este formulario se ejecuta cuando se oprime el bot�n FICHA -->
        <form name="form2" id="form2" method="post" action="calificacion_prueba.php">
          <input type="hidden" name="nom_btn" id= "nom_btn" value="">    <!--env�a el nombre del bot�n que se oprimi�-->
	      <input type="hidden" name="datos_alumno" id= "datos_alumno" value="<?php echo($datos_usuario); ?>">  <!--arreglo con datos del alumno-->
		  <input type="hidden" name="opcion_ver" id= "opcion_ver" value= 1> <!--Indica que se llama al formulario desde esta p�gina(1) -->
		  <input type="hidden" name="id_examen" id="id_examen" value="<?php echo($id_examen)?>">
		  <input type="hidden" name="nom_materia" id="nom_materia" value="<?php echo($nom_materia)?>">		  
      </form>
</body>  
</html>
