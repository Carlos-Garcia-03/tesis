<?php
error_reporting(E_ERROR);
//*********** Funci�n que muestra los mensajes de error *****************************	    
 function mensaje($msj){
       echo('
	         <html>
             <head>
                <script language="javascript" type="text/javascript">
                   function mandar(){        /* La siguiente funci�n se ejecuta cuando se carga la p�gina */
	   ');
				     if($msj==1) echo("javascript:window.alert('El Registro se ELIMIN� Correctamente')");
                     if($msj==2) echo("javascript:window.alert('Error... Es posible que ya exista esta matr�cula');");
				     if($msj==3) echo("javascript:window.alert('Error... Algunos campos no contienen informaci�n');");
       echo('
	                 document.f0.submit();
                   }
                </script>
		     </head>
		     <body onLoad="javascript:mandar();">
                 <form name="f0" id="f0" method="post" action="busca_reactivo.php">
				    <!--se env�an las siguientes variables para que regresar no muestre la pantalla en blanco -->
				    <input name="cbx_docente" type="hidden" id="cbx_docente" value= "'.$_POST["id_docente"].'"  />
                    <input name="cbx_tema" type="hidden" id="cbx_tema" value= "'.$_POST['id_tema_aux'].'"  />
			        <input name="docente" type="hidden" id="docente" value= "'.$_POST['nom_docente_aux'].'"  />
                    <input name="materia" type="hidden" id="materia" value= "'.$_POST['nom_materia_aux'].'"  />	

                      <input type="hidden" name="'.session_name().'" value="'.session_id().'">
                 </form>
			 </body>
 		     </html>
		');
   }		 
//******************************************************************************************************	 
function reindizar($id_mat,$link){
   $consulta="SELECT id_pregunta FROM banco_reactivos WHERE id_materia = '".$id_mat."';";  
   $hacerconsulta=mysql_query($consulta, $link);
   if ($hacerconsulta) {
       $i=1;
       while ($datos= mysql_fetch_array ($hacerconsulta, MYSQL_ASSOC)){
	        $consulta2="UPDATE banco_reactivos SET id_pregunta= '".$id_mat.$i."'
 		                WHERE id_pregunta='".$datos["id_pregunta"]."';";		
	        $hacerconsulta2=mysql_query($consulta2, $link);
		    $i+=1;
	    }
		echo($id_mat);
	}	
}
//************************************************************************************
$id_pregunta= $_POST["id_pregunta"];
$id_materia= $_POST["id_materia"];

if ($id_pregunta != '' and $id_materia != ''){
    require("conexion.php");
    $consulta="DELETE FROM banco_reactivos WHERE  id_pregunta='".$id_pregunta."';";
    $hacerconsulta=mysql_query($consulta, $link);
	if ($hacerconsulta) {
	    reindizar($id_materia,$link);            	
		mysql_close($link); //cierra la conexion
	    mensaje(1);   
	}	
    else mensaje(2);   
}    
else mensaje(3);
?>