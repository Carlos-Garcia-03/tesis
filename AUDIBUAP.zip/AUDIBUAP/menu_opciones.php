<?php
error_reporting(E_ERROR);
    session_start();
	//verificamos que se halla accesado desde la pagina de ingreso (verificamos que exista alguna variable de sesión)
	if (!isset($_SESSION["S_idDocente"])){
?>
       <script languaje="javascript" type="text/javascript">
           location.href="index.php";
       </script>
<?php
    }
  //Si existe la variable de sesión entonces se ejecuta el código
  else{
    $_SESSION["opcion"]=1;   //Le asignamos a la var de sesion 1 para que podamos insertar usuarios
?>
<html>
<head>
<title>Pánel de Administración</title>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="css/estilo_admin.css" type="text/css" media="screen" />
<link rel="stylesheet" type="text/css" href="css/demo.css" />
<link rel="stylesheet" type="text/css" href="css/style2.css" />
<link rel="stylesheet" href="css/style.css">
<link href='http://fonts.googleapis.com/css?family=Terminal+Dosis' rel='stylesheet' type='text/css' />

<body>
<div class="Contenedor">
  <div class="Titulo2">SISTEMA WEB DE REACTIVOS PARA EVALUAR EL APRENDIZAJE EN LA EDUCACIÓN SUPERIOR</div>
  <div class="imagen1"><img src="imagenes/dotted_line.png"></div>
  <div class="imagen2"><img src="imagenes/EscudoBuap.png" width="67" height="100"></div>
 
  <ul class="ca-menu">
                    <li>
                        <a href="ficha_alumnos.php?<?php echo(session_name());?>=<?php echo(session_id()); ?>">
                        <span class="icon-user"></span>
                            <div class="ca-content">
                                <h2 class="ca-main">Alta de Alumnos</h2>
                                <h3 class="ca-sub">Ingrese aquí para agregar nuevos alumnos</h3>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="ficha_docentes.php?<?php echo(session_name());?>=<?php echo(session_id()); ?>" >
                        <span class="icon-user2"></span>
                            <div class="ca-content">
                                <h2 class="ca-main">Alta de Coordinador</h2>
                                <h3 class="ca-sub">Ingrese aquí para agregar nuevos coordinadores</h3>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="ficha_reactivos.php?<?php echo(session_name());?>=<?php echo(session_id()); ?>" >
                            <span class="icon-file"></span>
                            <div class="ca-content">
                                <h2 class="ca-main">Alta de Reactivos</h2>
                                <h3 class="ca-sub">Ingrese aquí para agregar nuevos reactivos</h3>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="busca_alumno.php?<?php echo(session_name());?>=<?php echo(session_id()); ?>">
                            <span class="icon-search"></span>
                            <div class="ca-content">
                                <h2 class="ca-main">Búsqueda de Alummnos</h2>
                                <h3 class="ca-sub">Ingrese aquí para buscar alumnos</h3>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="busca_docente.php?<?php echo(session_name());?>=<?php echo(session_id()); ?>">
                            <span class="icon-search2"></span>
                            <div class="ca-content">
                                <h2 class="ca-main">Búsqueda de Coordinador</h2>
                                <h3 class="ca-sub">Ingrese aquí para buscar a un coordinador</h3>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="menu_reactivos.php?<?php echo(session_name());?>=<?php echo(session_id()); ?>">
                            <span class="icon-file2"></span>
                            <div class="ca-content">
                                <h2 class="ca-main">Consulta de Reactivos</h2>
                                <h3 class="ca-sub">Ingrese aquí para para consultar los reactivos guardados</h3>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="menu_calificaciones.php?<?php echo(session_name());?>=<?php echo(session_id()); ?>">
                            <span class="icon-folder-open"></span>
                            <div class="ca-content">
                                <h2 class="ca-main">Consulta de Calificaciones</h2>
                                <h3 class="ca-sub">Ingrese aquí para consultar calificaciones</h3>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="muestra_datos_alumnos.php?<?php echo(session_name());?>=<?php echo(session_id()); ?>">
                            <span class="icon-profile"></span>
                            <div class="ca-content">
                                <h2 class="ca-main">Consulta Datos de Alumnos</h2>
                                <h3 class="ca-sub">Ingrese aquí para consultar los datos de los alumnos</h3>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="generar_examen.php?<?php echo(session_name());?>=<?php echo(session_id()); ?>">
                            <span class="icon-cogs"></span>
                            <div class="ca-content">
                                <h2 class="ca-main">Crear Prueba</h2>
                                <h3 class="ca-sub">Ingrese aquí para crear una nueva prueba</h3>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="menu_asignar_prueba.php">
                            <span class="icon-wand"></span>
                            <div class="ca-content">
                                <h2 class="ca-main">Asignar Prueba</h2>
                                <h3 class="ca-sub">Ingrese aquí para asignar una prueba existente</h3>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="ficha_asignar_materias.php?<?php echo(session_name());?>=<?php echo(session_id()); ?>">
                            <span class="icon-signup"></span>
                            <div class="ca-content">
                                <h2 class="ca-main">Asignar Materias</h2>
                                <h3 class="ca-sub">Ingrese aquí para asignar materias</h3>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="ver_examenes.php?<?php echo(session_name());?>=<?php echo(session_id()); ?>" >
                           <span class="icon-eye"></span>
                            <div class="ca-content">
                                <h2 class="ca-main">Ver Exámenes</h2>
                                <h3 class="ca-sub">Ingrese aquí para consultar los exámenes existentes</h3>
                            </div>
                        </a>
                    </li>
                </ul>
                <input type="button_session" name="btn_volver" id="btn_volver" value="Cerrar Sesión" onClick="location.href='index.php';" />
                <br><br>
                
        <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.4/jquery.min.js"></script>
        <script src="css/demo.js"></script>
  
</body>
</html>
<?php
} //Se cierra el ELSE que se abrió al inicio
?>
