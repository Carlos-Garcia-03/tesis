<?php
error_reporting(E_ERROR);
//+++++++++++++++++++++++  Esta ventana es llamada por envio_var_busca_docentes.php +++++++++++++++++++++++++++++++++++++++

    session_start();
	//verificamos que se halla accesado desde la pagina de ingreso (verificamos que exista alguna variable de sesi�n)
	if (!isset($_SESSION["S_idDocente"])){    //Si existe la variable de sesi�n entonces se ejecuta el c�digo
?>
       <script languaje="javascript" type="text/javascript">
           location.href="index.php";
       </script>
<?php
    }
    else{
      if ($_SESSION["privilegio"]==3){       //verificamos si cuenta con los privilegios para ingresar docentes
?>

<html>
<head>
<title>Alta de Coordinadores</title>
<link rel="stylesheet" href="css/estilo_gral2.css" type="text/css" media="screen" />

<!-- El siguiente scrpit esta hecho en AJAX+++++++++++++++++++++++++-->
<script language="JavaScript" type="text/javascript">
  var peticion01 = null; //Creamos la variable     
  //para firefox creamos la siguiente variable (Para Internet Explorer creamos un objeto ActiveX)
      peticion01 = new XMLHttpRequest();
  function validar_pasword(url) {       //En esta caso recibe la direcci�n de la pagina valida_pass.php
     $opcion_selec= $_POST["opcion_selec"];   //Se recupera la var que indica si se inserta o edita a docentes=2 � alumnos=1
     nombre= document.getElementById('txt_nom').value;
     appaterno= document.getElementById('txt_appaterno').value;
     apmaterno= document.getElementById('txt_materno').value;
     semestre= 11;
     grupo= 'Z';
     privilegio= document.getElementById('txt_usuario').value;
     nid = document.getElementById('txt_nid').value;  //Obtenemos el valor del campo usuario
	 pass = document.getElementById('txt_pass').value;      //Obtenemos el valor del campo contrase�a
	 variables='id_mat='+nid+'&txt_nom='+nombre+'&txt_appaterno='+appaterno+'&txt_apmaterno='+apmaterno+'&cbx_sem='+11+'&cbx_grupo='+Z+'txt_pass='+pass;
     if(peticion01) {           //Si tenemos el objeto peticion01
        peticion01.open('GET', url+"?txt_pass="+pass+"&txt_usuario="+nid, false);       //Abrimos la url, false=forma s�ncrona
	    peticion01.send(null);       //No le enviamos datos al servidor.
        //Escribimos la respuesta en el campo con ID=resultado
	    if(peticion01.responseText==11){
            document.getElementById('pass_validado').innerHTML =  "Error... El nombre de Usuario/Contrase�a es incorrecto";
	    }
		else { document.form1.submit(); }
     }
  }
</script>
<!--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-->

  <script language='Javascript' type='text/javascript'>
<!--************* Esta funci�n verifica que se hallan escrito todos los datos********************-->	  
  function valida_datos(){
	  var error=false;
	  if(!document.getElementById("txt_appaterno").value){
	     error=true;
         javascript:window.alert('Error... Debe escribir el APELLIDO PATERNO');
	  }	 
	  else{ if(!document.getElementById("txt_apmaterno").value){
	           error=true;
               javascript:window.alert('Error... Debe escribir el APELLIDO MATERNO');
			}   
		    else{ if(!document.getElementById("txt_nom").value){
			         error=true;
                     javascript:window.alert('Error... Debe escribir el NOMBRE');
				  }
				  else{ if(!document.getElementById("txt_id").value){
				           error=true;
                           javascript:window.alert('Error... Debe escribir la MATR�CULA DEL USUARIO');
						}
						else{ if(!document.getElementById("txt_pass").value){
				                 error=true;
                                 javascript:window.alert('Error... Debe escribir una CONTRASE�A');
						      }
						}
				  }
			}  		 
	  }
	  if (!error) document.form.submit();    <!-- Si se escribieron todos los datos se env�a el formulario-->
  }   <!-- Fin de la Funci�n-->
</script>	
<!-- *****se ejecuta s�lo cuando se edita usuarios***************************************************************-->
<script language='Javascript' type='text/javascript'>
function cargaDatos(){
var valor1="";
var valor2="";
var texto1="";
var texto2=""; 
    document.getElementById("txt_nom").value="<?php echo($_POST['nombre']); ?>";
	document.getElementById("txt_appaterno").value="<?php echo($_POST['ap_paterno']); ?>";
	document.getElementById("txt_apmaterno").value="<?php echo($_POST['ap_materno']); ?>";
	document.getElementById("txt_id").value="<?php echo($_POST['id_docente']); ?>";
	document.getElementById("txt_pass").value="<?php echo($_POST['pass']); ?>";
	if( <?php echo($_POST['priv']); ?>==2 ){
	   document.form.rbtn_nivel[0].checked=true;   //Lee el arreglo de los botones de radio y marcamos el del nivel de prioridad del usuario
	}   
	else {
	   document.form.rbtn_nivel[1].checked=true;
	}
}
</script>
<!--++++++++++++  Esta funci�n confirma si se desea eliminar el registro ++++++++++++++++++++++++++++-->
<script language='Javascript' type='text/javascript'>
function eliminar(){
    if (confirm('Confirme que desea ELIMINAR el registro')){
       document.form2.submit()
    }
}
</script> 
<!--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-->
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<div class="Estilo5">
                <div class="Titulo1">- ALTA DE COORDINADORES -</div>
			    <div class="Titulo2">SISTEMA WEB DE REACTIVOS PARA EVALUAR EL APRENDIZAJE EN LA EDUCACI�N SUPERIOR</div>
				 <div class="imagen2"><img src="imagenes/dotted_line.png">
			  </div>
<?php
    $pag= $_POST['pag'];   //variable que permite saber a que p�gina debe regresar al oprimir el bot�n regresar
    $opcion= $_SESSION["opcion"];   //Recuperamos la variable de sesi�n que undica si se inserta(1) o edita(2) usuarios
    //Verificamos que se va a realizar. 1 para INSERTAR usuarios y 2 para EDITAR sus datos
    if($opcion == 1) echo('<body>');   
	if($opcion == 2) echo('<body onLoad="javascript:cargaDatos();">');   //Carga los datos que se van a modificar
?>	
  <div class="Contenedor">
	<?php  if($opcion == 1) { ?> 
    <div class="imagen1"><img src="imagenes/EscudoBuap.png" width="67" height="100"></div>
			  <div class="Estilo5">
                <div class="Titulo1">- ALTA DE COORDINADORES -</div>
			    <div class="Titulo2">SISTEMA WEB DE REACTIVOS PARA EVALUAR EL APRENDIZAJE EN LA EDUCACI�N SUPERIOR</div>
				 <div class="imagen2"><img src="imagenes/dotted_line.png">
			  </div>
<?php  }  ?>	  
	<?php  if($opcion == 2) { ?> 
	<div class="imagen1"><img src="imagenes/EscudoBuap.png" width="67" height="100"></div>
			  <div class="Estilo5">
                <div class="Titulo1">- ALTA DE COORDINADORES -</div>
			    <div class="Titulo2">SISTEMA WEB DE REACTIVOS PARA EVALUAR EL APRENDIZAJE EN LA EDUCACI�N SUPERIOR</div>
				 <div class="imagen2"><img src="imagenes/dotted_line.png">
			  </div>              
		 <?php  } ?>	

	<div class="Bloque1">
    <?php
       if($opcion == 1)echo('<form name="form" id="form" action="inserta_docentes.php"  method="post">');
       if($opcion == 2)echo('<form name="form" id="form" action="modifica_docentes.php"  method="post">');   
    ?>
<div class="Cuadro1">
      <table width="441" border="0" align="center" cellspacing="0">
      <tr>
        <tr><td width="160" height="20"><div align="center" class="Estilo4">Apellido Paterno </div></td></tr>
        <td width="277"><input name="txt_appaterno" type="text1" id="txt_appaterno" /></td>
      </tr>
      <tr>
         <tr><td height="20"><div align="center" class="Estilo4">Apellido Materno </div></td></tr>
         <td><input name="txt_apmaterno" type="text1" id="txt_apmaterno" /></td>
      </tr>
      <tr>
        <tr> <td height="20"><div align="center" class="Estilo4">Nombre</div></td></tr>
         <td><input name="txt_nom" type="text1" id="txt_nom" /></td>
      </tr>
      <tr>
         <tr><td height="20"><div align="center" class="Estilo4">Usuario</div></td></tr>
         <td><input name="txt_id" type="text"  id="txt_id" /></td>
      </tr>
      <tr>
         <td><span class="Estilo5"></span></td>
         <td><span class="Estilo5"></span></td>
      </tr>
      <tr>
         <tr><td><div align="center" class="Estilo5"><strong>Contrase&ntilde;a</strong></div></td></tr>
         <td><input name="txt_pass" type="password" id="txt_pass" /></td>
      </tr>
      <tr>
         <td><span class="Estilo5"></span></td>
         <td><span class="Estilo5"></span></td>
      </tr>
      <tr>
         <td><br><div align="left" class="Estilo5"><strong>Privilegios</strong></div><br></td>
      </tr>
      <tr>
         <td height="38"><span class="Estilo5">
           <label>
           <input name="rbtn_nivel" type="radio" value="2" checked />
           Docente</label>
         </span></td>
      </tr>
      <tr>
         <td height="33"><span class="Estilo5">
           <label>
           <input name="rbtn_nivel" type="radio" value="3" />
           Administrador</label>
         </span></td>
      </tr>
      <tr>
         <td>&nbsp;</td>
         <td>&nbsp;</td>
      </tr>      
   </table>    
</div>   <!--Cuadro1-->
  <div class="Botones">
     <table height="46" align="center" border="0">
        <tr>
          <td width="80"  align="center">
<?php		
             if($opcion == 1) echo("<input type='button' name='btn_guardar' id='btn_guardar' value='GUARDAR'  onClick='valida_datos();'/>");
	         if($opcion == 2) echo("<input type='button' name='btn_guardar' id='btn_guardar' value='MODIFICAR' onClick='valida_datos();'/>");   	        echo('</td>');
 	    if($opcion == 2){
			   echo('<td width="70" align="right">
			             <input type="button" name="btn_eliminar" id="btn_eliminar" value="ELIMINAR" onClick="eliminar();"/>
			         </td>');		    
			}
		   
           echo('<td width="90" align="right">');
         
		   //Regresa a la p�gina que llam� es esta p�gina
		   if($opcion == 1  ) {   // Si $pag es igual a UNO entonces la llam� la p�gina buscar_usuario.php
		       echo('<input type="button" name="regresar" id="regresar" value="REGRESAR" onClick="location.href=\'menu_opciones.php\';"/>');
		   }	
		   if($opcion == 2){   // Si $pag no tiene valor entonces la llam� la p�gina menu_opciones.php
		       echo('<input type="button" name="regresar" id="regresar" value="REGRESAR" onClick="location.href=\'busca_docente.php\';"/>');
		   }
	?>
         </td>
        </tr>
    </table>
</div>  <!--botones-->
  
  <?php
//+++++++++++++++++++ campos ocultos *********************************************************************************************************+	  
      echo('<input type="hidden" name="opcion_selec" id="opcion_selec" value="2"/>');  //indica que se mando desde la pagina de docentes
	  echo('<input type="hidden" name="'.session_name().'" id= "'.session_name().'" value="'.session_id().'">');
   if($opcion == 2) {
	  echo('<input type="hidden" name="id_aux" id="id_aux" value="'.$_POST['id_docente'].'"/>');  //s�lo se ejecuta cuando se edita
   }
echo('</form>');

	//++++++++++++++  Este formulario se ejecuta s�lo cuando se oprime el bot�n de eliminar ++++++++++++++++++++++++++++++++++
?>	
    <form name="form2" id="form2" action="elimina_docente.php"  method="post">
	   <input type="hidden" name="id_aux" id="id_aux" value="<?php echo($_POST['id_docente'])?>"/>
	</form2>
      
</div>
</div>
</body>
</html>
<?php
    }  //If que se encuentra dentro del else del inicio
	else{
	    echo('....NO tiene los suficientes privilegios para ver esta p�gina.....');
	    echo('<a href="menu_opciones.php">regresar</a>');
    }
 }  //Fin del else que se encuentra al principio
?>
