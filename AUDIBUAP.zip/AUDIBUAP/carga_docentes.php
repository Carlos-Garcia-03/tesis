<?php
error_reporting(E_ERROR);
    require("conexion.php");
	//Si el que ingres� es un administrador muestra todos los docentes
    if ($_POST["privilegio"]== 3){
		$consulta='SELECT nombre,ap_paterno,ap_materno,id_docente FROM docentes;';  
	}
	//Si el que ingres� es un docente s�lo muestra su nombre	
	if ($_POST["privilegio"]== 2){
	    $consulta='SELECT nombre,ap_paterno,ap_materno,id_docente FROM docentes WHERE id_docente="'.$_POST["id_usuario"].'";';  //busca los docentes
	}
    $hacerconsulta=mysql_query($consulta, $link);
    
    $rpta="<option value= '0'>Seleccione el Coordinador</option>;";
    if ($hacerconsulta) {    //si no hubo error al hacer la consulta
	   while ($docente=mysql_fetch_array ($hacerconsulta, MYSQL_ASSOC)){
			 $nombre_completo= htmlentities($docente["nombre"]." ".$docente["ap_paterno"]." ".$docente["ap_materno"]);  
	         $rpta= $rpta.'<option value="'.$docente["id_docente"].'">'.$nombre_completo.'</option>';
	   }
    }
    else {
       $rpta= '<option value="1">error...</option>';
    }  
echo ($rpta);	
?>


