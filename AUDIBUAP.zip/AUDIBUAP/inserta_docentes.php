<?php
error_reporting(E_ERROR);
//*********** Funci�n que muestra los mensajes de error *****************************	    
 function mensaje($msj){
       echo('
	         <html>
             <head>
                <script language="javascript" type="text/javascript">
                   function mandar(){        /* La siguiente funci�n se ejecuta cuando se carga la p�gina */
	   ');
				     if($msj==1) echo("javascript:window.alert('El Registro se GUARDO Correctamente')");
                     if($msj==2) echo("javascript:window.alert('Error... Es posible que ya exista esta matr�cula');");
				 	 if($msj==3) echo("javascript:window.alert('Error... Algunos campos no contienen informaci�n');");
       echo('
	                 document.f0.submit();
                   }
                </script>
		     </head>
		     <body onLoad="javascript:mandar();">
                 <form name="f0" id="f0" method="post" action="ficha_docentes.php">
                      <input type="hidden" name="'.session_name().'" value="'.session_id().'">
                 </form>
			 </body>
 		     </html>
		');
   }		 
//*************** Funci�n que inserta los datos **************************************************************+
    function inserta_datos($id_docente,$nom,$ap_paterno,$ap_materno,$pass,$priv){
	   //verificamos que las variables enviadas no esten vac�as
	   if ($id_docente != "" and   $nom != "" and $pass != "" and $priv != "") {
	       require("conexion.php");
    	   $consulta="INSERT INTO docentes (id_docente,ap_paterno,ap_materno,nombre,password,privilegio)
                      VALUES ('$id_docente','$ap_paterno','$ap_materno','$nom','$pass','$priv');";
	       $hacerconsulta=mysql_query($consulta, $link);
           if ($hacerconsulta) {  
		       mysql_close($link);   //cierra la conexion
	           mensaje(1);   
		   }
           else mensaje(2);   
       }
       else mensaje(3);   
    }  //Fin funci�n
//************************************************************************************
session_start();
	//verificamos que se halla accesado desde la pagina de ingreso (verificamos que exista alguna variable de sesi�n)
if (!isset($_SESSION["S_idDocente"])){
    echo('<script languaje="javascript" type="text/javascript">
           location.href="index.php";
       </script>');
    }
  //Si existe la variable de sesi�n entonces se ejecuta el c�digo
else{
//     $opcion_selec= $_POST["opcion_selec"];   //Se recupera la var que indica si se inserta o edita a docentes=2 � alumnos=1
     $id_docente= $_POST["txt_id"];
     $nombre= $_POST["txt_nom"];
     $appaterno=$_POST["txt_appaterno"];
     $apmaterno= $_POST["txt_apmaterno"];
     $pass= $_POST["txt_pass"];
     $priv= $_POST["rbtn_nivel"];
     
	 inserta_datos($id_docente,$nombre,$appaterno,$apmaterno,$pass,$priv); 
}

?>
