<?php 
error_reporting(E_ERROR);
//***************************  Convierte fecha de normal a mysql ******************************
  function cambiaf_a_mysql($fecha){
     ereg( "([0-9]{1,2})/([0-9]{1,2})/([0-9]{2,4})", $fecha, $mifecha);
     $lafecha=$mifecha[3]."-".$mifecha[2]."-".$mifecha[1];
     return $lafecha;
  } 
//-------------------------------------------------------------------------------------------------------------------------------------	
 	session_start();      /*Se inicia la sesi�n. */
//recuperamos las variables 
    $nom_exa= trim($_POST["txt_nom_exa"]);  //la funci�n trim elimina cualquier expacio en blanco al inicio o al final de la cadena
	$id_materia= $_POST["cbx_mat"];
	$id_subtema= $_POST["cbx_subtema"];
	$id_docente= $_SESSION[S_idDocente];
	$numpreg= $_POST["cbx_numpreg"];
	
	if ($nom_exa !="" and $id_materia != "" and $id_subtema != "" and $numpreg != "") {
	    require("conexion.php");
	    $fecha= date("d/m/Y");  //optiene la fecha del sistema
	    $nom_exa=$nom_exa."_".$fecha;   //al nombre del examen se le agrega la fecha
		$consulta="INSERT INTO pruebas_generadas (id_examen,id_materia,id_subtema,total_preg,id_docente,fecha)
                   VALUES ('".$nom_exa."','".$id_materia."','".$id_subtema."','".$numpreg."','".$id_docente."','".cambiaf_a_mysql($fecha)."');";
	    $consulta_inser= mysql_query($consulta, $link);
		if ($consulta_inser)  {
		   echo('');
	   }
	   else echo('Error.... no se insert�');
	}   //end if externo
	else echo('Error... variables vacias');	
?>
