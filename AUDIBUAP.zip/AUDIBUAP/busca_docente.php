<?php
error_reporting(E_ERROR);
//+++++++++++++++++++++++  Esta ventana es llamada por envio_var_busca_docentes.php +++++++++++++++++++++++++++++++++++++++

    session_start();
	//verificamos que se halla accesado desde la pagina de ingreso (verificamos que exista alguna variable de sesión)
	if (!isset($_SESSION["S_idDocente"])){
?>
       <script languaje="javascript" type="text/javascript">
           location.href="index.php";
       </script>
<?php
    }
  //Si existe la variable de sesión entonces se ejecuta el código
    else{
      if ($_SESSION["privilegio"]==3){       //verificamos si cuenta con los privilegios para ingresar docentes
?>
<html>
<head>
<title>Buscar Coordinadores</title>
<link rel="stylesheet" href="css/estilo_buscar2.css" type="text/css" media="screen" />


<script language='Javascript' type='text/javascript'>
<!-- La siguiente función optienen el nombre del botón que se oprimió y se lo asigna a una variable para que se envíecomo campo oculto-->
  function valida(objeto){
     document.getElementById("nom_btn").value = objeto.name;
     document.form1.submit();    <!-- se envía el formulario-->
  }   <!-- Fin de la Función-->
</script>
<!--****************************************************************************************--> 
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
</head>
<body>
<form name="form1" id="form1" method="post" action="envio_var_busca_docente.php">
<?php
   session_start();      /*Se inicia la sesión. */
   $_SESSION["opcion"]=2;   //  //Asignamos opcion=2 para indicar en otros formularios que estamos modificando(opcion=1 para insertar)
?>
   <div class="Contenedor" >
      <div class="imagen1"><img src="imagenes/EscudoBuap.png" width="67" height="100"></div>
			  <div class="Estilo5">
                <div class="Titulo1">- COORDINADORES REGISTRADOS -</div>
			    <div class="Titulo2">SISTEMA WEB DE REACTIVOS PARA EVALUAR EL APRENDIZAJE EN LA EDUCACIÓN SUPERIOR</div>
				 <div class="imagen2"><img src="imagenes/dotted_line.png">
			  </div>
	  <div align="center" class="Estilo1">
   <?php
   require("conexion.php");
   $consulta="SELECT * FROM docentes;";  
   $hacerconsulta=mysql_query($consulta, $link);
   if ($hacerconsulta) {
		$prog =1;  //Número progresivo
		$i=0;
	    echo("<p>&nbsp;</p>");
		echo("<table width='1000' align='center' border='0' bordercolor='#CCFFFF' cellspacing='0'>");
		  echo('<tr align="center" bgcolor="#FFDE00">');
             echo("<td width='50'>NÚMERO</td>");    
			 echo("<td width='150'>AP. PATERNO</td>");
			 echo("<td width='150'>AP. MATERNO</td>");							
  		  	 echo("<td width='170'>NOMBRE</td>");
             echo("<td width='200'>USUARIO</td>");			 
	  		 echo("<td width='150'>CONTRASEÑA</td>");
			 echo("<td width='100'>&nbsp;</td>");	//crea una celda para el botón de modificar			
          echo("</tr>");
		  while($datos= mysql_fetch_array ($hacerconsulta, MYSQL_ASSOC)){ 							 
		     echo("<tr>");
			  echo('<tr align="center" bgcolor="#0C0F66">');
               echo("<td align='center'>".$prog."</td>");
    		   echo("<td>".$datos["ap_paterno"]."</td>");
			   echo("<td>".$datos["ap_materno"]."</td>");
			   echo("<td>".$datos["nombre"]."</td>");										
			   echo("<td align='center'>".$datos["id_docente"]."</td>");			   
			   echo("<td align='center'>".$datos["password"]."</td>");
 			   echo("<td align='center'>
			         <input type='button' name='".$i."' id='".$i."' value='Editar' onClick='valida(this)'/>
					  </td>");//crea botón modificar
             echo("</tr>");
			 //guardamos los registros encontrados en un arreglo
			 $usuario[$i]["id_docente"]= $datos["id_docente"];
			 $usuario[$i]["ap_paterno"]= $datos["ap_paterno"];
			 $usuario[$i]["ap_materno"]= $datos["ap_materno"];
			 $usuario[$i]["nombre"]= $datos["nombre"];
			 $usuario[$i]["pass"]= $datos["password"];
			 $usuario[$i]["priv"]= $datos["privilegio"];			 
			 $i+=1;
			 $prog +=1;
		  }

    	  echo("</table>");  
?>
</div>
	<div class="botones">
	        <input type="button2" name="btn_volver" id="btn_volver" value="REGRESAR"  onClick="location.href='menu_opciones.php';"/>
	</div>
	
<?php	
	 //Para poder mandar el arreglo es necesario aplicarle estas 2 funciones;
    $usuario = serialize($usuario); 
    $usuario = urlencode($usuario); 
    echo('<input type="hidden" name="nom_btn" id= "nom_btn" value="">
	      <input type="hidden" name="datos_usuario" id= "datos_usuario" value="'.$usuario.'">
	 </form>');
	 
	 }  //Fin if externo
    else{ echo("No se encontro ningún registro"); }
?>
</body>
</html>	 
<?php
    }  //If que se encuentra dentro del else del inicio
	else{
	    echo('....NO tiene los suficientes privilegios para ver esta página.....');
	    echo('<a href="menu_opciones.php">regresar</a>');
    }
 }  //Fin del else que se encuentra al principio
?>
