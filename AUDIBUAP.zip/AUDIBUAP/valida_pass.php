<?php
error_reporting(E_ERROR);
//*********** Funci�n que muestra los mensajes de error *****************************	    
   function mensaje($msj){
       echo('
	         <html>
             <head>
                <script language="javascript" type="text/javascript">
                   function mandar(){        /* La siguiente funci�n se ejecuta cuando se carga la p�gina */
	   ');
				     if($msj==1) echo("javascript:window.alert('La Contrase�a y/o nombre de usuario no coninciden')");
                     if($msj==2) echo("javascript:window.alert('ERROR....No se pudo realizar la consulta a la Base de Datos!!!!!');");
				 	 if($msj==3) echo("javascript:window.alert('...Debe ingresar un nombre de USUARIO');");
       echo('
	                 document.f0.submit();
                   }
                </script>
		     </head>
		     <body onLoad="javascript:mandar();">
                 <form name="f0" id="f0" method="post" action="index.php">
                     &nbsp;
                 </form>
			 </body>
 		     </html>");
		');
   }		 
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   //Recupera variables que se envi� del formulario index.php
   $usuario= $_POST["txt_usuario"];
   $pass= $_POST["txt_pass"];
   $tipo_usuario = $_POST["tusuario"];
   $encontrado= false;
   if ($usuario != "") {
	   require("conexion.php");
	   if ($tipo_usuario == 1) {$consulta="SELECT * FROM docentes WHERE id_docente = '".$usuario."' and password = '".$pass."';";  }
	   if ($tipo_usuario == 2) {$consulta="SELECT * FROM alumnos WHERE id_alumno = '".$usuario."' and password = '".$pass."';";	   }
	   $hacerconsulta=mysql_query($consulta, $link) or die(mysql_error());
	   if ($hacerconsulta) {
	       $datos= mysql_fetch_array ($hacerconsulta, MYSQL_ASSOC);
		   if ($datos["password"]==$pass){     //verificamos si coinciden la contrase�a 
	           $encontrado= true;
	           session_start();      /*Se inicia la sesi�n. */
//Si el usuario que ingres� fue un Docente
			   if ($tipo_usuario == 1)  {
      			   /* Se indica que variables van a formar parte del archivo de la sesion */
                   $_SESSION["S_idDocente"]= $datos["id_docente"];  // Se ingresan los valores de las variables
	               $_SESSION["S_nombre"]= $datos["nombre"]." ".$datos["ap_paterno"]." ".$datos["ap_materno"];
			       $_SESSION["privilegio"]= $datos["privilegio"]; 
			       $_SESSION["id_examen"]= ""; 
			       $_SESSION["id_preguntas"]= ""; 
			       $_SESSION["actualizar"]=0;  //variable que permite actualizar datos 0=no actualizar 1= actualizar
			       $_SESSION["opcion"]=1;  //variable que permite INSERTAR=1 O EDITAR=2 alumnos o docentes
			       $_SESSION["exa_creado"]="";
			       $_SESSION["nom_examen"] = "";
			       $_SESSION["materia"]="";
                   $pagina="menu_opciones.php";
               }
//Si el usuario que ingres� fue un alumno
			   if ($tipo_usuario == 2) {   //session_register($S_matricula, $S_nombre);  
                   // Se ingresan los valores de las variables				   
                   $_SESSION["S_idAlumno"]= $datos["id_alumno"];  
                   $_SESSION["S_nombreA"]= $datos["nombre"]." ".$datos["ap_paterno"]." ".$datos["ap_materno"];
				   $_SESSION["S_semestre"]= $datos["semestre"];
				   $_SESSION["S_grupo"]= $datos["grupo"];  
                   $pagina="selecciona_prueba.php";
			   }
		   }  //If verifica password
	   	   else { mensaje(1);  }
	   } //if consulta 
	   else{  mensaje(2);  }
     } //If verifica usuario
	 else{ mensaje (3); }

    if ($encontrado){
	    echo("<html>");
        echo("<head>");
        echo('<script language="javascript" type="text/javascript">');
              /* La siguiente funci�n, que se ejecuta cuando se carga la p�gina, llama a la primera
                 p�gina de contenidos, pas�ndole, como campo oculto, la constante de identificaci�n de la sesi�n. */
              echo("function mandar(){");
                  echo("document.f0.submit();");
              echo("}");
           echo("</script>");
		echo("<head>");
        echo("<!-- Hacemos que, a la carga de la p�gina, se envie un campo oculto con la constante PHPSESSID -->");
        echo('<body onLoad="javascript:mandar();">');
        echo('<!-- El formulario contiene la constante PHPSESSID en un campo oculto. -->');
        echo('<form name="f0" id="f0" method="post" action="'.$pagina.'">');
        echo('<input type="hidden" name="'.session_name().'" value="'.session_id().'">');
        echo(" </form>");
     echo("</body>");
	 echo("</html>");
   } 
?>