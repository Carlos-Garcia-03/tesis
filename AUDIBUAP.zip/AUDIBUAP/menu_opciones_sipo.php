<?php
error_reporting(E_ERROR);
    session_start();
	//verificamos que se halla accesado desde la pagina de ingreso (verificamos que exista alguna variable de sesi�n)
	if (!Session_is_registered("S_idDocente")){
?>
       <script languaje="javascript" type="text/javascript">
           location.href="index.php";
       </script>
<?php
    }
  //Si existe la variable de sesi�n entonces se ejecuta el c�digo
  else{
    $_SESSION["opcion"]=1;   //Le asignamos a la var de sesion 1 para que podamos insertar usuarios
?>
<html>
<head>
<title>Menu Opciones</title>

<style type="text/css">
<!--
body,td,th {
text-align:center;
}
.Contenedor{
	position: relative;
	height: 550px;
	width: 1200px;
	left: 0px;
	top: 0px;
}
.Titulo {
	margin: 0px;
	font-family: Georgia, "Times New Roman", Times, serif;
	font-size: 28px;
	color: ;
	font-style: normal;
	font-weight: normal;
	width: 236px;
	position: absolute;
	top: 25px;
	left: 482px;
}
.Cuadro1{
	position: absolute;
	height: 450px;
	width: 675px;
	left: 301px;
	top: 93px;
}
.Opciones {
	margin: 0px;
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 16px;
	text-decoration: underline;
	color: ;
}
.linea1 {
    color: #0033FF;
	border-top-width: medium;
	border-top-style: ridge;
	border-top-color: ;
	position: absolute;
	width: 437px;
	left: 408px;
	top: 66px;
}


body {
	background-color: ;
}
a:link {
	color: ;
}
a:visited {
	color: ;
}
a:hover {
	color: ;
}
.imagen1 {	position: absolute;
	height: 57px;
	width: 104px;
	top: 4px;
	left: 220px;
}
.Estilo1 {margin: 0px; font-family: Arial, Helvetica, sans-serif; font-size: 28px; color: #000000; font-style: normal; font-weight: normal; width: 553px; position: absolute; top: 15px; left: 371px; }
.Estilo2 {font-family: Arial, Helvetica, sans-serif}
.Estilo4 {margin: 0px; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 16px; text-decoration: underline; color: #000000; }
.Estilo5 {margin: 0px; font-family: Arial, Helvetica, sans-serif; font-size: 16px; text-decoration: underline; color: #000000; }
-->
</style>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"></head>

<body>
<div class="Contenedor">
  <div class="imagen1"><img src="../imagenes/escudo_buap.jpg" width="98" height="91
  "></div>
  <div class="Estilo1"> 
    <div align="center">Men&uacute; de Opciones <img src="../imagenes/barra.png"></div>
  </div>
    <div class="Cuadro1">
    <table width="638" border="0" align="center" cellspacing="0">
      <tr>
         <td width="317" height="55"><div class="Opciones">
           <ul>
             <li>
				<div align="left" class="Estilo2">
				   <a href="ficha_alumnos.php?<?php echo(session_name());?>=<?php echo(session_id()); ?>">Ingresar Alumnos</a></div>
             </li>
            </ul>
         </div>	</td>
         <td width="317"><div class="Opciones">
	       <ul>
	         <li>
	           <div align="left">
			   <a href="ficha_reactivos.php?<?php echo(session_name());?>=<?php echo(session_id()); ?>" >Ingresar  Reactivos</a></div></li>
            </ul>
        </div>	</td>		   			   
      </tr>
      <tr>
         <td height="55"><div class="Estilo4">
             <ul>
               <li>
			   <div align="left" class="Estilo2">
			   <a href="ficha_docentes.php?<?php echo(session_name());?>=<?php echo(session_id()); ?>" >Ingresar Docentes </a></div>
               </li>
             </ul>
         </div></td>
         <td width="317"><div class="Estilo4">
		   <ul>
		     <li>
		       <div align="left">
			   <a href="menu_reactivos.php?<?php echo(session_name());?>=<?php echo(session_id()); ?>">Editar  Reactivos</a></div></li>
	        </ul>
		 </div></td>
      </tr>
      <tr>
         <td height="58" align="left"><div class="Estilo4">
           <div align="left">
             <ul>
               <li><a href="busca_alumno.php?<?php echo(session_name());?>=<?php echo(session_id()); ?>" class="Estilo2">Editar Alumnos</a></li>
             </ul>
           </div>
         </div>	</td>  
         <td align="center"><div class="Estilo4">
           <ul>
             <li>
               <div align="left"><a href="generar_examen.php?<?php echo(session_name());?>=<?php echo(session_id()); ?>" class="Estilo2">Generar Prueba</a>                 </div>
             </li>
           </ul>
         </div></td>	  
      </tr>
      <tr>
        <td height="57" align="left"><div class="Estilo4">
           <div align="left">
             <ul>
               <li><a href="busca_docente.php?<?php echo(session_name());?>=<?php echo(session_id()); ?>" class="Estilo2">Editar datos Docentes</a>                    </li>
             </ul>
           </div>
        </div></td>
		<td><div class="Estilo5">
		  <ul>
		    <li>
		      <div align="left"><a href="menu_asignar_prueba.php?<?php echo(session_name());?>=<?php echo(session_id()); ?>">Asignar Prueba</a>		        </div>
		    </li>
		    </ul>
		</div></td>
      </tr>
      <tr>
      <td height="53" align="center"><div class="Estilo4">
         <ul>
           <li>
             <div align="left" class="Estilo2"><a href="menu_calificaciones.php?<?php echo(session_name());?>=<?php echo(session_id()); ?>">Calificaciones</a>             </div>
           </li>
         </ul>
      </div>	  </td>
	  <td><div class="Estilo5">
	    <ul>
	      <li>
	        <div align="left"><a href="ficha_asignar_materias.php?<?php echo(session_name());?>=<?php echo(session_id()); ?>">Asignar Materias</a></div>
	      </li>
	      </ul>
	  </div></td>
  </tr>
  <tr>
      <td height="62" align="center"><div class="Estilo4">
         <ul class="Estilo2">
           <li>
             <div align="left"><a href="muestra_datos_alumnos.php?<?php echo(session_name());?>=<?php echo(session_id()); ?>">Ver Alumnos Registrados</a>             </div>
           </li>
         </ul>
      </div>	  </td>
      <td align="center"><div class="Estilo5">
	     <ul>
	       <li>
	         <div align="left"><a href="ver_examenes.php?<?php echo(session_name());?>=<?php echo(session_id()); ?>" >Pruebas Generados</a></div>
	       </li>
	       </ul>
      </div></td>
     </tr>
  </table>
  <table width="100" height="80" align="center">
     <tr width="100">
	    <td height="74">
		   <input type="button" name="btn_volver" id="btn_volver" value="Salir del Sistema" onClick="location.href='index.php';" />
	    </td>
	 </tr>
  </table>
</div>  <!-- Fin cuadro1-->
</div>  <!-- Fin Contenedor-->
</body>
</html>
<?php
} //Se cierra el ELSE que se abri� al inicio
?>
