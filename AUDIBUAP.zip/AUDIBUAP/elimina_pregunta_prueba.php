<?php
error_reporting(E_ERROR);
//Recuperamos las variable
$id_prueba=trim($_POST["txt_nom_exa"]);  //la funci�n trim elimina cualquier expacio en blanco al inicio o al final de la cadena
$id_subtema= trim($_POST["txt_subtema"]);

$fecha= date("d/m/Y");  //optiene la fecha del sistema
$id_prueba=$id_prueba."_".$fecha;   //al nombre del examen se le agrega la fecha

    require("conexion.php");
    $consulta="DELETE FROM pruebas_generadas
	           WHERE  id_examen='".$id_prueba."' and id_subtema='".$id_subtema."';";
	$hacerconsulta=mysql_query($consulta, $link);
	if ($hacerconsulta) {
	    echo("eliminado...".$id_subtema);
	}
	else echo("no se elimino:");   
            	
if ($hacerconsulta) {
	mysql_close($link);
   } //cierra la conexion 
?>
