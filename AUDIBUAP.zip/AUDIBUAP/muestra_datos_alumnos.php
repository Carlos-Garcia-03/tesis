<?php
error_reporting(E_ERROR);
    session_start();      /*Se inicia la sesi�n. */
		$error= false;
    require("conexion.php");
    $consulta="SELECT * FROM alumnos ORDER BY semestre,grupo,ap_paterno;";  
	$hacerconsulta=mysql_query($consulta, $link);
	if ($hacerconsulta)  {
?>	 

<html>
<head>
<title>Listado Alumnos</title>
<link rel="stylesheet" href="css/estilo_datos.css" type="text/css" media="screen" />

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<div class="Contenedor" >
	 <div class="imagen1"><img src="imagenes/EscudoBuap.png" width="67" height="100"></div>
			  <div class="Estilo5">
                <div class="Titulo1">- LISTADO DE ALUMNOS -</div>
			    <div class="Titulo2">SISTEMA WEB DE REACTIVOS PARA EVALUAR EL APRENDIZAJE EN LA EDUCACI�N SUPERIOR</div>
				 <div class="imagen2"><img src="imagenes/dotted_line.png">
			  </div>
	 <div class="Estilo1">
	 <?php		
		$cierraTabla = false;
		$usuarios= array("matricula","ap_paterno","ap_materno","nombre","semestre","grupo");
		while($datos= mysql_fetch_array ($hacerconsulta, MYSQL_ASSOC)){ 
             if ($datos["semestre"] != $sem or $datos["grupo"] != $g){
			    if ($cierraTabla) { echo("</table>"); }  //Cierra las tablas intermedias 
		        echo("
				     <p>&nbsp;</p>
				     <table width='1000' align='center'>
				       <tr>
				         <td align='center'><div class='fondo1'><p>AREA: ".$datos["semestre"]."</p></div></td>
				       </tr>
				       <tr>
				         <td align='left'><div class='fondo1'><p>NIVEL: ".$datos["grupo"]."</p></div></td>
				       </tr>
				     </table>
			         <table width='1000' align='center' border='1' cellspacing='0'>
                       <tr align='center'>
                         <td width='50'>N�MERO</td>
				         <td width='50'>MATR�CULA</td>
				         <td width='150'>AP. PATERNO</td>
				         <td width='150'>AP. MATERNO</td>
  		  		         <td width='170'>NOMBRE</td>
				       </tr>
			    ");
				$sem = $datos["semestre"];
				$g = $datos["grupo"];
				$prog =1;  //N�mero progresivo
				$cierraTabla = true;						 
			 }	//Fin if interno
			 echo("
			      <tr>
                    <td align='center' width='100'>".$prog."</td>
			        <td align='center' width='200'>".$datos["id_alumno"]."</td>
			        <td width='150'>".$datos["ap_paterno"]."</td>
			        <td width='150'>".$datos["ap_materno"]."</td>
			        <td width='150'>".$datos["nombre"]."</td>
			        </tr>
			 ");
			 $prog +=1;
		}  //Fin While
    	echo("</table>");   //Cierra la �ltima tabla
?>  
  </div>    
	 <!--estilo1-->
	    <div class="Botones">
	      <table  align="center" width="100">
	        <tr>
		     <td height="38"><input type="button" name="regresar" id="regresar" value="REGRESAR" onClick="location.href='menu_opciones.php';"/></td>
		    </tr>  
          </table>
        </div>    <!--Botones-->
</div>  <!--contenedor-->
</body>
</html>	 
<?php
 	}  //Fin if externo
    else{ 
	   echo("No se encontro ning�n registro");
    }
	$_SESSION["opcion"]=0;  //ingresamos el valor por defaul de la variable
?>