<style type="text/css">
<!--
.Estilo2 {color: #993366}
-->
</style>
<?php
error_reporting(E_ERROR);
 //Recuperamos las variables
  $id_prueba= $_POST["id_prueba"];  

  require("conexion.php");
  //Buscamos todos los subtemas y el n�mero de preguntas que conforman la prueba
  $consulta="SELECT b.id_materia, a.subtema, b.total_preg, c.tema
             FROM  subtemas a, pruebas_generadas b, temas c
             WHERE a.id_subtema = b.id_subtema and a.id_tema = c.id_tema and b.id_examen= '".$id_prueba."';";     
			 
			 
  $hacerconsulta= mysql_query($consulta, $link);
  if ($hacerconsulta) {   
      $i = 0; 	  //inicializamos el Indice del arreglo $preg
	  //Recuperamos los datos de los registros encontrados
	  while($datos= mysql_fetch_array ($hacerconsulta, MYSQL_ASSOC)){ 
            $preguntas[$i] = $datos;
				      $i+=1;
       }
  }
  $lim = count($preguntas);
    echo('
        <table border=0>
		  <tr height="40" bgcolor="#FFDE00" align="center">
		     <td width="330" > &Aacute; R E A</td>
		     <td width="330"> S U B &Aacute R E A</td>
		     <td width="200">N&Uacute;MERO DE PREGUNTAS</td>			 
		  </tr>
	 ');
		  for( $i=0; $i<$lim; $i++ ){
		       echo('<tr height="10">
		               <td>'.$preguntas[$i]['tema'].'</td>
			           <td>'.$preguntas[$i]['subtema'].'</td>
			           <td align="center">'.$preguntas[$i]['total_preg'].'</td>			 
		             </tr>
			   ');
		  }
		  echo('</table>');
			 
?>
