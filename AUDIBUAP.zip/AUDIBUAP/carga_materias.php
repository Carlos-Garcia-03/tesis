<?php
error_reporting(E_ERROR);
    require("conexion.php");
    $consulta='SELECT materia, id_materia FROM materias WHERE semestre = "'.$_POST["elegido"].'" ;';  
    $hacerconsulta=mysql_query($consulta, $link);
    $rpta="<option value= '0'>Seleccione la Materia</option>;";
    if ($hacerconsulta) {    //si no hubo error al hacer la consulta
	    while ($dato=mysql_fetch_array ($hacerconsulta, MYSQL_ASSOC)){
		    if($dato["id_materia"]==$_POST["id_materia"]) {  // opci�n que se mostrar� por defaul en el select
               $rpta= $rpta.'<option value="'.$dato["id_materia"].'" selected="selected">'.htmlentities($dato["materia"]).'</option>';
		   }
	       else {
		      $rpta= $rpta.'<option value="'.$dato["id_materia"].'">'.htmlentities($dato["materia"]).'</option>';
		   }
        }
    }
    else {
       $rpta= '<option value="1">error...</option>';
    }  
echo ($rpta);	
?>
