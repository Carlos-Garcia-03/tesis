<?php
//+++++++++++++++++++++++  Esta ventana es llamada por registro_docentes.php y por registro_alumnos.php +++++++++++++++++

//*********** Funci�n que muestra los mensajes de error *****************************	    
error_reporting(E_ERROR);
function mensaje($msj){
   echo('
	         <html>
             <head>
                <script language="javascript" type="text/javascript">
                   function mandar(){        /* La siguiente funci�n se ejecuta cuando se carga la p�gina */
	   ');
				     if($msj==1) echo("javascript:window.alert('Los Datos se Modificaron Correctamente')");
                     if($msj==2) echo("javascript:window.alert('Error... Es posible que ya exista esta matr�cula');");
				 	 if($msj==3) echo("javascript:window.alert('Error... Algunos campos no contienen informaci�n');");
       echo('
	                 document.f0.submit();
                   }
                </script>
		     </head>
		     <body onLoad="javascript:mandar();">
                 <form name="f0" id="f0" method="post" action="busca_docente.php">
                      <input type="hidden" name="'.session_name().'" value="'.session_id().'">
                 </form>
			 </body>
 		     </html>
		');
}		 
//************************************************************************************
$id_nueva= $_POST["txt_id"];
$nombre= $_POST["txt_nom"];
$appaterno=$_POST["txt_appaterno"];
$apmaterno= $_POST["txt_apmaterno"];
$id_aux=$_POST["id_aux"];
$pass= $_POST["txt_pass"];
$priv= $_POST["rbtn_nivel"];   

    require("conexion.php");
   	// opcion_select = 2 modifica DOCENTES
	if ($id_nueva != "" and $appaterno != "" and $apmaterno != "" and $nombre != "" and
	    $pass != "" and $id_aux != '' and $priv != ""){
        $consulta="UPDATE docentes SET  id_docente = '".$id_nueva."',ap_paterno= '".$appaterno."', ap_materno= '".$apmaterno."',
	               nombre= '".$nombre."',password= '".$pass."', privilegio= '".$priv."'
	               WHERE  id_docente='".$id_aux."';";
	    $hacerconsulta=mysql_query($consulta, $link);
	    if ($hacerconsulta)  mensaje(1);  
		else  mensaje(2);  
    }			  
            	
if ($hacerconsulta) {mysql_close($link);   } //cierra la conexion 
?>