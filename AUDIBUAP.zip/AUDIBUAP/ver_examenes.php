<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Selecciona Examen</title>
<link rel="stylesheet" href="css/estilo_examenes.css" type="text/css" media="screen" />
<script language="javascript" src="/js/jquery-1.2.6.min.js"></script>
<script type="text/javascript" src="js/addPreguntas.js"></script>

<?php
error_reporting(E_ERROR);
    session_start();      /*Se inicia la sesi�n. */
mysql_connect('localhost','root','')or die ('Ha fallado la conexi�n con el servidor: '.mysql_error());
mysql_select_db('bd_sipo')or die ('Error al seleccionar la Base de Datos: '.mysql_error());


?> 
 

<script language="javascript" src="js/jquery-1.2.6.min.js"></script>
<script language="javascript">
<!--*******************Protejemos el codigo para que no se muestre si no tienen javascript*****************-->
<!-- ************************ Carga el combo con los docentes ****************************************************************************-->
 function carga_examen(){
           elegido = 11;  <!--puede ser cualquier numero distinto de uno porque uno es para los alumnos-->
	       $.post("carga_docentes.php", { elegido: elegido }, function(data){
	                                                                  $("#cbx_docentes").html(data);
	                                                                        });			
   }
</script>
<!-- ************************ Carga el combo con los docentes ****************************************************************************-->
<script language="javascript">
   function CargaDocentes(){
        id_docente = '<?php echo($_SESSION["S_idDocente"]); ?>';
		privilegio= '<?php echo($_SESSION["privilegio"]); ?>';
	    
		$.post("carga_docentes.php", {privilegio: privilegio, id_usuario:id_docente}, function(data){
	                                                                                   $("#cbx_docente").html(data);
	                                                                                                 });			
   }
</script>
<!-- ****************************Carga el combo con los examenes creados por el docente elegido***********************************************-->
<script language="javascript" src="js/jquery-1.2.6.min.js"></script>
<script language="javascript">

$(document).ready(function(){
	// Parametros para e combo1
    $("#cbx_docente").change(function () {
   		                $("#cbx_docente option:selected").each(function () {
				                                           elegido = $(this).val();
				                                           $.post("carga_materia_docente.php", { id_docente: elegido }, function(data){
				                                                                                       $("#cbx_mat").html(data);
				                                                                                       $("#cbx_examenes").html("");
			                                                                                         });			
                                                           });
                          })
	// Parametros para el combo2
	$("#cbx_mat").change(function () {
	                    $("#cbx_mat option:selected").each(function () {
			//alert($(this).val());
			                                          elegido = $(this).val();
											          cbxdocente= document.getElementById("cbx_docente");  //Referenciamos el combox
											          id_docente= cbxdocente.value;  //optenemos el docente seleccionado en el combox
		                                              $.post("carga_exa_creados.php", { id_docente: id_docente, id_materia:elegido  }, function(data){
                                                                                                             $("#cbx_examenes").html(data);
													  		                                                                                                 });			
                                                            });
                          })  

});
</script>
<!--***********************************************************************************************************-->
<script language='Javascript' type='text/javascript'>
   function cargaVariables(){	
   	  var nomExa= document.getElementById("cbx_examenes");  <!-- select ex�menes-->
	  var i= nomExa.selectedIndex;     <!-- optenemos el indice del elemento seleccionado en el select-->
	  document.getElementById("nomExamen").value= nomExa.options[i].text;  <!-- asignamos a la var del campo oculto el texto del elemento-->
	  document.getElementById("contestarExa").value= 1;   <!-- campo oculto..le asignamos 1=permitir se envie examen contestado-->
      document.form1.submit();    <!-- se env�a el formulario-->
   }	  
</script>
<!--***********************************************************************************************************-->
</head>

<body onLoad="CargaDocentes()">
<div class="contenedor">
    <div class="imagen1"><img src="imagenes/EscudoBuap.png" width="67" height="100"></div>
			  <div class="Estilo5">
                <div class="Titulo1">- ASIGNAR MATERIAS -</div>
			    <div class="Titulo2">SISTEMA WEB DE REACTIVOS PARA EVALUAR EL APRENDIZAJE EN LA EDUCACI�N SUPERIOR</div>
				 <div class="imagen2"><img src="imagenes/dotted_line.png">
			  </div>
	  <form id="form1" name="form1" method="post" action="guarda_var.php">
    <div class="Estilo1">

      <table width="461">
	  <tr>
         <td width="183" height="33" align="right" >Nombre del Coordinador: </td>	  
	     <td width="266" align="left"><select name="cbx_docente" id="cbx_docente">
                                      </select>
	     </td>
	  </tr>
	  <tr>
	     <td height="34" align="right" >Materia:</td>
		 <td align="left"><select name="cbx_mat" id="cbx_mat">
         </select></td>
	  </tr>
	   <tr>
	     <td height="34" align="right" >Nombre del Examen:</td>
	     <td align="left"><select name="cbx_examenes" id="cbx_examenes">
         </select></td>
	  </tr>
    </table>
   </div>   <!--estilo1-->
   <div class="botones">
   <table>
	  <tr>
	    <td width="110"  valign="bottom">
		    <div align="center">
		      <input type="button" name="btn_enviar" id="btn_enviar" value="ACEPTAR" onClick="mostrar_prueba();" />
            </div></td>
        <td width="120">
		    <div align="center">
		      <input type="button" name="btn_volver" id="btn_volver" value="REGRESAR" onClick="location.href='menu_opciones.php';" />
            </div></td>
	  </tr>
    </table>
	</div>  <!--botones-->
    <input type="hidden" name="nomExamen" id="nomExamen" value="">
    <input type="hidden" name="contestarExa" id="contestarExa" value="">
    <input type="hidden" name="'.session_name().'" value="'.session_id().'">
    </form>
	<div class="Menu" id="Menu2">&nbsp;</div>
</div>  <!--Contenedor-->
</body>
</html>
