
<html>
<head>
<title>Asignar Materias</title>
<link rel="stylesheet" href="css/estilo_materia.css" type="text/css" media="screen" />
<!--************* Esta funci�n verifica que se hayan escrito todos los datos********************-->	  
<script language='Javascript' type='text/javascript'>
function valida_datos(){
  var error=false;

  if(document.getElementById("cbx_docente").value==0){
     error=true;
     javascript:window.alert('Error... Debe Seleccionar un Docente');
  }	 
  else{ 
       if(document.getElementById("cbox_semestre").value==0){
           error=true;  
           javascript:window.alert('Error... Debe Seleccionar un Semestre');
	   } 
	   else{ 
	        if(document.getElementById("cbx_materia").value==0){
	           error=true;
               javascript:window.alert('Error... Debe Seleccionar una Materia');
		    } 
            else{ 
			     if(document.getElementById("cbx_grupo").value==0){
	                error=true;
                    javascript:window.alert('Error... Debe Seleccionar una Grupo');
				 }
		    }			
	  }   	 
  }
  if (!error){
      document.form.submit();    <!-- Si se escribieron todos los datos se env�a el formulario-->
  }	 
}   <!-- Fin de la Funci�n-->
 </script>
<!-- *****se ejecuta s�lo cuando se edita usuarios***************************************************************-->
<script language="javascript" src="js/jquery-1.2.6.min.js"></script>  <!--Se requiere paracargar los combox-->   
<script language='Javascript' type='text/javascript'>
function cargaDocentes(){
     $.post("carga_docentes.php", { privilegio: 3, id_usuario:'admin' }, function(data){
	                                                       $("#cbx_docente").html(data);
	                                                    });			
}
$(document).ready(function(){
	// Parametros para el combo1
   $("#cbox_semestre").change(function () {
   		                $("#cbox_semestre option:selected").each(function () {
			//alert($(this).val());
				                                           elegido = $(this).val();
														   $.post("carga_materias.php", { elegido: elegido, id_materia:'' }, function(data){
				                                                                                       $("#cbx_materia").html(data);
			                                                                                         });			
                                                             });
                          })
});

</script>
<!--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-->
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body onLoad="cargaDocentes()">
<div class="Contenedor">
	<div class="imagen1"><img src="imagenes/EscudoBuap.png" width="67" height="100"></div>
			  <div class="Estilo5">
                <div class="Titulo1">- ASIGNAR MATERIAS -</div>
			    <div class="Titulo2">SISTEMA WEB DE REACTIVOS PARA EVALUAR EL APRENDIZAJE EN LA EDUCACI�N SUPERIOR</div>
				 <div class="imagen2"><img src="imagenes/dotted_line.png">
			  </div>
    <div class="bloque1">
	<form name="form" id="form" action="inserta_asignacion_materias.php"  method="post">
    <br>
      <table width="441" height="165" border="0" align="center" cellspacing="0">
         <tr>
            <td><div align="center" class="Estilo2">Coordinador</div></td>
            <td>
               <select name="cbx_docente" id="cbx_docente">
               </select>            </td>
         </tr>
         <tr>
            <td><div align="center" class="Estilo2">Nivel</div></td>
            <td>
               <select name="cbox_semestre" id="cbox_semestre">
                 <option value="0">-Seleccione un Nivel-</option>
                 <option value="1">NIvel Basico</option>
                 <option value="2">Nivel Formativo</option>
                 <option value="3">Nivel Optativo</option>
               </select>            </td>
         </tr>      
		 <tr>
         <td><div align="center" class="Estilo2">Materia</div></td>
         <td><label> 
		   <select name="cbx_materia" id="cbx_materia">
           </select>
		 </label></td>
      </tr>
	  <td><div align="center" class="Estilo2">Area</div></td>
         <td><label> 
		   <select name="cbx_grupo" id="cbx_grupo">
		     <option value="0">-Area-</option>
		     <option value="1"> 1   &quot;Seleccion de sistemas computacionales para aplicaciones especificas&quot;</option>
		     <option value="2"> 2   &quot;Generaci&oacute;n de nueva tecnolog&iacute;a para la implementaci&oacute;n de sistemas de c&oacute;mputo&quot;</option>
		     <option value="3"> 3   &quot;Desarrollo de sistemas de hardware y su software asociado para aplicaciones espec&iacute;ficas&quot;</option>
		     <option value="4"> 4   &quot;Adaptaci&oacute;n de hardware y/o software&quot;</option>
		     <option value="5"> 5   &quot;Configuraci&oacute;n de redes de c&oacute;mputo para necesidades espec&iacute;ficas&quot;</option>*/
           </select>
		 </label></td>
      </tr>
   </table>    
      
   <div class="Botones">
     <table height="46" align="center" border="0">
        <tr>
          <td width="80"  align="center">
		      <input type='button' name='btn_guardar' id='btn_guardar' value='GUARDAR'  onClick='valida_datos();'/>
		  </td>
          <td width="70" align="center">
		      <input type="button" name="regresar" id="regresar" value="REGRESAR" onClick="location.href='menu_opciones.php'"/></td>
        </tr>
    </table>
   </div>  <!--botones-->
   </form>
  </div><!--Bloque1-->
</div>  <!--contenedor-->
</body>
</html>
