<?php
error_reporting(E_ERROR);
    session_start();
	//verificamos que se halla accesado desde la pagina de ingreso (verificamos que exista alguna variable de sesi�n)
	if (!isset($_SESSION["S_idDocente"])){
?>
       <script languaje="javascript" type="text/javascript">
           location.href="index.php";
       </script>
<?php
    }
  //Si existe la variable de sesi�n entonces se ejecuta el c�digo
  else{

?>

<html>
<head>
<title>Menu Asignar Examen</title>
<link rel="stylesheet" href="css/estilo_examen.css" type="text/css" media="screen" />

<script language="javascript" src="js/jquery-1.2.6.min.js"></script>
<script>
<!--*******************Protejemos el codigo para que no se muestre si no tienen javascript*****************-->
<!--  ***************************Carga el los combos de materias y el de nombre de ex�menes **************************************************-->
function carga_docente(){
        var id_docente = '<?php echo($_SESSION["S_idDocente"]); ?>';
		var privilegio= '<?php echo($_SESSION["privilegio"]); ?>';
	    $.post("carga_docentes.php", { privilegio: privilegio, id_usuario:id_docente }, function(data){
	                                                                $("#cbx_docente").html(data);
	                                                                        });			
}

$(document).ready(function(){
    $("#cbx_sem").change(function () {
   		                $("#cbx_sem option:selected").each(function () {
				                                           elegido = $(this).val();
				                                           $.post("combo1.php", { elegido: elegido }, function(data){
				                                                                                       $("#cbx_mat").html(data);
				                                                                                       $("#cbx_examenes").html("");
			                                                                                         });			
                                                           });
                          })
<!--  ***************************Carga el combo de ex�menes **********************************************************************************-->
	$("#cbx_mat").change(function () {
	                    $("#cbx_mat option:selected").each(function () {
			                                          id_mat = $(this).val();
												      cbxdocente= document.getElementById("cbx_docente");  //Referenciamos el combox
													  id_docente= cbxdocente.value;  //optenemos el docente seleccionado en el combox
			                                          $.post("carga_exa_creados.php", { id_docente: id_docente, id_materia:id_mat }, function(data){
				                                                                                       $("#cbx_examenes").html(data);
			                                                                          });			
                                                       });
                          })
    
});
 
 <!-- ************************* nos env�a al menu principal de opciones ****************************-->
   function ir_pag(){
	       location.href="menu_opciones.php?<?php echo(session_name());?>=<?php echo(session_id()); ?>";
	   }
	    
</script>	
<!--************* Esta funci�n verifica que se hayanescrito todos los datos********************-->	  
<script language='Javascript' type='text/javascript'>
  function valida_datos(){
	  var error=false;
	  if(document.getElementById("cbx_docente").value==0){
	     error=true;
         javascript:window.alert('Error... Debe Seleccionar un Docente');
	  }
	  else{
	      if(document.getElementById("cbx_sem").value==0){
	         error=true;
             javascript:window.alert('Error... Debe Seleccionar un Semestre');
	      }
		  else{ 
		       if(document.getElementById("cbx_grupo").value==0){
	              error=true;
                  javascript:window.alert('Error... Debe Seleccionar un Grupo');
			   }	 
	           else{ 
		           if(document.getElementById("cbx_mat").value==0){
	                  error=true;
                      javascript:window.alert('Error... Debe Seleccionar una Materia');
			       }   
		           else{ 
			            if(document.getElementById("cbx_examenes").value==0){
			               error=true;
                           javascript:window.alert('Error... Debe Seleccionar un Examen');
				        }
			       }
			   }
		  }  		 
	  }
	  if (!error){
	     document.form1.submit();    <!-- Si se escribieron todos los datos se env�a el formulario-->
	  }	 
  }   <!-- Fin de la Funci�n-->
 </script>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"></head>
<!--*********************************************************************************************************************-->
<body onLoad="carga_docente();">	
 <div class="Contenedor">
   <div class="imagen1"><img src="imagenes/EscudoBuap.png" width="67" height="100"></div>
			  <div class="Estilo5">
                <div class="Titulo1">- ASIGNAR EXAMEN -</div>
			    <div class="Titulo2">SISTEMA WEB DE REACTIVOS PARA EVALUAR EL APRENDIZAJE EN LA EDUCACI�N SUPERIOR</div>
				 <div class="imagen2"><img src="imagenes/dotted_line.png">
			  </div>
   <form id="form1" name="form1" method="post" action="listado_alumnos.php?" >
     <div class="Menu">
      <table width="628" height="204" border="0" align="left" cellspacing="0">
        <tr>
          <td height="23"><div class="Estilo2">Seleccione un Coordinador:</div></td>
	      <td align="left"><div align="left">
             <select name="cbx_docente" id="cbx_docente">
             </select>
          </div></td>
        </tr>

	    <tr>
          <td width="176" height="20"><div class="Estilo2">Seleccione el nivel:</div></td>
           <td width="448"><div align="left">
		    <select name="cbx_sem" id="cbx_sem">
  	  	      <option value="0" selected="selected">Selecciona nivel</option>
              <option value="1">NIvel Basico</option>
              <option value="2">NIvel Formativo</option>
              <option value="3">NIvel Optativo</option>
             
            </select>
		  </div></td>
        </tr>
		<tr>
          <td width="176" height="20"><div class="Estilo2">Seleccione el Area:</div></td>
           <td width="448"><div align="left">
		    <select name="cbx_grupo" id="cbx_grupo">
  	  	      <option value="0" selected="selected">Selecciona el area</option>
              <option value="1">Base de Datos</option>
              <option value="2">"Redes"</option>
			   <option value="3">"Ingenieria de Software"</option>
			    <option value="4">"Matematicas Basicas"</option>
				 <option value="5">"Robotica"</option>
            </select>
		  </div></td>
        </tr>
        <tr>
          <td height="23"><div class="Estilo2">Seleccione la Materia:</div></td>
	      <td align="left"><div align="left">
            <select name="cbx_mat" id="cbx_mat">
            </select>
          </div></td>
       </tr>
       <tr>
          <td height="20"><div class="Estilo2">Ex�menes creados: </div></td>
          <td height="20"><div align="left">
            <select name="cbx_examenes" id="cbx_examenes">
            </select>
         </div></td>
       </tr>
   </table>
   </div>   <!--div Menu
  <!-- ********************** Botones  **************************-->
  <div class="Botones">
  <table border="0" cellspacing="0">
	 <tr>
        <td width="120"><input type="button" name="asignar" id="asignar" value="ASIGNAR EXAMEN" onClick="javascript:valida_datos();"/></td>
		<td width="30">&nbsp;</td>
		<td width="78"><input type="button" name="retorno" id="retorno" value="REGRESAR" onClick="javascript:ir_pag();"/></td>
     </tr>
  </table>
  </div>
	 <!-- Campo oculto que envia las variables de sesi�n-->
     <input type="hidden" name="'.session_name().'" value="'.session_id().'">
  </form>
</div> <!--Contenedor-->
</body>
</html>
<?php
    }
?>
