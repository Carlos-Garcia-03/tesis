<?php  
            //+++++++++++++++++++++++++++++++Esta pagina es llamada por la pagina menu_opciones.php +++++++++++++++++++++++++++++++++
    error_reporting(E_ERROR);
	session_start();
	//verificamos que se halla accesado desde la pagina de ingreso (verificamos que exista alguna variable de sesi�n)
	if (!isset($_SESSION["S_idDocente"])){
       echo(' <script languaje="javascript" type="text/javascript">
                location.href="index.php";
              </script>');
    }
        //Si existe la variable de sesi�n entonces se ejecuta el c�digo
   else{
?>

<html>
<head>
 <title>Edici&oacute;n Reactivos</title>
<link rel="stylesheet" href="css/estilo_m_reactivo.css" type="text/css" media="screen" />
<!-- *****************************************************************************************************-->
<script language="javascript" src="js/jquery-1.2.6.min.js"></script>  <!--Se requiere paracargar los combox-->   
<script language="javascript">

function carga_docente(){
        id_docente = '<?php echo($_SESSION["S_idDocente"]); ?>';
		privilegio='<?php echo($_SESSION["privilegio"]); ?>';
	    $.post("carga_docentes.php", { privilegio: privilegio, id_usuario:id_docente }, function(data){
	                                                                $("#cbx_docente").html(data);
	                                                                        });			
}
//Cargamos las materias que imparte el docente seleccionado
$(document).ready(function(){
	// Parametros para el combo1
   $("#cbx_docente").change(function () {
   		                $("#cbx_docente option:selected").each(function () {
				                                           elegido = $(this).val();
														   $.post("carga_materia_docente.php", { id_docente: elegido }, function(data){
				                                                                                       $("#cbx_materia").html(data);
																									   
			                                                                                         });			
                                                             });
                          })
						  
//Cargamos los temas de la materia seleccionada
    $("#cbx_materia").change(function () {
	                    $("#cbx_materia option:selected").each(function () {
			                                               elegido=$(this).val();
			                                               $.post("carga_temas.php", { elegido: elegido, id_tema:'' }, function(data){
				                                                                                              $("#cbx_tema").html(data);
			                                                                                                 });			
                                                            });
                          })						  
    
});
</script>
<!--************* Esta funci�n verifica que se hayan escrito todos los datos********************-->	  
<script language='Javascript' type='text/javascript'>
  function valida_datos(){
	  var error=false;
	  if(document.getElementById("cbx_docente").value==0){
	     error=true;
         javascript:window.alert('Error... Debe Seleccionar un Docente');
	  }	 
	  else{ if(document.getElementById("cbx_materia").value==0){
	           error=true;
               javascript:window.alert('Error... Debe Seleccionar una Materia');
			}   	 
	  }
	  if (!error){
         var cbxdocente= document.getElementById("cbx_docente");
		 var cbxmateria= document.getElementById("cbx_materia");
		 	  
	     document.getElementById("docente").value = cbxdocente.options[cbxdocente.selectedIndex].text; 
	     document.getElementById("materia").value = cbxmateria.options[cbxmateria.selectedIndex].text; 		 
	     document.form1.submit();    <!-- Si se escribieron todos los datos se env�a el formulario-->
	  }	 
  }   <!-- Fin de la Funci�n-->
 </script>
<!-- ********************************************************************************+*************************************-->
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"></head>

<body onLoad="carga_docente();">
   <div class="Contenedor">
      <div class="imagen1"><img src="imagenes/EscudoBuap.png" width="67" height="100"></div>
			  <div class="Estilo5">
                <div class="Titulo1">- CONSULTA DE REACTIVOS -</div>
			    <div class="Titulo2">SISTEMA WEB DE REACTIVOS PARA EVALUAR EL APRENDIZAJE EN LA EDUCACI�N SUPERIOR</div>
				 <div class="imagen2"><img src="imagenes/dotted_line.png">
			  </div>
      <div class="Instrucciones">
     <label><h3><center>SELECCIONE ALGUNA OPCI�N DE B�SQUEDA</center></h3></label></div>
        <form name="form1" id="form1" method="post" action="busca_reactivo.php">
           <div class="Estilo1">  
		 
           <table width="434" border="0">
             <tr>
               <td width="92" height="49"><div align="center">Docente</div></td>
               <td width="332"><label>
                  <select name="cbx_docente" id="cbx_docente">
                  </select>
                  </label></td>
             </tr>
             <tr>
               <td height="52"><div align="center">Materia</div></td>
               <td><label> 
		           <select name="cbx_materia" id="cbx_materia">
               </select>
				   </label></td>
             </tr>
			 <tr>
               <td height="52"><div align="center">Area</div></td>
               <td><label> 
		           <select name="cbx_tema" id="cbx_tema">
               </select>
				   </label></td>
             </tr>

          </table>
          <p>&nbsp;</p>
	  </div>
      <div class="Botones">
         <table width="146" border="0" align="center">
            <tr>
               <td width="76"><label><div align="center"><input type="button" name="Submit" value="Buscar" onClick='valida_datos();'/>
			   </div></label></td>
               <td width="10">&nbsp;</td>
               <td width="100"><label><div align="center">
			      <input type="button" name="Submit2" value="Regresar" onClick="location.href='menu_opciones.php';"></div></label></td>
            </tr>
        </table>
      </div>
	  <input type="hidden" name="docente" id= "docente" value="">
      <input type="hidden" name="materia" id= "materia" value="">
      <?php  echo('<input type="hidden" name="'.session_name().'" value="'.session_id().'">'); ?>
      </form>
   </div>  
   <!-- se cierra Contenedor-->
</body>
</html>

<?php
  }      /*fin del else que se encuentra al inicio. */
?>