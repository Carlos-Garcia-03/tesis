<?php
error_reporting(E_ERROR);
//*********** Funci�n que muestra los mensajes de error *****************************	    
 function mensaje($msj){
       echo('
	         <html>
             <head>
                <script language="javascript" type="text/javascript">
                   function mandar(){        /* La siguiente funci�n se ejecuta cuando se carga la p�gina */
	   ');
				     if($msj==1) echo("javascript:window.alert('Su Examen fue registrado Correctamente')");
                     if($msj==2) echo("javascript:window.alert('Error... Al parecer ya has contestado este Examen');");
				 	 if($msj==3) echo("javascript:window.alert('Error... Existen preguntas que no fueron contestadas');");
				     if($msj==4) echo("javascript:window.alert('Error... N�mero de registros es menor que  uno');");					 
       echo('
	                 document.f0.submit();
                   }
                </script>
		     </head>
		     <body onLoad="javascript:mandar();">
                 <form name="f0" id="f0" method="post" action="selecciona_prueba.php">
                      <input type="hidden" name="'.session_name().'" value="'.session_id().'">
                 </form>
			 </body>
 		     </html>
		');
   }		 

//***************************  Convierte fecha de normal a mysql ******************************
  function cambiaf_a_mysql($fecha){
     ereg( "([0-9]{1,2})/([0-9]{1,2})/([0-9]{2,4})", $fecha, $mifecha);
     $lafecha=$mifecha[3]."-".$mifecha[2]."-".$mifecha[1];
     return $lafecha;
  } 
//****************************************************************************************************
 session_start();      /*Se inicia la sesi�n. */
 $id_examen= $_POST['id_examen'];
 $id_alumno= $_SESSION["S_idAlumno"];
 if ($_POST['num_preg'] > 0 ) {
		//Se deben aplicar estas funciones para poder leer el arreglo recibido
		$preg= array();
	    $preg = stripslashes($_POST["preguntas_prueba"]); 
        $preg = urldecode($preg); 
        $preg = unserialize($preg);
	//*************************************************
        $respuestas="";
		$preguntas="";
		$resp_corr="";
	    $no_contestadas=false;
		$error=false;
		//En lugar de aumentar se decrementa para que no las guarde al reves
	for($i=$_POST['num_preg']; $i >=1; $i-=1){
        $resp ="rbtn_opcion".$i;        //creamos las variables del checkbox c1,c2,...cn que se crearon en asignar_examen.php	
        if ($$resp == "A" or $$resp == "B" or $$resp == "C" or $$resp == "D"){  //verifica que haya sido selecionado una opci�n		
	       $respuestas = $$resp.",".$respuestas;
	    }
		else $no_contestadas=true;
	}
	$tope= count($preg)-1;
	//En lugar de aumentar se decrementa para que no las guarde al reves
	for($i=$tope; $i >=0; $i-=1){
	    $preguntas= $preg[$i][0].",".$preguntas;   //Creamos una cadena separada por comas con los id de las preguntas
		$resp_corr= $preg[$i][7].",".$resp_corr;   //Creamos una cadena separada por comas con las respuestas correctas
	}	
	if (!$no_contestadas) {
	    $fecha= date("d/m/Y");  //optiene la fecha del sistema   
	    require("conexion.php");
	    $consulta="INSERT INTO respuestas (id_examen,id_alumno,respuestas,resp_correctas,preguntas,fecha)
                   VALUES ('$id_examen','$id_alumno','$respuestas','$resp_corr','$preguntas','".cambiaf_a_mysql($fecha)."');";
		
        $hacerconsulta=mysql_query($consulta, $link);
        if ($hacerconsulta){
		    echo('
			      <html>
                  <head>
                     <script language="javascript" type="text/javascript">
                        function mandar() {
                           document.f0.submit();
                        }
                     </script>
		          <head>
                  <!-- Hacemos que, a la carga de la p�gina, se envie un campo oculto con la constante PHPSESSID -->
                  <body onLoad="javascript:mandar();">
                     <!-- El formulario contiene la constante PHPSESSID en un campo oculto. -->
                     <form name="f0" id="f0" method="post" action="calificacion_prueba.php">
                        <input type="hidden" name="'.session_name().'" value="'.session_id().'">
                        <input name="id_examen" type="hidden" id= "id_examen" value="'.$id_examen.'">
						<input name="opcion_ver" type="hidden" id= "opcion_ver" value="2">  
                     </form>
                  </body> 
	              </html>
			');
        }			
		else mensaje(1);
	}
}//fin del IF externo		
else {
	mensaje(4);    //numero de registros es menor que  uno
}
    
?>