<?php
error_reporting(E_ERROR);
require('fpdf/fpdf.php');
//Creamos la clase PDF
class PDF extends FPDF
{
  //Cabecera de p�gina
  function Header() {
    //Logo
    $this->Image("imagenes/escudo.gif" , 5 ,2, 35 , 28 , "gif" ,"http://www.mipagina.com");
    //Arial bold 13
    $this->SetFont('Arial','B',13);
	//Movernos a la derecha
    $this->Cell(30);
	//T�tulo
    $this->Cell(140,10,'Secretar�a de Educaci�n P�blica',0,0,'C');
    //Salto de l�nea
    $this->Ln(10);
    //Movernos a la derecha
    $this->Cell(30);
	//T�tulo
    $this->Cell(140,10,'Escuela Normal Ofl. "Profr. Luis Casarrubias Ibarra',0,0,'C');
    //Salto de l�nea
    $this->Ln(10);
    //Movernos a la derecha
	$this->Cell(30);
    //T�tulo
    $this->Cell(140,10,'Reporte de Calificaciones por subtemas',0,0,'C');
    //Salto de l�nea
    $this->Ln(10);
	//Arial bold 10
  }
   
  //Pie de p�gina
  function Footer() {
    //Posici�n: a 1,5 cm del final
    $this->SetY(-50);
    //Arial italic 8
    $this->SetFont('Arial','I',8);
    $this->Cell(0,5,'Nombre y Firma del Maestro:',1,0,'C');
    $this->Ln(20);
    //N�mero de p�gina
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
  }
  
   function menu2($nombre_alumno,$materia,$id_prueba,$fecha,$total_reactivos,$aciertos,$calificacion,$resp){
     $this->SetFont('Arial','B',9);
	//Texto
    $this->Cell(35,5,'Materia:',1,0,'C');
	$this->Cell(50,5,$materia,1,0,'C');
	//creamos un espacio
	$this->Cell(40);
    $this->Cell(35,5,"Num. de Reactivos:",1,0,'C');	
    $this->Cell(15,5,$total_reactivos,1,0,'C');	
	//Salto de l�nea
    $this->Ln(5);
    $this->Cell(35,5,'Prueba:',1,0,'C');
	$this->Cell(50,5,$id_prueba,1,0,'C');	
	$this->Cell(40);
    $this->Cell(35,5,"Aciertos:",1,0,'C');	
    $this->Cell(15,5,$aciertos,1,0,'C');	
    $this->Ln(5);
    $this->Cell(35,5,'Fecha de Aplicaci�n:',1,0,'C');
	$this->Cell(50,5,$fecha,1,0,'C');		
	$this->Cell(40);
    $this->Cell(35,5,"Calificaci�n:",1,0,'C');	
    $this->Cell(15,5,$calificacion,1,0,'C');	
	$this->Ln(5);
    $this->Cell(35,5,'Nombre del Alumno:',1,0,'C');
	$this->Cell(50,5,$nombre_alumno,1,0,'C');
	$this->Cell(40);
    $this->Cell(50,5,$resp,1,0,'C');	
    $this->Ln(20);
   }
  
   //Tabla simple
   function TablaSimple($encabezado, $resultado_prueba) {
       $this->Ln(5);
	   	$this->Cell(40);
	   $this->Cell(35,5,'Descripci�n de la Puebla aplicada',0,0,'C');
	   $this->Ln(10);
      //Cabecera
      foreach($encabezado as $col)
      $this->Cell(40,7,$col,1,0,'C');
      $this->Ln();
	  $t= count($resultado_prueba);
      for($i=0; $i<$t; $i++){  
	    $this->Cell(40,5,$resultado_prueba[$i][0],1,0,'C');
        $this->Cell(40,5,$i+1,1,0,'C');
        $this->Cell(40,5,$resultado_prueba[$i][1],1,0,'C');
        $this->Ln();
      }
   }
}  //cerramos la clase PDF

//Recuperamos variables
$nombre_alumno = $_POST["nom_alumno"];
$nombre_materia = $_POST["nombre_materia"];
$calificacion = $_POST["calificacion"];
$aciertos = $_POST["aciertos"];
$total_reactivos = $_POST["total_reactivos"];
$id_prueba = $_POST["id_prueba"];
$resp = $_POST["resp"];
$fecha_examen = $_POST["fecha_examen"];

//Es necesario hacer esto cuando se recibe un arreglo
 $resultado_prueba = stripslashes($_POST['resultado_prueba']); 
 $resultado_prueba = urldecode($resultado_prueba); 
 $resultado_prueba = unserialize($resultado_prueba);


$pdf=new PDF();
//T�tulos de las columnas
$Tencabezado = array('C�digo pregunta','Pregunta','respuesta');
$pdf->AliasNbPages();
//Primera p�gina
$pdf->AddPage();
$pdf->SetY(45);
//$pdf->AddPage();
$pdf->menu2($nombre_alumno,$nombre_materia,$id_prueba,$fecha_examen,$total_reactivos,$aciertos,$calificacion,$resp);
$pdf->TablaSimple($Tencabezado, $resultado_prueba);
$pdf->Output();
?>

