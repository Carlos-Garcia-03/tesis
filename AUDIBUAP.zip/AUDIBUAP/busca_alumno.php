<?php
error_reporting(E_ERROR);
    session_start();
	//verificamos que se halla accesado desde la página de ingreso (verificamos que exista alguna variable de sesión)
if (!isset($_SESSION["S_idDocente"])){
    echo('<script languaje="javascript" type="text/javascript">
           location.href="index.php";
       </script>');
    }
  //Si existe la variable de sesión entonces se ejecuta el código
 else{
     $_SESSION["opcion"]=2;   //Le asignamos a la var de sesion 2 para indiar que se van editar datos
 ?>
<html>
<head>
<title>Buscar Alumno</title>
<link rel="stylesheet" href="css/estilo_buscar.css" type="text/css" media="screen" />
<!--******************************************************************************************************************************-->
<!-- El siguiente scrpit esta hecho en AJAX+++++++++++++++++++++++++-->
<script language="JavaScript" type="text/javascript">
  var peticion01 = null; //Creamos la variable     
      peticion01 = new XMLHttpRequest();  //para firefox creamos la siguiente variable (Para Internet Explorer creamos un objeto ActiveX)

  function busca(url) {       //En esta caso recibe la dirección de la pagina valida_pass.php
     sem = document.getElementById('cbx_semestre').value;  //Obtenemos el valor del campo usuario
	 grupo = document.getElementById('cbx_grupo').value;      //Obtenemos el valor del campo contraseña
     if(peticion01) {           //Si tenemos el objeto peticion01
        peticion01.open('GET', url+"?cbx_semestre="+sem+"&cbx_grupo="+grupo, false);       //Abrimos la url, false=forma síncrona
	    peticion01.send(null);       //No le enviamos datos al servidor.
        //Escribimos la respuesta en el campo con ID=resultado
	    if (peticion01.responseText==11){
	        document.form2.submit();
	    }
	    else{
            document.getElementById('result_consulta').innerHTML =  peticion01.responseText;
	    }
     }
  }
</script>
<!--******************************************************************************************************************************-->
<!-- Este script se ejecuta al oprimir el boton de editar que se crea en la pagina busca_por_semestre.php que se llama con ajax-->
<!-- La siguiente función optienen el nombre del botón que se oprimió y se lo asigna a una variable para que se envíe como campo oculto-->
<script language='Javascript' type='text/javascript'>
  function valida(objeto){
     document.getElementById("boton").value = objeto.name;  //Asignamos a la var. boton el objeto recibido
	 num_btn= document.getElementById("boton").value;  //Obtenemos el nombre(número) del boton que se oprimió
	 document.getElementById("reg_matricula").value= document.getElementById("a"+num_btn).innerHTML;
	 document.getElementById("reg_nombre").value= document.getElementById("d"+num_btn).innerHTML;
	 document.getElementById("reg_appaterno").value= document.getElementById("b"+num_btn).innerHTML;	 	 
	 document.getElementById("reg_apmaterno").value= document.getElementById("c"+num_btn).innerHTML;	 
 	 document.getElementById("reg_pass").value= document.getElementById("e"+num_btn).innerHTML;
    //   alert(document.getElementById("d"+num_btn).innerHTML);
	 document.form2.submit();
  }   <!-- Fin de la Función-->
</script>

<style type="text/css">
<!--


-->
     </style>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /></head>

<body>
<div class="Contenedor">
  <div class="imagen1"><img src="imagenes/EscudoBuap.png" width="67" height="100"></div>
			  <div class="Estilo5">
                <div class="Titulo1">- BUSCAR USUARIO -</div>
			    <div class="Titulo2">SISTEMA WEB DE REACTIVOS PARA EVALUAR EL APRENDIZAJE EN LA EDUCACIÓN SUPERIOR</div>
				 <div class="imagen2"><img src="imagenes/dotted_line.png">
			  </div>
   <!--**************Busca usuario POR MATRÍCULA **************************************************************-->
   <div class="Separador1">Buscar por Matrícula</div>
   <div class="Buscar1">
     <form name="form1" id="form1" method="post" action="busca_por_matricula.php">
     <table width="329" align="center">
       <tr>
          <td><h2>Matrícula</h2></td>	   
	      <td><input name="txt_id" type="text" id="txt_id" value=""></td>
		  <td><input type="button" name="Submit" value="BUSCAR" onClick="javascript:document.form1.submit();"></td>
	   </tr>
     </table>
     <input type="hidden" name="<?php session_name() ?>" value="<?php session_id() ?>">
     </form>
  </div>   <!--Buscar1-->
   <!--*************** Busca usuario POR SEMESTRE *************************************************************-->
   <div class="Separador2">Buscar por Área</div>
   <div class="Buscar2">
     <form name="form2" id="form2" method="post" action="ficha_alumnos.php">
     <table width="514" align="center">
	   <tr>
	      <td width="68"><h2>Área</h2></td>
	      <td width="177"><select name="cbx_semestre" id="cbx_semestre"> 
                            <option value="1" selected="selected">Área 1</option>
               <option value="2">Área 2</option>
               <option value="3">Área 3</option>
               <option value="4">Área 4</option>
               <option value="5">Área 5</option>
		  </select></td>
		  <td width="47">Nivel</td>
          <td width="63"><select name="cbx_grupo" id="cbx_grupo">
                             <option value="BASICO">Básico</option>
               <option value="FORMATIVO">Formativo</option>
			   <option value="OPTATIVO">Optativo</option>
          </select></td>
          <td width="135">  <input type="button" name="Submit2" value="BUSCAR" onClick="javascript:busca('busca_por_sem.php');"/></td>
		  <!--onClick="javascript:document.form2.submit();"></td>-->
       </tr>	   
     </table>
     <input type="hidden" name="<?php session_name() ?>" value="<?php session_id() ?>">
	 <input type="hidden" name= "boton" id= "boton" value="">	 
	 <input type="hidden" name= "reg_matricula" id= "reg_matricula" value="">
	 <input type="hidden" name= "reg_nombre" id = "reg_nombre" value="">
	 <input type="hidden" name= "reg_appaterno" id = "reg_appaterno" value=""> 	 
	 <input type="hidden" name= "reg_apmaterno" id = "reg_apmaterno" value="">	 
 	 <input type="hidden" name= "reg_pass" id ="reg_pass" value = "">
     </form>
  </div>  <!--Buscar2-->
  <!--************************************************************************************************************-->
  <div class="consulta"><div id="result_consulta">&nbsp;</div></div>  <!--en el div id=pass_validado se escribe el resultado de la funcion en ajax-->
  <div class="BotonVolver"> 
  <input type="button" name="Submit2" value="REGRESAR" onClick="location.href= 'menu_opciones.php'"/> </div>
   <div class="linea2">&nbsp;</div>
</div>  <!--contenedor-->
</body>
</html>
<?php
} //Se cierra el ELSE que se abrió al inicio
?>
