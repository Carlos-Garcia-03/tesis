
<?php //+++++++++++++++++++++++++++++ Esta ventana es llamada por insertar_reactivo.php ++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//*********** Funci�n que muestra los mensajes de error *****************************	    
error_reporting(E_ERROR);
 function mensaje($msj){
       echo('
	         <html>
             <head>
                <script language="javascript" type="text/javascript">
                   function mandar(){        /* La siguiente funci�n se ejecuta cuando se carga la p�gina */
	   ');
				     if($msj==1) echo("javascript:window.alert('El Registro se MODIFIC� Correctamente')");
                     if($msj==2) echo("javascript:window.alert('Error... Es posible que ya exista esta matr�cula');");
				     if($msj==3) echo("javascript:window.alert('Error..No se pudo leer el n�mero de registros de la tabla banco reactivos necesario para crear el id de la pregunta');");					 
				 	 if($msj==4) echo("javascript:window.alert('Error... Algunos campos no contienen informaci�n');");
       echo('
	                 document.f0.submit();
                   }
                </script>
		     </head>
		     <body onLoad="javascript:mandar();">
                 <form name="f0" id="f0" method="post" action="busca_reactivo.php">
				    <!--se env�an las siguientes variables para que regresar no muestre la pantalla en blanco -->
				    <input name="cbx_docente" type="hidden" id="cbx_docente" value= "'.$_POST["id_docente"].'"  />
                    <input name="cbx_tema" type="hidden" id="cbx_tema" value= "'.$_POST['id_tema_aux'].'"  />
			        <input name="docente" type="hidden" id="docente" value= "'.$_POST['nom_docente_aux'].'"  />
                    <input name="materia" type="hidden" id="materia" value= "'.$_POST['nom_materia_aux'].'"  />	

                      <input type="hidden" name="'.session_name().'" value="'.session_id().'">
                 </form>
			 </body>
 		     </html>
		');
   }		 

//******************************************************************************************************	 
$id_pregunta= $_POST["id_pregunta"];
$id_preg_aux= $id_pregunta;    //respaldo el id de la pregunta

$id_materia= $_POST["cbx_mat"];  //valor del combox cbx_mat

$id_materia_aux= $_POST["id_materia_aux"]; //valor de la variable oculta mat_aux
$instruccion= $_POST["txt_instruccion"];  //valor de la caja de texto txt_instruccion
$base= $_POST["txt_base"];   //valor de la caja de texto txt_base
$opa= $_POST["txt_opa"];
$opb= $_POST["txt_opb"];
$opc= $_POST["txt_opc"];
$opd= $_POST["txt_opd"];
$opcorrecta= $_POST["cbx_opcorrecta"];
$formato= $_POST["cbx_formato"];
$niveltax= $_POST["cbx_nivel_taxonomico"];
$just_fuente= $_POST["txt_just_fuente"];
$id_tema= $_POST["cbx_tema"];    //valor del combox cbx_tema
$id_subtema= $_POST["cbx_subtema"];  //valor del combox cbx_subtema
$semestre= $_POST["cbx_sem"];  //valor del combox cbx_sem
$id_docente= $_POST["id_docente"];


 if ($id_pregunta!="" ) {			
  	 $ruta="imagenes/";  //ubicacion de las im�genes
	 require("conexion.php");
	 //Verificamos si se modific� la materia a la que pertenece el reactivo entonces es necesario modificar el id_preg
/*	 if ($id_materia != $id_materia_aux){
	    $consulta_aux= "SELECT COUNT(id_materia) AS numreg FROM banco_reactivos WHERE id_materia='".$id_materia."';";
		$a_consulta= mysql_query($consulta_aux, $link);
	    $datos_= mysql_fetch_array ($a_consulta, MYSQL_ASSOC);
	    $nreg=$datos_["numreg"]+1;    //se lee el arreglo el cual contiene el total de registros guardados de esa materia
		$id_preg_aux= $id_materia.$nreg;
	 }*/
	 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	 $consulta="UPDATE banco_reactivos SET id_pregunta= '".$id_preg_aux."',instruccion= '".$instruccion."',base= '".$base."', opcionA= '".$opa."',
	              opcionB= '".$opb."',opcionC= '".$opc."',opcionD= '".$opd."',opcion_correcta= '".$opcorrecta."',
				  formato= '".$formato."', nivel_tax= '".$niveltax."', just_fuente= '".$just_fuente."',id_tema= '".$id_tema."',
				  id_subtema= '".$id_subtema."',id_materia= '".$id_materia."',semestre='".$semestre."',
				  id_docente= '".$id_docente."'
				   WHERE  id_pregunta='".$id_pregunta."';";		
	 $hacerconsulta=mysql_query($consulta, $link);
	 if ($hacerconsulta) mensaje(1);   //Si se guardo correctamente
     else  mensaje(2);     //No se guardo 
 }  
 else mensaje(4);   //error si existen variables vacias
            	
 if ($hacerconsulta) mysql_close($link);      //cierra la conexion 

?>
