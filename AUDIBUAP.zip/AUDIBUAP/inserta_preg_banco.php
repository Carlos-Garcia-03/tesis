
<?php 
error_reporting(E_ERROR);
//+++++++++++++++++++++++++++++ Esta ventana es llamada por insertar_reactivo.php ++++++++++++++++++++++++++++++++++++++++++++++++++++++++

//*********** Funci�n que muestra los mensajes de error *****************************	    
function mensaje($msj){
  echo('
	    <html>
        <head>
        <script language="javascript" type="text/javascript">
             function mandar(){        /* La siguiente funci�n se ejecuta cuando se carga la p�gina */
');
               if($msj==1) echo("javascript:window.alert('El Registro se GUARDO Correctamente')");
               if($msj==2) echo("javascript:window.alert('Error... Es posible que ya exista un reactivo con el mismo c�digo');");
			   if($msj==3) echo("javascript:window.alert('Error... Algunos campos no contienen informaci�n');");
			   if($msj==4) echo("javascript:window.alert('Error..No se pudo leer el n�mero de preguntas de la materia seleccionada');");
echo('
               document.f0.submit();
            }
        </script>
        </head>
	    <body onLoad="javascript:mandar();">
            <form name="f0" id="f0" method="post" action="ficha_reactivos.php">
               <input type="hidden" name="'.session_name().'" value="'.session_id().'">
            </form>
	    </body>
 		</html>");
');	 
}		 
 
 ////////////////////////////////////////////////////
//Convierte fecha de mysql a normal
////////////////////////////////////////////////////
function cambiaf_a_normal($fecha){
    ereg( "([0-9]{2,4})-([0-9]{1,2})-([0-9]{1,2})", $fecha, $mifecha);
    $lafecha=$mifecha[3]."/".$mifecha[2]."/".$mifecha[1];
    return $lafecha;
}
//La siguiente linea convierte mjestra fecha le�da de mysql
/*<input type="text" name="fecha" value="<?echo cambiaf_a_normal($fila->fecha);//?>"> 
 */
 ////////////////////////////////////////////////////
//Convierte fecha de normal a mysql
////////////////////////////////////////////////////

function cambiaf_a_mysql($fecha){
    ereg( "([0-9]{1,2})/([0-9]{1,2})/([0-9]{2,4})", $fecha, $mifecha);
    $lafecha=$mifecha[3]."-".$mifecha[2]."-".$mifecha[1];
    return $lafecha;
} 
  //******************************************************************************************************	 
$instruccion= $_POST["txt_instruccion"];
$base= $_POST["txt_base"];
$opa= $_POST["txt_opa"];
$opb= $_POST["txt_opb"];
$opc= $_POST["txt_opc"];
$opd= $_POST["txt_opd"];
$opcorrecta= $_POST["cbx_opcorrecta"];
$formato= $_POST["cbx_formato"];
$niveltax= $_POST["cbx_nivel_taxonomico"];
$just_fuente= $_POST["txt_just_fuente"];
$semestre= $_POST["cbx_sem"];
$id_materia= $_POST["cbx_mat"];
$id_docente= $_POST["id_docente"];
$id_tema= $_POST["cbx_tema"];    //valor del cbx_tema.value
$id_subtema= $_POST["cbx_subtema"];  //valor del cbx_subtema.value

 if ($base !="" and $opa !="" and $opb !="" and  $opc !="" and
     $opd !="" and $opcorrecta !="" and $id_materia !="" and $id_tema !="" and 
     $id_subtema !="" and $id_docente !="" ) {			
  
	 $ruta="imagenes/";  //ubicacion de las im�genes
	 require("conexion.php");
	 // Se optiene el n�mero de reactivos de la materia seleccionada para crear el indice 
	 $consulta= "SELECT COUNT(id_materia) AS num_reactivos FROM banco_reactivos WHERE id_materia='".$id_materia."';";
	 $hacerconsulta= mysql_query($consulta, $link);
	 if ($hacerconsulta) {
         $datos= mysql_fetch_array ($hacerconsulta, MYSQL_ASSOC);	 
         $nreg=$datos['num_reactivos']+1;     
  	     $fecha= date("d/m/Y");  //optiene la fecha del sistema   
	     //Se insertan los datos. el id de la pregunta se forma con el id_materia mas el numero de registros obtenido anteriormente mas uno 
	     $consulta="INSERT INTO banco_reactivos (id_pregunta,instruccion,base,opcionA,opcionB,opcionC,opcionD,opcion_correcta,formato,nivel_tax,
	                                        just_fuente,id_tema,id_subtema,id_materia,semestre,id_docente,fecha,img1,img2,img3,img4,img5,img6,img7)
		  		    VALUES ('$id_materia$nreg','$instruccion','$base','$opa','$opb','$opc','$opd','$opcorrecta','$formato','$niveltax',
					        '$just_fuente','$id_tema','$id_subtema','$id_materia','$semestre','$id_docente','".cambiaf_a_mysql($fecha)."',
					 	    '".$ruta.$img1."','".$ruta.$img2."','".$ruta.$img3."',
							'".$ruta.$img4."','".$ruta.$img5."','".$ruta.$img6."','".$ruta.$img7."');";
	     $hacerconsulta=mysql_query($consulta, $link);
	     if ($hacerconsulta) {
              mysql_close($link);      //cierra la conexion 		 
		      mensaje(1);   //Si se guardo correctamente
		 }
         else  mensaje(2);     //No se guardo 
     }  //if inical
     else mensaje(4);   //error al leer num de materias
 }
 else mensaje(3);   //error variables vacias  
?>

