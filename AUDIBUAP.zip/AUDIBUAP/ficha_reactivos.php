<?php
error_reporting(E_ERROR);
//+++++++++++++++++++++++  Esta ventana es llamada por.... y por envio_var_busca_reactivo.php +++++++++++++++++++++++++++++++++++++++
session_start();	
	
	//verificamos que se halla accesado desde la pagina de ingreso (verificamos que exista alguna variable de sesi�n)
	if (!isset($_SESSION["S_idDocente"])){
       echo('<script languaje="javascript" type="text/javascript">
               location.href="index.php";
             </script>');
    }
  //Si existe la variable de sesi�n entonces se ejecuta el c�digo
  else{
?>
<html>
<head>
<title>Alta de Reactivos</title>
<link rel="stylesheet" href="css/estilo_tabla.css" type="text/css" media="screen" />

<!--************* Esta funci�n que rellena los combox ********************-->	  
<script language="javascript" src="js/jquery-1.2.6.min.js"></script>  <!--Se requiere paracargar los combox-->   
<script language="javascript">

$(document).ready(function(){
   $("#cbx_sem").change(function () {
	                    $("#cbx_sem option:selected").each(function () {
			                                               sem = $(this).val();
			                                               $.post("carga_materias.php", { elegido: sem}, function(data){
				                                                                                              $("#cbx_mat").html(data);
																											  $("#cbx_tema").html("");
																											  $("#cbx_subtema").html("");
			                                                                                                 });			
                                                            });
                          })
	$("#cbx_mat").change(function () {
	                    $("#cbx_mat option:selected").each(function () {
			                                               id_mat = $(this).val();
			                                               $.post("carga_temas.php", { elegido: id_mat, id_tema:'' }, function(data){
				                                                                                              $("#cbx_tema").html(data);
																											  $("#cbx_subtema").html("");
			                                                                                                 });			
                                                            });
                          })
    
	// Parametros para el combo2
	$("#cbx_tema").change(function () {
	                    $("#cbx_tema option:selected").each(function () {
			//alert($(this).val());
			                                               elegido=$(this).val();
			                                               $.post("carga_subtemas.php", { elegido: elegido, id_subtema:'' }, function(data){
				                                                                                              $("#cbx_subtema").html(data);
			                                                                                                 });			
                                                            });
                          })
    
						  
});
</script>	
<!--************* Esta funci�n verifica que se hayanescrito todos los datos********************-->	  
<script language='Javascript' type='text/javascript'>
  function valida_datos(){
	  var error=false;
	  if(!document.getElementById("txt_base").value){
	     error=true;
         javascript:window.alert('Error... el campo BASE no puede quedar vac�o');
	  }	 
	  else{ if(!document.getElementById("txt_opa").value){
	           error=true;
               javascript:window.alert('Error... Debe llenar el campo OPCI�N A');
			}   
		    else{ if(!document.getElementById("txt_opb").value){
			         error=true;
                     javascript:window.alert('Error... Debe llenar el campo OPCI�N B');
				  }
				  else{ if(!document.getElementById("txt_opc").value){
				           error=true;
                           javascript:window.alert('Error... Debe llenar el campo OPCI�N C');
						}
						else{ if(!document.getElementById("txt_opd").value){
				                 error=true;
                                 javascript:window.alert('Error... Debe llenar el campo OPCI�N D');
						      }
						      else{ if(document.getElementById("cbx_opcorrecta").value==0){
				                       error=true;
                                       javascript:window.alert('Error... No ha seleccionado una OPCI�N CORRECTA');
						            }   
						            else{ if(document.getElementById("cbx_formato").value==0){
				                             error=true;
                                             javascript:window.alert('Error... No ha seleccionado el FORMATO del reactivo');
						                  }
								          else{ if(document.getElementById("cbx_nivel_taxonomico").value==0){
				                                   error=true;
                                                   javascript:window.alert('Error... No ha seleccionado el nivel TAXON�MICO del reactivo');
						                        }
								                else{ if(document.getElementById("cbx_sem").value==0){
						                                 error=true;
                                                         javascript:window.alert('Error... No a seleccionado un SEMESTRE');
										              }
										              else{ if(document.getElementById("cbx_mat").value==0){
						                                       error=true;
                                                               javascript:window.alert('Error... No a seleccionado una MATERIA');
											                }
												            else{ if(document.getElementById("cbx_tema").value==0){
						                                             error=true;
                                                                     javascript:window.alert('Error... No puede dejar el campo TEMA vac�o');
													              }	  
								    				              else{ if(document.getElementById("cbx_subtema").value==0){
						                                                   error=true;
                                                                           javascript:window.alert('Error... No puede dejar el campo SUBTEMA vac�o');
															            }
															            else{if(!document.getElementById("txt_fecha").value){
						                                                         error=true;
                                                                               javascript:window.alert('Error... No puede dejar el campo FECHA vac�o');
																			 }
																        }
													              }	
													        }	
											          }
										        }
									      }
									}
							  }	 
						}
				  }
			}  		 
	  }
	  if (!error){
     	  document.getElementById("cbx_mat").disabled= false;   <!-- Deshabilita el select para que no cambien la materia de la pregunta-->
	      document.getElementById("cbx_sem").disabled= false;   <!-- Deshabilita el select para que no cambien el semestre de la pregunta-->
	      document.getElementById("txt_fecha").disabled= false;   <!-- Deshabilita el select para que no cambien el semestre de la pregunta-->	
	      document.getElementById("txt_docente").disabled= false;   <!-- Deshabilita el select para que no cambien el semestre de la pregunta-->	
	      document.form.submit();    <!-- Si se escribieron todos los datos se env�a el formulario-->
	  }	 
  }   <!-- Fin de la Funci�n-->
 </script>
 
<!--*****************************************************************************************************************************
*********************** Estas fuciones s�lo se ejecutan cuando se editan reactivos  *************************************************
*********************************************************************************************************************************-->
<script language="javascript" src="js/jquery-1.2.6.min.js"></script>
<script>
   function carga_select(sem,id_materia,id_tema,id_subtema){
<!-- *************** Carga el combo de materias  ********************************************-->
	    $.post("carga_materias.php", { elegido: sem, id_materia:id_materia }, function(data){
	                                                                $("#cbx_mat").html(data);
	                                                                        });	
		
										
<!-- *************** Carga el combo temas  ********************************************-->																																	
	    $.post("carga_temas.php", { elegido: id_materia, id_tema:id_tema }, function(data){
	                                                                $("#cbx_tema").html(data);
	                                                                        });					
<!-- *************** Carga el combo subtemas  ********************************************-->																																																				
	    $.post("carga_subtemas.php", { elegido: id_tema, id_subtema:id_subtema }, function(data){
	                                                                $("#cbx_subtema").html(data);
	                                                                        });																									
  }

<!-- *************** Carga los datos de la pregunta a editar  ********************************************-->
function cargaDatos(){
<?php
    //Es necesario hacer esto cuando se recibe un arreglo
    $datos = stripslashes($_POST['datos_usuario']);  //Recuperamos el arreglo con los datos de los docentes 
    $datos = urldecode($datos); 
    $datos = unserialize($datos); 
	$i= $_POST['nom_btn'];   //obtenemos el nombre del bot�n que se oprimi�, �ste ser� el num de registro en el arrego 
?>     
  
    document.getElementById("txt_instruccion").value="<?php echo($datos[$i]['instruccion']); ?>";
	document.getElementById("txt_base").value="<?php echo($datos[$i]['base']); ?>";
	document.getElementById("txt_opa").value="<?php echo($datos[$i]['opcionA']); ?>";
	document.getElementById("txt_opb").value="<?php echo($datos[$i]['opcionB']); ?>";
	document.getElementById("txt_opc").value="<?php echo($datos[$i]['opcionC']); ?>";
	document.getElementById("txt_opd").value="<?php echo($datos[$i]['opcionD']); ?>";
	document.getElementById("cbx_opcorrecta").value=  "<?php echo($datos[$i]['opcion_correcta']) ?>";
	document.getElementById("cbx_formato").value = "<?php echo($datos[$i]['formato']); ?>";
	document.getElementById("cbx_nivel_taxonomico").value= "<?php echo($datos[$i]['nivel_tax']); ?>";
	document.getElementById("txt_just_fuente").value="<?php echo($datos[$i]['just_fuente']); ?>";   	
   	
	sem ="<?php echo($datos[$i]["semestre"]);?>";
	id_materia = "<?php echo($datos[$i]["id_materia"]);?>";
	id_tema = "<?php echo($datos[$i]["id_tema"]);?>";
	id_subtema ="<?php echo($datos[$i]["id_subtema"]);?>";
	
	carga_select(sem,id_materia,id_tema,id_subtema);  <!--Carga el combo con las materias del semestre seleccionado-->
	document.getElementById("mat_aux").value= "<?php echo($datos[$i]["id_materia"]);?>"; <!--Respaldamos el id de la materia por si se cambia-->
	document.getElementById("cbx_sem").selectedIndex = sem;
	document.getElementById("cbx_mat").disabled= true;   <!-- Deshabilita el select para que no cambien la materia de la pregunta-->
	document.getElementById("cbx_sem").disabled= true;   <!-- Deshabilita el select para que no cambien el semestre de la pregunta-->
	document.getElementById("txt_fecha").disabled= true;   <!-- Deshabilita el select para que no cambien la fecha de la pregunta-->	
	document.getElementById("txt_docente").disabled= true;   <!-- Deshabilita el select para que no cambien nombre del docente-->	

}
</script>
<!--++++++++++++  Esta funci�n confirma si se desea eliminar el registro ++++++++++++++++++++++++++++-->
<script language='Javascript' type='text/javascript'>
function eliminar(){
    if (confirm('Confirme que desea ELIMINAR el registro')){
       document.form2.submit()
    }
}
</script> 
<!--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-->
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<!--****************************************************************************************************************************-->
<?php
    $opcion= $_SESSION["opcion"];   //Recuperamos la variable de sesi�n

    echo('<div class="Contenedor">');
    //Verificamos que se va a realizar. 1 para INSERTAR preguntas y 0 para EDITAR los datos
    if($opcion == 1) echo("<body>");   
	if($opcion == 0) echo("<body onLoad='javascript:cargaDatos();'>");   //Carga los datos que se van a modificar
?>
    <div class="imagen1"><img src="imagenes/EscudoBuap.png" width="67" height="100"></div>
	
                <div class="Titulo1">- ALTA DE REACTIVOS -</div>
			    <div class="Titulo2">SISTEMA WEB DE REACTIVOS PARA EVALUAR EL APRENDIZAJE EN LA EDUCACI�N SUPERIOR</div>
				 <div class="imagen2"><img src="imagenes/dotted_line.png">
			  
</div>
	
	<div class="Cuadro1">
<?php    
	if($opcion == 1)echo('<form name="form" id="form" action="inserta_preg_banco.php"  method="post">');
    if($opcion == 0)echo('<form name="form" id="form" action="modifica_reactivo.php"  method="post">');   
?>     
<!-- estilo2 -->
     <div class="Estilo2"><br>
       <table width="453" height="58" border="0" align="center" cellspacing="0" >
         <tr>
           <td width="451" height="25">INSTRUCCI�N</td>
         </tr>
		 <tr>
            <td valign="top"><textarea name="txt_instruccion" id="txt_instruccion" cols="70" rows="3" class="area_texto"></textarea></td>
         </tr>
         <tr>
           <td height="25">BASE</td>
         </tr>
		 <tr>
            <td valign="top"><textarea name="txt_base" id="txt_base" cols="70" rows="3" class="area_texto" ></textarea></td>
         </tr>
      </table> 
    </div>  
    <!-- fin estilo 2 -->  

<!-- Imagenes1 -->
<!-- fin Imagenes1 -->
<!-- estilo3 -->
<div class="Estilo3">
  <table width="448" height="390" border="0" align="center" cellspacing="0">
    <tr>
      <td height="49" valign="middle"><div align="center">RESPUESTAS</div></td>
    </tr>
    <tr>
      <td height="45" valign="bottom"><div align="center">Opcion A</div></td>
    </tr>
    <tr>
	  <td width="446"><textarea name="txt_opa" id="txt_opa" cols="70" rows="2" class="area_texto"></textarea></td>
    </tr>
    <tr>
      <td height="34" valign="bottom"><div align="center">Opci&oacute;n B</div></td>
    </tr>
    <tr>
      <td><textarea name="txt_opb" id="txt_opb" cols="70" rows="2" class="area_texto"></textarea></td>
    </tr>
    <tr>
      <td height="34" valign="bottom"><div align="center">Opci&oacute;n C</div></td>
    </tr>
    <tr>
      <td><textarea name="txt_opc" id="txt_opc" cols="70" rows="2" class="area_texto"></textarea></td>
    </tr>
    <tr>
      <td height="36" valign="bottom"><div align="center">Opci&oacute;n D</div></td>
    </tr>
    <tr>
      <td><textarea name="txt_opd" id="txt_opd" cols="70" rows="2" class="area_texto"></textarea></td>
    </tr>
    <tr>
	<td height="43" valign="bottom" >Opci&oacute;n Correcta:	   
        <select name="cbx_opcorrecta" id="cbx_opcorrecta">
              <option value="0" selected="selected">Seleccione</option>
              <option value="A">"A"</option>
              <option value="B">"B"</option>
              <option value="C">"C"</option>
              <option value="D">"D"</option>
        </select></td>
    </tr>
  </table>
</div>  
<!-- fin estilo 3 -->
<!-- fin Imagenes2 -->
<label>&nbsp;</label>

  <!--Estilo4 -->
<div class="Estilo4"> 
  <table width="210"  border="0" align="center" cellspacing="0"> 	
    <tr>
      <td height="33" valign="bottom"><div align="left">Formato</div></td>
    </tr>
	<tr>
      <td>
	  <select name="cbx_formato" id="cbx_formato">
              <option value="0" selected="selected">Seleccione formato</option>
              <option value="Cuestionamiento directo">Cuestionamiento directo</option>
              <option value="Canev&aacute; o decompletar">Canev&aacute; o decompletar</option>
              <option value="Ordenamiento y selecci&oacute;n de elementos">Ordenamiento y selecci&oacute;n de elementos</option>
        </select></td>
	</tr>  
    <tr>
      <td height="33" valign="bottom"><div align="left">Nivel Taxon&oacute;mico </div></td>
    </tr>
    <tr>
      <td>
	    <select name="cbx_nivel_taxonomico" id="cbx_nivel_taxonomico">
	      <option value="0">Seleccione nivel taxon&oacute;mico</option>
	      <option value="Conocimiento o memoria">Conocimiento o memoria</option>
	      <option value="Comprensi&oacute;n">Comprensi&oacute;n</option>
	      <option value="Aplicaci&oacute;n">Aplicaci&oacute;n</option>
	      <option value="An&aacute;lisis">An&aacute;lisis</option>
	      <option value="S&iacute;ntesis">S&iacute;ntesis</option>
	      <option value="Evaluaci&oacute;n">Evaluaci&oacute;n</option>
        </select></td>
    </tr>
    <tr>
      <td height="35" valign="bottom">Justificaci&oacute;n y Fuente</td>
    </tr>
    <tr>
      <td><textarea name="txt_just_fuente" id="txt_just_fuente" cols="70" rows="2" class="area_texto"></textarea></td>
    </tr>
</table>
</div>  
<!-- fin estilo 4 -->  
   
    <!-- estilo5 -->	
<div class="Estilo5">
   <table width="564" cellspacing="10"> 	
      <tr>
         <td height="47" colspan="2"><div align="center">IDENTIFICADORES DEL REACTIVO </div></td>
      </tr>
      <tr>
         <td height="24"><div align="right">Nivel:</div></td>
         <td><select name="cbx_sem" id="cbx_sem">
              <option value="0" selected="selected">Selecciona el NIvel</option>
              <option value="1">NIvel Basico</option>
              <option value="2">NIvel Formativo</option>
              <option value="3">Nivel Optativo</option>
              
             </select></td>
      </tr>
      <tr>
         <td height="24"><div align="right">Materia:</div></td>
         <td><select name="cbx_mat" id="cbx_mat">
          </select></td>
      </tr>
      <tr>
         <td height="24"><div align="right">Area:</div></td>
         <td><div align="left"><select name="cbx_tema" id="cbx_tema">
		                       </select></div></td>
      </tr>
      <tr>
         <td height="24"><div align="right">Subarea:</div></td>
        <td><div align="left"><select name="cbx_subtema" id="cbx_subtema">
		                      </select></div></td> 
      </tr>
      <tr>
         <td height="24"><div align="right">Fecha:</div></td>
         <td><div align="left"><input name="txt_fecha" type="text" id="txt_fecha" class="area_texto" value="<?php
                                                                                           if($opcion == 0) echo($datos[$i]['fecha']);
																						   if($opcion == 1) echo(date('d/m/Y'));?>"
																						    /></div></td>
      </tr>
   	  <tr>
         <td height="24"><div align="right">Elaborador:</div></td>
         <td><input type="text" name="txt_docente"  id="txt_docente" class="area_texto" value="<?php 
		                                                                        if($opcion == 0)echo($_POST['docente']);
																				if($opcion == 1)echo($_SESSION["S_nombre"]);?>" 
																				/></td>
    </tr>
  </table>
</div>   
<!-- fin estilo 5 -->  
   <div class="botones">
     <table>
        <tr>
		   <td width="105" align="right">
		<?php		
             if($opcion == 1) echo('<input type="button" name="btn_guardar" id="btn_guardar" value="G U A R D A R"  onClick="valida_datos();"/>');
	         if($opcion == 0) echo('<input type="button" name="btn_modifica" id="btn_modifica" value="MODIFICAR" onClick="valida_datos();"/>');   	
	 echo('</td>');
		     if($opcion == 0){
			    echo('<td align="right"> 
			             <input type="button" name="btn_eliminar" id="btn_eliminar" value="ELIMINAR" onClick="eliminar();"/>
			         </td>');		    
			}
	 echo('<td align="right">');
		 //Regresa a la p�gina que llam� es esta p�gina
		   if ($opcion == 1  ) {   // Si $pag es igual a UNO entonces la llam� la p�gina menu_opciones.php
		       echo('<input type="button" name="regresar" id="regresar" value="REGRESAR" onClick="location.href=\'menu_opciones.php\';"/>');
		   }	
		   if ($opcion == 0){   // Si $pag es igual a CERO entonces la llam� la p�gina buscar_usuario.php
		       echo('<input type="button" name="regresar" id="regresar" value="REGRESAR" onClick="document.form3.submit();"/>');
		   }
     echo('</td>');		   
 ?>
		
     </table>
   </div>   
   <!-- fin botones -->  
<!-- Campos para insertar temas y subtemas en el combox -->  
  <div  class="Opciones1">  
    <table width="158" height="105" border="0" align="center" cellspacing="0">
       <tr>
         <td  colspan="2" height="34">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Agregar �reas </td>
	   </tr>  
	   <tr>
         <!--         <td width="80"><input type="button" name="btn_inser_tema" id="btn_inser_tema" value="Insertar" onClick="javascript:carga(1);" /></td>-->
         <td width="80">
		   <input type="button2" name="btn_inser_tema" id="btn_inser_tema" value="Agregar" onClick="location.href='ficha_temas.php'"; /></td>
       </tr>
       <br>
	   <tr>
         <td  colspan="2" height="34">&nbsp;&nbsp;Agregar Sub�reas</td>
	   </tr>
	   <tr>
         
<!-- 	     <td><input type="button" name="btn_inser_subtema" id="btn_inser_subtema" value="Insertar"  onClick= "javascript:carga(2);" /></td>-->
 	     <td>
		    <input type="button2" name="btn_inser_subtema" id="btn_inser_subtema" value="Agregar"  onClick="location.href='ficha_subtemas.php'";/>
		 </td>		 
       </tr>
    </table>
  </div>   
  <!-- fin oopciones 1 -->  
   	  <input type="hidden" name="id_docente" id="id_docente" value= "<?php 
	                                                                    if($opcion == 0) echo($datos[$i]['id_docente']); 
																		if($opcion == 1)echo($_SESSION['S_idDocente']);?>"
																		/>
<?php  
    if($opcion == 0){
	  echo('
        <!--**************Est�s variables oocultas se envian solo cuando se oprime el bot�n MODIFICAR **************************-->
          <input type="hidden" name="mat_aux" id="mat_aux" value= "'.$datos[$i]["id_materia"].'"  />		  	  
          <input type="hidden" name="id_pregunta" id="id_pregunta" value= "'.$datos[$i]['id_pregunta'].'" />

        <!--Se env�an los siguente campos ocultos para que al regresar busque nuevamente los reactivos y no se muestre la pantalla en blanco -->	
          <input name="id_tema_aux" type="hidden" id="id_tema_aux" value= "'.$_POST['cbx_tema'].'"  />
          <input name="nom_docente_aux" type="hidden" id="nom_docente_aux" value= "'.$_POST['docente'].'"  />
          <input name="nom_materia_aux" type="hidden" id="nom_materia_aux" value= "'.$_POST['materia'].'"  />	
	  ');
	}
?>
 </form>
    
<!--**************Este formulario se ejecuta s�lo cuando se oprime el bot�n de eliminar ****************************************-->
    <form name="form2" id="form2" action="elimina_reactivo.php"  method="post">
	   <input type="hidden" name="id_pregunta" id="id_pregunta" value= "<?php echo($datos[$i]['id_pregunta']); ?>"  />
	   <input type="hidden" name="id_materia" id="id_materia" value= "<?php echo($datos[$i]["id_materia"]); ?>"  />
        <!--Se env�an los campos ocultos cbx_docente y cbx_materia para que al regresar busque nuevamente los reactivos y no se muestre la pantalla en blanco -->	
	   <input name="id_docente" type="hidden" id="id_docente" value= "<?php echo($datos[$i]['id_docente']); ?>"  />
       <input name="id_tema_aux" type="hidden" id="id_tema_aux" value= "<?php echo($_POST['cbx_tema']); ?>"  />
       <input name="nom_docente_aux" type="hidden" id="nom_docente_aux" value= "<?php echo($_POST['docente']); ?>"  />
       <input name="nom_materia_aux" type="hidden" id="nom_materia_aux" value= "<?php echo($_POST['materia']); ?>"  />	
	</form>
<!--********************************************************************************************************************************-->
<!--*********Este formulario se ejecuta s�lo cuando se oprime el bot�n REGRESAR y se est� editando reactivos. *********************-->
    <form name="form3" id="form3" action="busca_reactivo.php"  method="post">
	   <!--Se env�an los siguientes campos ocultos para que al regresar busque nuevamente los reactivos y no se muestre la pantalla en blanco -->
	   <input name="cbx_docente" type="hidden" id="cbx_docente" value= "<?php echo($datos[$i]['id_docente']); ?>"  />
       <input name="cbx_tema" type="hidden" id="cbx_tema" value= "<?php echo($_POST['cbx_tema']); ?>"  />
       <input name="docente" type="hidden" id="docente" value= "<?php echo($_POST['docente']); ?>"  />
       <input name="materia" type="hidden" id="materia" value= "<?php echo($_POST['materia']); ?>"  />	   	   
	</form>
<!--********************************************************************************************************************************-->
</div>   <!-- fin main -->  
  </div> <!--wrap -->
</body>
</html>
<?php
    }   //Fin del ELSE inicial
?>
