<?php
error_reporting(E_ERROR);
//*********** Funci�n que muestra los mensajes de error *****************************	    
   function mensaje($msj){
       echo('
	         <html>
             <head>
                <script language="javascript" type="text/javascript">
                   function mandar(){        /* La siguiente funci�n se ejecuta cuando se carga la p�gina */
	   ');
				     if($msj==1) echo("javascript:window.alert('El Registro se GUARDO Correctamente')");
                     if($msj==2) echo("javascript:window.alert('Error... Es posible que ya exista esta matr�cula');");
				 	 if($msj==3) echo("javascript:window.alert('Error... Algunos campos no contienen informaci�n');");
       echo('
	                 document.f0.submit();
                   }
                </script>
		     </head>
		     <body onLoad="javascript:mandar();">
                 <form name="f0" id="f0" method="post" action="ficha_subtemas.php">
                      <input type="hidden" name="'.session_name().'" value="'.session_id().'">
                 </form>
			 </body>
 		     </html>");
		');
   }		 
//************************************************************************************
session_start();
	//verificamos que se halla accesado desde la pagina de ingreso (verificamos que exista alguna variable de sesi�n)
if (!Session_is_registered("S_idDocente")){
    echo('<script languaje="javascript" type="text/javascript">
           location.href="index.php";
       </script>');
    }
else{
    $subtema= $_POST["txt_subtema"];
    $id_tema=$_POST["cbox_tema"];
    if ($subtema!= "" and $id_tema != "") {
       // Se optiene el n�mero de temas de la materia  
	   require("conexion.php");
	   $consulta= "SELECT COUNT(id_tema) AS numreg FROM subtemas WHERE id_tema='".$id_tema."';";
	   $hacerconsulta= mysql_query($consulta, $link);
	   if ($hacerconsulta) {
           $datos= mysql_fetch_array ($hacerconsulta, MYSQL_ASSOC);
	       $nreg=$datos["numreg"]+1;    //optenemos el num. de temas de la materia y le sumamos 1
	       $id_subtema= $id_tema."ST".$nreg;    //Creamos el codigo al nuevo tema
       }    
       $consulta="INSERT INTO subtemas (id_subtema,subtema,id_tema)
                  VALUES ('$id_subtema','$subtema','$id_tema');";
	   $hacerconsulta=mysql_query($consulta, $link);
	   if ($hacerconsulta) mensaje(1);   
       else mensaje(2); 
	}
	else mensaje(3);

    if ($hacerconsulta) {
        mysql_close($link);   //cierra la conexion
    }  
}//Se cierra el ELSE que se avrio al inicio
?>
