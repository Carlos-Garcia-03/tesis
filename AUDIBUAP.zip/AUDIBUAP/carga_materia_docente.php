<?php
error_reporting(E_ERROR);
      require("conexion.php");
	   //Si el usuario es un administrador, se muestran todas las materias
	  $consulta='SELECT b.materia, b.id_materia FROM asignacion_materias a, materias b 
	             WHERE a.id_materia = b.id_materia and a.id_docente="'.$_POST["id_docente"].'";';  
      $hacerconsulta=mysql_query($consulta, $link);
      $rpta="<option value= '0'>Seleccione la Materia</option>;";
      if ($hacerconsulta) {    //si no hubo error al hacer la consulta
	     while ($materia=mysql_fetch_array ($hacerconsulta, MYSQL_ASSOC)){
	            $rpta= $rpta.'<option value="'.$materia["id_materia"].'">'.htmlentities($materia["materia"]).'</option>';
		  }
       }
       else $rpta= '<option value="1">error...</option>';  
       echo ($rpta);	

?>



