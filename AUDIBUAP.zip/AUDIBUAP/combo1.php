<?php
error_reporting(E_ERROR);
    if ($_POST["elegido"] != 0) {
       require("conexion.php");
       $consulta='SELECT id_materia,materia FROM materias  WHERE semestre = "'.$_POST["elegido"].'";';  //busca materias que coincidan con el semestre
       $hacerconsulta=mysql_query($consulta, $link);
    
       $rpta="<option value= '0'>Seleccione la Materia</option>;";
       if ($hacerconsulta) {    //si no hubo error al hacer la consulta
	      while ($materia=mysql_fetch_array ($hacerconsulta, MYSQL_ASSOC)){
	            $rpta= $rpta.'<option value="'.$materia["id_materia"].'">'.htmlentities($materia["materia"]).'</option>';
		  }
       }
       else $rpta= '<option value="1">error...</option>';  
    }
    echo ($rpta);	

?>



