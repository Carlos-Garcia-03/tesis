<?php
error_reporting(E_ERROR);  
            //+++++++++++++++++++++++++++++++Esta pagina es llamada por la pagina menu_opciones.php +++++++++++++++++++++++++++++++++
    session_start();
	//verificamos que se halla accesado desde la pagina de ingreso (verificamos que exista alguna variable de sesi�n)
	if (!isset($_SESSION["S_idDocente"])){
       echo(' <script languaje="javascript" type="text/javascript">
                location.href="index.php";
              </script>');
    }
        //Si existe la variable de sesi�n entonces se ejecuta el c�digo
   else{
?>
<html>
<head>
<title>Consultar Calificaciones</title>
<link rel="stylesheet" href="css/estilo_buscar_calif.css" type="text/css" media="screen" />


<script language="javascript" src="js/jquery-1.2.6.min.js"></script>
<script>
<!--*******************Protejemos el codigo para que no se muestre si no tienen javascript*****************-->
<!-- ************************ Carga el combo con los docentes ****************************************************************************-->
   function CargaDocentes(){
        id_docente = '<?php echo($_SESSION["S_idDocente"]); ?>';
		privilegio= '<?php echo($_SESSION["privilegio"]); ?>';
	    
		$.post("carga_docentes.php", {privilegio: privilegio, id_usuario:id_docente}, function(data){
	                                                                                   $("#cbx_docente").html(data);
	                                                                                                 });			
   }

<!-- ****************************Carga el combo con los examenes creados por el docente elegido***********************************************-->
 $(document).ready(function(){
    $("#cbx_docente").change(function () {
   		                $("#cbx_docente option:selected").each(function () {
	                                           elegido = $(this).val();
											   priv = '<?php echo($_SESSION["privilegio"]) ?>';
	                                           $.post("carga_materia_docente.php", { id_docente: elegido, privilegio:priv  }, function(data){
                                                                                                             $("#cbx_materia").html(data);
																											 $("#cbx_examenes").html();

			                                                                                         });			
                                                           });
                          })
    $("#cbx_materia").change(function () {
   		                $("#cbx_materia option:selected").each(function () {
	                                           elegido = $(this).val();
											   cbxdocente= document.getElementById("cbx_docente");  //Referenciamos el combox
											   id_docente= cbxdocente.value;  //optenemos el docente seleccionado en el combox
											   priv = '<?php echo($_SESSION["privilegio"]) ?>';
	                                           $.post("carga_exa_creados.php", { id_docente: id_docente, id_materia:elegido  }, function(data){
                                                                                                             $("#cbx_examenes").html(data);

			                                                                                         });			
                                                           });
                          })

});
</script> 
 <!-- ************************* nos env�a al menu principal de opciones ****************************-->
<script language='Javascript' type='text/javascript'>  
   function ir_pag(){
	       location.href="menu_opciones.php?<?php echo(session_name());?>=<?php echo(session_id()); ?>";
   }
</script>	
<!--************* Esta funci�n verifica que se hayanescrito todos los datos********************-->	  
<script language='Javascript' type='text/javascript'>
  function valida_datos(){
	  var error=false;
	  if(document.getElementById("cbx_docente").value==0){
	     error=true;
         javascript:window.alert('Error... Debe Seleccionar un Docente');
	  }	 
	  else{
	       if(document.getElementById("cbx_materia").value==0){
	          error=true;
              javascript:window.alert('Error... Debe Seleccionar una Materia');
		   }
		   else{
		        if(document.getElementById("cbx_examenes").value==0){
	               error=true;
                   javascript:window.alert('Error... Debe Seleccionar una Prueba');
	            }	 
		   }   	 
	  }
	  if (!error){
	     var cbxmateria = document.getElementById("cbx_materia");
		 document.getElementById("nom_materia").value = cbxmateria.options[cbxmateria.selectedIndex].text; 
	    <!-- Creamos la variable para enviarla como dato oculto-->
	     document.form.submit();    <!-- Si se escribieron todos los datos se env�a el formulario-->
	  }	 
  }   <!-- Fin de la Funci�n-->
 </script>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<!--*********************************************************************************************************************-->

<body onLoad="CargaDocentes()">	
<div class="Contenedor">
     <div class="imagen1"><img src="imagenes/EscudoBuap.png" width="67" height="100"></div>
			  <div class="Estilo5">
                <div class="Titulo1">- CONSULTA DE CALIFICACIONES -</div>
			    <div class="Titulo3">SISTEMA WEB DE REACTIVOS PARA EVALUAR EL APRENDIZAJE EN LA EDUCACI�N SUPERIOR</div>
				 <div class="imagen2"><img src="imagenes/dotted_line.png">
			  </div>
       
    <div class="Cuadro1">
    <br>
       <form id="form" name="form" method="post" action="obtener_calificacion.php?" >
       <table width="486" height="150" border="0" cellspacing="0" align="center">
          <tr>
            <td width="98" height="29"><div class="Etiquetas">Coordinador:</div></td>
			 <td width="384" height="28"><div align="left">
                <select name="cbx_docente" id="cbx_docente">
                </select>
            </div></td>
	      </tr>
	      <tr>
            <td><div class="Etiquetas">Materia:</div></td>
	         <td><div align="left">
                 <select name="cbx_materia" id="cbx_materia">
                 </select>
             </div></td>
	      </tr>
          <tr>
	         <td><div class="Etiquetas">Examen:</div></td>
	         <td><div align="left">
                <select name="cbx_examenes" id="cbx_examenes">  <!--observar que el nombre y el id son distintos-->
                </select>
             </div></td>
          </tr>
      </table>
	  

	<input type="hidden" name="nom_materia" id= "nom_materia" value="">   	<!-- enviamos el nombre de lamateria-->
    <input type="hidden" name="'.session_name().'" value="'.session_id().'">  	<!-- enviamos las variables de sesi�n-->
   </form>  <!--form-->
   <div class="Botones">
     <table height="47">  
	  <tr>
         <td  width="102" height="43" valign="bottom"><div align="center">
	       <input type="button" name="btn_aceptar" id="btn_aceptar" value="ACEPTAR" onClick="javascript:valida_datos();" /></div></td>
	     <td width="127" valign="bottom"><div align="center">
	      <input type="button" name="retorno" id="retorno" value="REGRESAR" onClick="javascript:ir_pag();"/></div></td>
      </tr>
     </table>
   </div>
</div>
</div><!-- fin Contenedor -->
</body>
</html>
<?php
  }
?>
